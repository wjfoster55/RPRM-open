#!/usr/bin/env python3
"""Independent, exact development checks of the supplied R2 public API.
No imports from its test runner. Table arithmetic is a separate reference.
Does not change the supplied package. Uses only newly created work files.
"""
from __future__ import annotations
import argparse, hashlib, importlib.util, itertools, json, random, sys
from dataclasses import asdict
from fractions import Fraction as Q
from pathlib import Path


def load_module(root: Path):
    path = root/'experiments/core_recovery_bridge_01_r2/prestige_envelope.py'
    spec = importlib.util.spec_from_file_location('reviewed_envelope', path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = mod
    spec.loader.exec_module(mod)
    return mod, path


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--package', required=True, type=Path)
    ap.add_argument('--work', required=True, type=Path)
    ap.add_argument('--output', required=True, type=Path)
    args = ap.parse_args()
    args.work.mkdir(parents=True, exist_ok=False)
    e, source = load_module(args.package.resolve())
    rows = []
    contract = e.FULL_CUBE_CONTRACT | frozenset({'identity'})

    def must(condition, message):
        if not condition:
            raise AssertionError(message)

    def exact(result):
        must(result.status == 'EXACT', repr(result))
        return result.value

    def promote(table, name, family='rational_cube', backed=True, ops=contract):
        return e.promote_cube(table, label='one', contract=ops,
            cold_dir=args.work/'cold' if backed else None, name=name, family=family)

    def api_case(name, fn):
        try:
            data = fn()
            rows.append({'case':name, 'status':'PASS', 'data':data})
        except Exception as ex:
            rows.append({'case':name, 'status':'FAIL', 'error':repr(ex)})

    def family_repair():
        checks=[]
        for backed in (False,True):
            units = [e.unit(axis, family='boolean_cube', contract=contract,
                cold_dir=args.work/'cold' if backed else None,
                name=f'family_{axis}_{backed}') for axis in ('h','x','y')]
            meter0=asdict(e.METER)
            p=exact(e.multiply_units(exact(e.multiply_units(units[0],units[1])),units[2]))
            sres=e.add_units(p,p); s=exact(sres)
            meter1=asdict(e.METER)
            must(p.family=='boolean_cube' and s.family=='rational_cube','incorrect family')
            must(s.retained==(Q(0),)*7,'incorrect zero C2')
            must(meter1['cold_reads']==meter0['cold_reads'],'hidden cold arithmetic')
            omitted=e.inspect_omitted(s)
            flipped=e.apply_fixed_receiver_map(s,tuple(i^1 for i in range(8)))
            if backed:
                must(exact(omitted)==2,'wrong composed omitted value')
                must(exact(e.read_admitted(exact(flipped)))[6]==2,'wrong transformed value')
            else:
                must(omitted.status=='REOPEN_REQUIRED','unbacked omission fabricated')
                must(flipped.status=='REOPEN_REQUIRED','unbacked flip fabricated')
            checks.append({'backed':backed,'product_family':p.family,'sum_family':s.family,
                'C2_disposition':sres.disposition,'C2_count_scope':sres.witness['counts'],
                'cold_reads_during_arithmetic':meter1['cold_reads']-meter0['cold_reads'],
                'recipe_constructions':meter1['constructions']-meter0['constructions'],
                'omitted_status':omitted.status,'omitted_value':str(omitted.value),
                'flip_status':flipped.status})
        rejected=0
        for site in range(8):
            for bad in (-1,2,Q(1,2)):
                vals=[Q(0)]*8; vals[site]=Q(bad)
                try: promote(vals,f'bad_{site}_{bad}',family='boolean_cube',backed=False)
                except e.AdmissionError: rejected+=1
                else: raise AssertionError('false Boolean declaration accepted')
        return {'hidden_sums':checks,'invalid_boolean_declarations_rejected':rejected}

    def maps_repair():
        table=tuple(Q(i*i-3,2) for i in range(8))
        admitted=promote(table,'map_full')
        narrow=promote(table,'map_narrow',ops=e.ARITH_CONTRACT)
        parity=0
        for env in (admitted,narrow):
            for name,mapping in e.input_maps().items():
                a=e.apply_input_map(env,name); b=e.apply_fixed_receiver_map(env,mapping)
                must(a.status==b.status and a.disposition==b.disposition,'admission routes differ')
                expected_admission=name in env.contract
                must((a.status=='EXACT')==expected_admission,'wrong contract decision')
                if expected_admission:
                    expected=tuple(table[mapping[s]] for s in range(7))
                    must(exact(e.read_admitted(a.value))==expected,'named map wrong')
                    must(exact(e.read_admitted(b.value))==expected,'generic map wrong')
                parity+=1
        h=e.unit('h',family='boolean_cube',contract=contract,cold_dir=args.work/'cold',name='raw_h')
        mapping=(0,0,0,1,0,0,0,1)
        must(e.apply_fixed_receiver_map(h,mapping).status=='UNSUPPORTED','arbitrary map certified')
        raw=e.apply_raw_site_map(h,mapping); val=exact(raw)
        must(val.degree_bound is None and raw.witness['certified'] is False,'raw metadata wrong')
        must(exact(e.read_admitted(val))==tuple(Q(int(i in (3,7))) for i in range(7)),'raw hx wrong')
        must(e.apply_input_map(val,'flip_h').status=='UNSUPPORTED','raw continued through flip')
        must(e.multiply_units(val,h).status=='UNSUPPORTED','raw continued through arithmetic')
        invalid=[(0,)*7,(0,)*7+(8,),(0,)*7+(-1,),(0,)*7+(1.0,),(0,)*7+(True,)]
        for m in invalid:
            must(e.apply_fixed_receiver_map(h,m).status=='UNSUPPORTED','invalid certified map')
            must(e.apply_raw_site_map(h,m).status=='UNSUPPORTED','invalid raw map')
        return {'named_generic_decisions_compared':parity,'invalid_map_paths_rejected':2*len(invalid),
            'raw_helper_degree_bound':val.degree_bound,'raw_helper_contract':sorted(val.contract),
            'raw_helper_certified':raw.witness['certified']}

    def arithmetic_oracle():
        rng=random.Random(92601)
        steps=values_compared=0
        for k in range(16):
            if k%2==0:
                aa=tuple(Q(rng.randrange(2)) for _ in range(8)); fa='boolean_cube'
            else:
                aa=tuple(Q(rng.randrange(-4,5),rng.randrange(1,4)) for _ in range(8)); fa='rational_cube'
            if k%3==0:
                bb=tuple(Q(rng.randrange(2)) for _ in range(8)); fb='boolean_cube'
            else:
                bb=tuple(Q(rng.randrange(-3,4),rng.randrange(1,4)) for _ in range(8)); fb='rational_cube'
            a=promote(aa,f'oracle_{k}_a',fa); b=promote(bb,f'oracle_{k}_b',fb)
            ref=aa
            for op in ('multiply','add','clamp_h_0','flip_y','multiply','add'):
                cold_before=e.METER.cold_reads
                if op=='add': result=e.add_units(a,b); ref=tuple(x+y for x,y in zip(ref,bb))
                elif op=='multiply': result=e.multiply_units(a,b); ref=tuple(x*y for x,y in zip(ref,bb))
                elif op=='clamp_h_0': result=e.apply_fixed_receiver_map(a,tuple(i&~1 for i in range(8))); ref=tuple(ref[i&~1] for i in range(8))
                else: result=e.apply_input_map(a,'flip_y'); ref=tuple(ref[i^4] for i in range(8))
                if op in ('add','multiply'):
                    must(e.METER.cold_reads==cold_before,'arithmetic performed cold reads')
                a=exact(result)
                observed=exact(e.read_admitted(a))+(exact(e.inspect_omitted(a)),)
                must(observed==ref,f'independent table mismatch at {k}/{op}')
                if a.family=='boolean_cube': must(all(v in (0,1) for v in ref),'unsound Boolean family')
                # Separate direct inclusion-exclusion degree calculation.
                coeff=[sum(((-1)**(s.bit_count()-t.bit_count()))*ref[t] for t in range(8) if (t&s)==t) for s in range(8)]
                degree=max([0]+[s.bit_count() for s,c in enumerate(coeff) if c])
                if a.degree_bound is not None: must(degree<=a.degree_bound,'unsound degree bound')
                steps+=1; values_compared+=8
        return {'deterministic_seed':92601,'source_pairs':16,'composed_steps':steps,
            'exact_value_comparisons':values_compared,'arithmetic_cold_reads':0,
            'scope':'development oracle, not performance or holdout evaluation'}

    def coherent_transport():
        table=tuple(Q(2*i-5,3) for i in range(8))
        hot=promote(table,'transport_hot',backed=False)
        count=0
        for perm in itertools.permutations(range(3)):
            for flip in range(8):
                mapping=tuple(sum(((s>>perm[b])&1)<<b for b in range(3))^flip for s in range(8))
                result=e.coherent_transport(hot,mapping)
                expected=tuple((s,table[mapping[s]]) for s in range(8) if mapping[s]<7)
                must(exact(result)==expected,'coherent receiver mismatch')
                must(result.witness['used_cold'] is False,'unexpected cold access')
                count+=1
        return {'cube_symmetries':count,'backing':'absent','all_exact':True}

    def dependency_checks():
        units=[e.unit(axis,family='boolean_cube',contract=contract,cold_dir=args.work/'cold',
            name=f'dep_{axis}') for axis in ('h','x','y')]
        p=exact(e.multiply_units(exact(e.multiply_units(units[0],units[1])),units[2]))
        s=exact(e.add_units(p,p))
        path=Path(units[0].cold_route); original=path.read_bytes()
        path.write_bytes(original+b'corruption')
        corrupt=e.inspect_omitted(s)
        must(corrupt.status=='INVALID_DEPENDENCY' and corrupt.value is None,'corruption fabricated result')
        must(exact(e.read_admitted(s))==(Q(0),)*7,'backing corruption invalidated independently sufficient hot answer')
        path.unlink()
        missing=e.inspect_omitted(s)
        must(missing.status=='UNRESOLVED' and missing.value is None,'missing backing fabricated result')
        path.write_bytes(original)
        must(exact(e.inspect_omitted(s))==2,'restored dependency did not recover')
        return {'corrupt_status':corrupt.status,'missing_status':missing.status,
            'restored_omitted':'2','hot_answer_remains_available':True}

    api_case('output_family_and_declared_input',family_repair)
    api_case('named_generic_raw_maps',maps_repair)
    api_case('exact_composed_table_oracle',arithmetic_oracle)
    api_case('coherent_receiver_transport',coherent_transport)
    api_case('physical_dependency_mutations',dependency_checks)
    report={'status':'PASS' if all(r['status']=='PASS' for r in rows) else 'FAIL',
        'scope':'Independent assistant-side constructed development tests, not original donor replay',
        'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'python':sys.version,'results':rows}
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))
    return 0 if report['status']=='PASS' else 2
if __name__=='__main__':
    raise SystemExit(main())
