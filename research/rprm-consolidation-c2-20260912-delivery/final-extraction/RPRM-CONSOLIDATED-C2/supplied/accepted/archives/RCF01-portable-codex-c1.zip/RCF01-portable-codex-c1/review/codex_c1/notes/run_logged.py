"""Run an existing script with task-local clean Python environment and raw logs."""
import argparse
import hashlib
import json
import os
import platform
import subprocess
import sys
import time
from pathlib import Path

def main():
    p = argparse.ArgumentParser()
    p.add_argument('--log', type=Path, required=True)
    p.add_argument('--cwd', type=Path, required=True)
    p.add_argument('args', nargs=argparse.REMAINDER)
    a = p.parse_args()
    a.log.mkdir(parents=True, exist_ok=False)
    env = dict(os.environ)
    for key in ('PYTHONPATH', 'PYTHONHOME'):
        env.pop(key, None)
    env['PYTHONDONTWRITEBYTECODE'] = '1'
    env['PYTHONNOUSERSITE'] = '1'
    env['PYTHONUTF8'] = '1'
    args = a.args[1:] if a.args[:1] == ['--'] else a.args
    args[0] = str(Path(args[0]).resolve())
    cmd = [sys.executable, '-I', '-B', *args]
    started = time.time()
    proc = subprocess.run(cmd, cwd=a.cwd, env=env, capture_output=True)
    (a.log/'stdout.txt').write_bytes(proc.stdout)
    (a.log/'stderr.txt').write_bytes(proc.stderr)
    script = Path(args[0]).resolve()
    rec = {'command': cmd, 'cwd': str(a.cwd.resolve()), 'exit_code': proc.returncode,
           'started_unix': started, 'seconds': time.time()-started,
           'python': sys.version, 'executable': sys.executable, 'platform': platform.platform(),
           'environment': {'PYTHONPATH': 'UNSET', 'PYTHONHOME': 'UNSET',
                           'PYTHONDONTWRITEBYTECODE': '1', 'PYTHONNOUSERSITE': '1', 'PYTHONUTF8': '1'},
           'entrypoint_sha256': hashlib.sha256(script.read_bytes()).hexdigest(),
           'stdout_bytes': len(proc.stdout), 'stderr_bytes': len(proc.stderr)}
    (a.log/'context.json').write_text(json.dumps(rec, indent=2)+'\n', encoding='utf-8')
    print(json.dumps(rec, indent=2))
    return proc.returncode

if __name__ == '__main__':
    raise SystemExit(main())
