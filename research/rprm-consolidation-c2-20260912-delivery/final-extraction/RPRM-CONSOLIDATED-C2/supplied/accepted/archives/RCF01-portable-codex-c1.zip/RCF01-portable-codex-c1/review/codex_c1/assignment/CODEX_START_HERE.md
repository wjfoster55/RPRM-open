# RCF01–Codex C1: independent review and bounded runtime closeout

**12 September 2026 · The single active assignment in this handoff**

William is transferring this work from Cursor to Codex because he wants a second pair of eyes on an important core RPRM result. Do substantive independent review, not rubber-stamping. Continue from the frozen R2 implementation; do not restart concept recovery or treat the entire program as unformalized.

Read `CURRENT_STATE.md`, then follow this assignment. Earlier Cursor prompts and integration instructions inside the supplied trees are historical context, not parallel jobs. Applicable workspace `AGENTS.md` instructions still govern.

## 1. Objective and stop condition

Independently check the finite mathematical/API claims, reproduce the specific remaining runner-report defect, inspect the proposed patch, and integrate a justified minimal runtime repair into a clearly identified successor export. Preserve the accepted R2 work and the broader meanings of the recovered concepts.

Finish with an actual portable ZIP, evidence, a readable review/closeout, and a carry-forward note. A review may confirm prior findings, correct them, or identify a concrete new blocker. Do not require novelty, a speed improvement, a new theorem, or another research round to finish.

This handoff is **not** an instruction to solve the open fiving/Double-Stamp bridge, finish every deferred concept, rewrite the paper, or dispatch other projects.

## 2. Authority, files, and workspace

The handoff contains:

- `frozen_r2/`: exact expanded copy of the submitted R2 portable package. Its root `run_portable.py` is the baseline entrypoint.
- `review_r2/`: exact expanded copy of the prior review, including its patch, executable probes, historical results, and explicit limitations.
- `recovered_sources/`: exact convenience extraction of the original recovery archive already retained under `frozen_r2/`; these files preserve William's original wording and corrections.
- `inputs/`: both original ZIPs, unchanged.
- `TRANSFER_VALIDATION.json`, `HANDOFF_MANIFEST.json`, and `verify_handoff.py`: transfer integrity only, not new mathematical verification.
- `COMMANDS.md`: checked command shapes; resolve placeholders to real paths and fresh outputs.

Frozen input ZIP:

```text
RCF01-portable-r2.zip
f33d4dfa04b4451dc3b847bd06121c9a0d1601413939e765c8e42f954102926c
```

Prior review ZIP:

```text
RCF01-R2-REVIEW-03.zip
f873e92239dd7739b38615622fb1e6f4dfb0bb0ade0d694c92de6f74257f6e73
```

Identify the actual authorized workspace, applicable instructions, Python environment, and git HEAD/status if available. The last reported local path was `research/core-recovery-r2`, with no commit; that is a locator, not evidence of the current checkout. Do not assume it still points to these exact bytes.

Keep the supplied handoff read-only. Create a fresh, separate work directory, for example `research/core-recovery-r2-codex-c1/`, outside the handoff and all frozen source/export trees. Copy the frozen portable tree there for executions and changes. Never overwrite an existing directory, discard uncommitted work, reset a checkout, or apply the patch directly to the historical input.

No commit, push, merge, publication, paper-source modification, package installation, remote upload, paid compute, secret access, held-out evaluator access, or restart of unrelated lanes is authorized. Use the existing environment and packaged dependencies. Missing original donor trees remain unavailable; do not search unrelated personal files or rebuild an archive to disguise their absence.

## 3. Read the meanings before judging the implementation

Read these focused sources, without an unbounded archive scan:

1. `recovered_sources/PRESTIGE-AND-NUMBER-OPERATIONS.md`: the original Prestige One corrections, acquired usable knowledge, finite fiving, and FIVE_IS_SAFE/Double-Stamp sections. Also inspect the approximate grouping and unsettled taxonomy boundaries.
2. `recovered_sources/CUBES-AND-PI-CURVES.md`: finite formula representation, ambiguity/kernel distinctions, and original abduction wording. Broader curve material remains registered, not a new implementation task.
3. `frozen_r2/research/core-recovery-01/CONCEPT_REGISTER.source.md`, `CONCEPT_REGISTER.md`, and `CONCEPT_REGISTER.json`.
4. `frozen_r2/research/core-recovery-01/FORMAL_BRIDGE_NOTE.md`.
5. The current envelope `PROOFS.md`, `PROTOCOL.json`, source and checker under `frozen_r2/experiments/core_recovery_bridge_01_r2/`, plus `frozen_r2/rprm/core.py` where used.
6. `frozen_r2/research/core-recovery-r2/RETURN_TO_WILLIAM_R2.md` and `GUARD_CORRECTIONS.md`.
7. `review_r2/REVIEW.md`, `CARRY_FORWARD.md`, patch, probes, and the receipts relevant to the claims you verify. `INTEGRATE_RUNNER_GUARD.md` is supporting context superseded procedurally by this assignment.

Preserve these semantic constraints:

- Prestige One includes relationship/access, earned task-relative reuse, retained construction, and a real reopening route. It is not social prestige, a literal-integer trick, merely a hash, or merely nesting depth.
- This prototype realizes an **exact finite reuse branch**. It does not exhaust the prestige lifecycle or the approximate-regrouping proposal. Construction depth, winding, uncertainty, and cost are different quantities.
- Finite fiving, FIVE_IS_SAFE, and FIVE.future are separately typed. C10 half-exchange is one realization, not the entire source concept. A finite return does not erase strong winding.
- FIVE_IS_SAFE is a type-finding source anchor. Dwell permissions in this carrier are supplied process rules, not a theorem about unrestricted physical safety.
- A unique answer/retained summary need not identify a unique complete law. Invalid backing does not imply an empty mathematical candidate family. B6's disabled dwell does not imply B6 is nonexistent.
- Preserve all 13 registered IDs and their meanings, source anchors, evidence grades, and unformalized remainder. Do not invent a third prestige species or an inverse-number dictionary.

## 4. Independent core review — focused, but real

The prior review accepts envelope 28/28 and starter 12/12, plus targeted API checks. Treat those as prior evidence, not a substitute for your own inspection.

First verify source identities and replay the unmodified baseline from a fresh copy with only packaged imports. Include the starter in the actual mathematical replay; exercise explicit skipping separately as a narrower runner-scope control. Preserve full child receipts, stdout/stderr, command, environment, hashes, exit codes, and aggregate verdict. Clear inherited `PYTHONPATH`/`PYTHONHOME` when needed to avoid accidental workspace imports; do not modify the user's global environment.

Then inspect the short proofs and actual production APIs. Reuse the supplied reviewer probes, but add a small independently derived direct-table calculation or proof check rather than only repeating their expected fields. Focus on these load-bearing issues:

1. Seven low-degree coefficients (C2) support exact retained pointwise addition and multiplication on rational-valued Boolean-cube laws. Boolean reduction is used; addition is over Q, not XOR. Omitted-value reads are not hidden in hot arithmetic.
2. Build `p=(h*x)*y`, then `s=p+p=2hxy` through the public API. The product remains Boolean-valued; the sum lifts to `rational_cube` although its hot C2 summary is all zeros. Reopening uses the composed result/recipe, not an operand or an assumed zero. With absent backing, report insufficiency; with valid backing, obtain the omitted value 2. Count recipe work separately from backing reads.
3. The input-family constructor does not accept a false Boolean claim. A unique hot result is not reported as a uniquely identified source law. Full symbolic candidate-family propagation is outside this API.
4. Named and generic certified maps enforce the same admission contract. The raw map that sends `h` to `hx` must not inherit a degree-1 guarantee or certified continuation. Coherent transport of both receiver and question remains a positive case and must not demand unnecessary data.
5. A needed backing file that is actually deleted, altered, or stale does not yield a fabricated exact reopened result. Independently sufficient hot answers need not fail solely because an unrelated cold route failed.
6. Dwell enabledness and state/event type remain distinct from vertex counts. The finite fiving adapter and retained winding do not get upgraded to the still-open Double-Stamp restart equivalence.
7. Review the retained-site proposition `H(S) ⊆ S` and least forward-closed repair in their stated arbitrary-law/retained-site setting. Do not turn finite checks into a universal proof, or this restricted minimality into a claim about every encoding, constrained family, or physical model.

Classify findings by consequence: directly invalidating a claimed capability, runtime evidence handling, documentation clarification, or deferred research. Repair only a reproduced, relevant defect in a successor. Nonblocking ideas go in the return; they do not trigger another project. Any mathematical-code change must be explicit, justified by a counterexample, separately identified, and independently retested; never silently change the frozen 28-case protocol or erase its passing evidence.

## 5. Inspect and close the runner-report gap

The original R2 runner passes its actual full run but previously accepted a top-level PASS without adequate case records. Reproduce the supplied eight report scenarios through the real runner in disposable copies: valid, absent results, empty results, failed case beneath PASS, missing ID, duplicate ID, unexpected ID, and non-object JSON. The latter seven must not be accepted by a corrected runner.

These are **fault-injected reporting fixtures**, not additional mathematical runs. Keep their receipts and claims separate from real envelope/starter execution. A child crash is not automatically a successful expected coverage rejection. Inspect both child and aggregate reason/status, and verify JSON, printed verdict, and exit code agree.

Review these files before applying anything:

```text
review_r2/patch/runner_receipt_validation.patch
review_r2/make_runner_candidate.py
review_r2/review_runner_receipts.py
frozen_r2/research/core-recovery-r2/check_runner.py
```

The proposed minimal patch validates object shape, nonempty typed case rows, all-case success, and exact unique case IDs from the declared protocol, not the emitted rows. It also keeps the synthetic runner fixtures schema-valid. Inspect edge cases within that contract; do not assume the supplied patch is correct merely because it has receipts.

Expected unpatched root runner SHA-256:

```text
46ef570e0cef28b41fd735985e5aa72cf6a41af42e93913118c686551e9239da
```

The helper can create a separate hash-pinned candidate and diff; it is not an upstream release tool. Inspect its source and manifest changes before use. If the actual local runner already has an equivalent repair, compare it and test it rather than duplicating the patch. A mismatch requires explicit reconciliation, not forcing a patch against different code.

Use the supplied repair if it stands up, or explain and make the smallest better repair. Normally only the two runtime copies, their runner fixtures, successor documentation, and export metadata need change. Give the runtime revision a new identity while preserving the unchanged mathematical source/protocol identities.

Verify: normal complete run; starter failure; export failure; wrong-reason crash; genuine expected coverage rejection; reorder; explicit skip scope; and all eight report scenarios. Do not solve this by building a scheduler, weakening the protocol, or generating PASS-shaped substitutes for actual mathematics.

## 6. Deliver a real successor and stop

Package the actual completed successor outside its own input tree. Keep one unambiguous active successor ZIP, not a pile of nested candidate exports. Retain source, proofs, protocol(s), exact imported dependencies, original recovery/register, historical failures, current evidence, relative links, and a new manifest. Preserve historical records as historical; never recreate a missing old receipt and call it original.

Extract that **final ZIP**, not merely the pre-export workspace, into a fresh directory. Replay its root entrypoint with only exported dependencies. Check the original recovery/register preservation, 13-entry semantic coverage, file identities, needed relative links, and runner regressions. Keep final external replay receipts outside the already-hashed ZIP to avoid a circular self-hash or changing the artifact after reporting its digest. Return those receipts separately or in a clearly identified evidence archive.

Return:

- `CODEX_REVIEW_AND_CLOSEOUT.md`: independent judgment on core math, public APIs, meanings, and runtime; actual new findings and fixes; evidence and limitations.
- One active successor ZIP, its SHA-256, entrypoint, and precise status. A path on your machine alone is not delivery; use the environment's actual artifact/attachment mechanism where available, and state an access limitation if unavailable rather than inventing a link.
- Actual commands/results and before/after diff, with mathematical replay, reused historical records, and synthetic runner fixtures clearly separated.
- `CARRY_FORWARD_CODEX.md`: a self-contained account of the preserved concepts, exact demonstrated capabilities, operating conditions, source/evidence locations, and open scope. Do not reduce the work to a list of test counts.

Use a disposition such as ACCEPTED_WITHIN_SCOPE, CORRECTED_AND_REVERIFIED, or BLOCKED_WITH_REPRODUCER, and explain it. Do not manufacture a positive verdict. If an environment limitation prevents one required replay, complete the review possible from available bytes and clearly mark that replay NOT_RUN.

Fiving splice ↔ Double-Stamp A5 restart remains OPEN unless a separately authorized research task later establishes it. Deferred IDs remain NOT_RUN. No new paper placement decision, performance claim, physical result, or universal compression claim is part of this closeout.

**Complete this bounded second review and runtime integration, return the usable artifacts, then stop.**
