# RCF01-R2 review and tested runtime closeout

Start with **REVIEW.md**. The submitted mathematical/API repairs are accepted. One runner-only receipt-validation gap is demonstrated, with an implementation patch and before/after tests.

- `INTEGRATE_RUNNER_GUARD.md`: bounded integration handoff; no new recovery or mathematical study.
- `CARRY_FORWARD.md`: concise rebrief text with evidence boundaries.
- `patch/runner_receipt_validation.patch`: changes the runner copies and synthetic runner fixtures only.
- `make_runner_candidate.py`: creates a separate, hash-pinned reviewer candidate; does not overwrite the supplied R2 package.
- `independent_api_checks.py`: independent exact arithmetic/map/type/dependency checks.
- `review_runner_receipts.py`: actual runner exercised with explicit fast receipt fixtures; not mathematical execution.
- `submitted/`: unchanged copies of relevant supplied notes/source for reference.
- `results/replay/`: completed unmodified R2 replay.
- `results/candidate_replay_02/`: completed reviewer-candidate replay.
- `results/runner_receipt_faults_extended.json` and `candidate_runner_receipts_extended.json`: eight before/after receipt scenarios.
- `results/interrupted_attempt.json`: explains the incomplete earlier tool-interrupted attempt. Partial receipts in `results/candidate_replay/` are not counted as completion.

The official input ZIP is the user attachment `RCF01-portable-r2.zip`, SHA-256 `f33d4dfa04b4451dc3b847bd06121c9a0d1601413939e765c8e42f954102926c`. This review archive is not a replacement release and intentionally does not bundle another competing active R2 ZIP.

## Reproduce

Extract the supplied R2 ZIP to a fresh directory. Use existing Python, standard library only. Clear PYTHONPATH/PYTHONHOME for a clean-room replay. Choose new work/output paths on each invocation.

```text
python -B <R2>/run_portable.py --output-dir <fresh-original-run>
python -B independent_api_checks.py --package <R2> --work <fresh-api-work> --output <fresh-api.json>
python -B review_runner_receipts.py --package <R2> --replay <fresh-original-run> --work <fresh-fault-work> --output <fresh-faults.json>
```

The last command is expected to return 2 for unmodified R2, demonstrating the gap. It uses copied receipts as explicit aggregation fixtures and does not run mathematical cases.

```text
python -B make_runner_candidate.py --package <R2> --candidate <fresh-candidate> --patch-output <fresh-patch.diff>
python -B <fresh-candidate>/run_portable.py --output-dir <fresh-candidate-run>
python -B <fresh-candidate>/research/core-recovery-r2/check_runner.py --package <fresh-candidate> --output-dir <fresh-runner-controls>
python -B review_runner_receipts.py --package <fresh-candidate> --replay <fresh-original-run> --work <fresh-candidate-fault-work> --output <fresh-candidate-faults.json>
```

All four candidate commands passed in this review. Candidate math implementation/protocol bytes are unchanged. File hashes and scenario receipts provide traceability, not a universal proof of program correctness. Do not count fixture rows as extra mathematical evidence or ordinary repeated runs as new scientific systems.
