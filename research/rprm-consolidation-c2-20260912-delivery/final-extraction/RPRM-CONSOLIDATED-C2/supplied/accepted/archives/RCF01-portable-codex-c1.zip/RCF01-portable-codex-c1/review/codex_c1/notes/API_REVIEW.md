# Independent finite API review

12 September 2026. Disposition: **CORRECTED_AND_REVERIFIED** for the newly
reproduced coherent-transport admission defect; the reviewed finite arithmetic
and valid-map capabilities remain accepted within their declared scope.

This is the independent API review lane. The coordinating closeout owns the
runner repair, complete envelope/starter replay, final ZIP and external replay.
This note does not substitute these development checks for those obligations.

## Material and execution identity

The supplied handoff was read-only. The initial execution copy was
`../work/api_independent`, copied fresh from
`../RCF01-CODEX-HANDOFF-01/frozen_r2`. The post-test complete tree comparison
found the same 115 files and bytes, with no additions, deletions or changes;
see `../evidence/independent_api/copy_identity.json`. Every backing mutation
occurred in a newly created evidence work directory, outside either package.

The source inspection covered the actual envelope implementation and checker,
its `PROOFS.md`, the `rprm.core` fiber/quotient code used by that implementation,
the prior reviewer's `independent_api_checks.py`, and the R1 status correction
note. This lane wrote no production code. The coordinator applied the isolated
transport validation repair and supplied `../work/successor` for retesting.

| Byte identity | SHA-256 |
|---|---|
| Frozen R2 envelope implementation | `bebf2c25d26f2ecf92e3366082aaf38f4d379e18ac06ea0f1d9294ecc64ee3a8` |
| C1 repaired envelope implementation | `e5ad46b6a8dc863b19f41a279ffeed882dad8ad6670a644fc4b3c71bebe59d68` |
| Imported packaged `rprm/core.py` | `a461bbeccd141caa10f3583b5cdb5c083d7032dbbd6793dd34a849efc69f3f0b` |
| New independent direct-table script | `efa49016df595e9048a9356a47c7a88df4d0df7e06ab88ca994fb85ec8b8595c` |
| Unchanged prior reviewer's reused script | `0a43dcb07efb21c9d4cce6b657130ee6fde8c9e3d183bec5e0a7ebbbf473a971` |

The C1 implementation retains the R2 file location and existing envelope
serialization version for portable compatibility. Its changed source identity
must be described as C1 and must not be called byte-identical R2 mathematics.
The change is an input guard; arithmetic and valid-map behavior are unchanged.

Execution used existing Python 3.14.5 on Windows. The final independent baseline
and successor checks used `-I -B -S`, removed `PYTHONPATH` and `PYTHONHOME` from
each child environment, and checked that `rprm.core` came from the selected
package. `-S` avoids site initialization; the initial `-I -B` receipts are also
retained transparently. No installation or network access was needed. Repo HEAD
was `9b5e132ee36334311f125027c2a719563890a3c1`; git's ordinary status was clean
(the artifact directory is ignored, so this is not evidence that artifacts do
not exist).

## Contract and independent method

The carrier is the eight Boolean coordinate sites `(h,x,y)`, with mask order
`h+2x+4y`, and exact rational-valued laws. Equality is exact rational equality
at each named site. The retained receiver reads the seven sites other than
`(1,1,1)`, equivalently the seven multilinear coefficients of degree at most
two. Arithmetic receives two envelopes and returns the retained output of
pointwise rational addition or multiplication. A newly requested omitted-site
read or fixed-receiver map may require a retained construction recipe and valid
backing. A transported receiver asks a different, explicitly moved question.

The new `independent_direct_api.py` computes truth tables directly from
coordinate formulas. It reconstructs expected coefficients by triangular
interpolation of the monomial evaluation matrix, without calling production
Möbius, zeta, compact, or checker routines for expected answers. Public outputs
are compared against these independently computed full tables. API status and
meter fields are inspected only for their own operational promises.

The source argument for hot multiplication is sound at this scope: restriction
to retained sites preserves pointwise arithmetic. Equivalently, under Boolean
reduction, multiplication combines monomial supports by union, so an omitted
three-coordinate term cannot affect a coefficient of smaller support. The
restriction is a surjective algebra homomorphism with a kernel, rather than a
canonical inclusion of the seven-site algebra into the eight-site one. These
written observations and the finite checks remain separate evidence grades.

## Tested finite assertions

The same nine groups passed on both frozen R2 and repaired C1, with **317
assertions** per run:

1. Three explicit rational-law pairs produce six complete eight-site addition
   and multiplication tables agreeing with independent formulas and
   interpolation. Negative and fractional values are included. `h*h=h`
   explicitly checks Boolean reduction; `h+h=2h` distinguishes Q-addition from
   XOR. All six arithmetic operations perform zero backing reads.
2. Public `p=(h*x)*y` and `s=p+p` give Boolean `p`, rational `s`, degree bound
   three, and zero retained coefficients. The backed `s` reopens to omitted
   value **2**, and its h-flip reads 2 at mask 6. With no backing, neither
   operation invents a value. Construction accounting records three recipe
   nodes and zero backing reads on the backed hot chain; reopening this sum
   performs six leaf reads because the recipe contains both uses of `p`.
3. Boolean promotion rejects five concrete malformed declarations: `-1`,
   `1/2`, or `2` at selected sites, and Python Boolean/float entries. The
   checker is an admission guard on the full supplied input table.
4. The zero-C2 Boolean source fiber is exactly `{0,hxy}`. Independent arithmetic
   distinguishes the complete readout family `{0,2}` for one selected source
   added to itself from `{0,1,2}` for two independent source choices. The
   rational source family is `{q*hxy : q in Q}`. `ONE/EXACT` from `add_units`
   identifies the retained output, not a unique complete law.
5. Ten named coordinate maps under both full and narrow contracts give the
   same admission decision through named and generic certified APIs. Their
   admitted seven-site outputs agree with independently constructed pullbacks.
6. The raw map `(h,x,y) -> (hx,x,y)` actually changes `h` into degree-two `hx`.
   The certified path refuses it. The raw helper returns the correct retained
   values, unsets its degree bound, retains only `read_admitted`, and refuses
   certified arithmetic/flip continuations.
7. Unbacked coherent h-flip transport returns the exact moved receiver
   `(0,1,2,3,4,5,7)` and its expected values with zero backing reads.
8. Needed backing is physically deleted, byte-tampered, or changed to a stale
   version. Every case refuses an exact reopened answer. The stale-version
   fixture binds the actual changed bytes to their actual digest, reaching the
   version guard beyond ordinary hash mismatch. Independently sufficient hot
   reads and zero clamps remain exact with no extra backing reads.
9. The declared A5 -> B6 -> C7 -> A5 sequence preserves state/event distinctions
   and dwell `[true,false,true]`; A5 and B6 collide at three vertex orbits.
   Twelve selected lifted winding states retain `(w+1,h,r)` after two steps;
   all 40 finite adapter inputs commute. This does not establish a fiving-splice
   to Double-Stamp restart equivalence or a physical safety statement.

The unchanged prior reviewer probe also passed all five groups in a fresh C1
`-I -B -S` run, including its 96 composed-operation reference steps. That is a
fresh replay of an attributed prior probe, not a new independently authored
test design or donor replay.

## New defect, minimal repair, and independent retest

**API admission defect, reproduced:** frozen
`prestige_envelope.py:692`, `coherent_transport`, validated map length but not
site types/range. With an unbacked `h` envelope, maps `(-1,)*8` and `(8,)*8`
returned `ONE/EXACT` with an empty tuple. Both leave the cube. The certified
and raw map interfaces rejected those same maps. This is not a counterexample
to the theorem quantified over valid `H:X->X`; it is a public boundary failing
to enforce that premise.

The independently reviewed minimal repair invokes the existing
`_validate_site_map(mapping)` at the start of coherent transport and returns
its rejection before computing the receiver or reopening a dependency. It
uses the existing public map admission convention (`NONE/UNSUPPORTED`) for
malformed length/type/range, instead of treating that tag as an empty
mathematical source family. It changes no rational arithmetic or valid map.

The revised `independent_api_boundaries.py --expect-transport-validation`
verified seven malformed cases: lengths 7 and 9, -1 and 8 addresses, and
Boolean, float and string entries. All reject without a backing read. The
valid constant map `(7,)*8` still returns an exact empty moved receiver, since
its preimage of the retained sites really is empty. Valid coherent transport
remains exact with absent, valid, actually deleted and actually tampered
backing. These guard tests are separate from the unchanged 28-case envelope
protocol. The original defect report and original reproducer bytes remain
preserved in `boundary_results.json` and
`independent_api_boundaries_baseline.py`.

## Explicit remaining limits and status meanings

- **Unbacked affine flip:** the public API does not currently use a known
  degree-one bound to unlock fixed-receiver flips. It conservatively returns
  `MANY/REOPEN_REQUIRED` even for unbacked `h`. The checker demonstrates affine
  recovery by a separate manual completion. This is narrower implementation
  coverage, not a failed arithmetic theorem or a newly promised capability.
- **Coherent transport reads:** when backing exists, the implementation tries
  reopening before using its sufficient hot fallback. Identity transport read
  one valid file; deleted/tampered-file cases attempted one read, recorded one
  invalidation, then still returned the exact retained answer. Exact coherent
  answers do not require successful backing, but zero cold attempts cannot be
  promised for an envelope with a route. The minimal admission repair preserves
  this behavior; no performance optimization is claimed.
- **Legacy `MANY` label:** R1 `STATUS_CORRECTIONS.md` describes absent backing as
  `OPEN/REOPEN_REQUIRED`, while the actual R2/C1 code returns
  `MANY/REOPEN_REQUIRED` and `value=None`. This is an explicit documentation/API
  discrepancy. Treat it as an admitted operation with insufficient retained
  information. It is not an enumerated candidate family and must not be
  promoted to an API-supplied complete `MANY(family)` object. Deleted backing
  uses `OPEN/UNRESOLVED`; stale or tampered backing uses
  `NONE/INVALID_DEPENDENCY` for failed backing validation, not mathematical
  emptiness. Changing this legacy status would be a separate API contract
  revision; it was not needed to repair the malformed transport guard.
- Construction depth, recipe work, winding, family ambiguity and backing cost
  remain different quantities. No full prestige lifecycle, universal
  compression, runtime speed, physical law or unrestricted safety result
  follows. Full Q candidate-family propagation and fiving/Double-Stamp restart
  equivalence remain outside this API; the latter remains OPEN.

## Receipts and reproduction

All paths below are relative to `../evidence/independent_api/`:

| Receipt prefix | Meaning | Outcome |
|---|---|---|
| `baseline_stdlib` | New direct suite on unchanged frozen copy | PASS, 9 groups / 317 assertions, exit 0 |
| `baseline_boundary_stdlib` | Original admission defect and unchanged scope limits | OBSERVATIONS_REPRODUCED, exit 0 |
| `successor_direct` | Identical direct suite on repaired source | PASS, 9 groups / 317 assertions, exit 0 |
| `successor_boundary` | Repaired admission, hostile and valid controls | OBSERVATIONS_REPRODUCED, exit 0 |
| `successor_reused_prior` | Attributed prior probe on repaired source | PASS, 5 groups, exit 0 |

Each prefix has complete `_results.json`, `_stdout.log`, `_stderr.log`, and
`_invocation.json`; invocation records the exact command, child cwd, environment
controls, exit status, probe digest and output digests. Stderr was empty for
every listed run. Backing fixtures and actual mutation snapshots are retained
in the corresponding `_work` directories. The earlier `direct`, `boundary`
and `reused_prior` receipts preserve the initial runs separately.

The reusable script interface is:

```text
python -I -B -S independent_direct_api.py --package PACKAGE --work FRESH_WORK --output NEW_JSON
python -I -B -S independent_api_boundaries.py --package PACKAGE --work FRESH_WORK --output NEW_JSON --expect-transport-validation
```

Use absolute paths and clear `PYTHONPATH`/`PYTHONHOME` in the child environment
as recorded by the invocation files. The scripts refuse existing work/output
paths. Omit `--expect-transport-validation` only to reproduce the original
baseline acceptance defect; its report explicitly identifies that expectation.
