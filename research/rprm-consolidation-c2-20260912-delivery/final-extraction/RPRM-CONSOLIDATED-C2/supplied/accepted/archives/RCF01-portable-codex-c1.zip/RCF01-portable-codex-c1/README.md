# RCF01-portable-codex-c1

**CORRECTED_AND_REVERIFIED within scope.** This is the one active successor
of the frozen R2 package. Root entrypoint: `run_portable.py`.

C1 integrates the independently reviewed runner-report guard and one small
coherent-transport site-map admission fix. The algebra, checker, proofs and
28-case R2 protocol are unchanged; the C1 source hash is explicit in
`SUCCESSOR.json` and the manifest. The R2 implementation directory name is
retained for portable path compatibility.

- [Independent review and closeout](CODEX_REVIEW_AND_CLOSEOUT.md)
- [Concepts, capability and guarantee boundary](CARRY_FORWARD_CODEX.md)
- [Replay commands](REPLAY_COMMANDS.md)
- [Detailed public API review](review/codex_c1/notes/API_REVIEW.md)
- [Independent mathematical review](review/codex_c1/notes/MATH_REVIEW.md)
- [Original meanings review](review/codex_c1/notes/CONCEPT_REVIEW.md)

Use the existing Python; no installation is needed. Keep outputs outside the
extraction and choose a new output directory each time:

```text
python -I -B run_portable.py --output-dir ../c1_replay
python -I -B verify_successor.py --root . --output ../c1_integrity.json
```

The normal runner includes the starter. `--skip-starter` explicitly narrows
the scope. The final ZIP digest and actual final-extraction replay evidence
are supplied separately as `FINAL_EXPORT_REPLAY.md` and an evidence archive;
they are not embedded inside the ZIP they hash.

All thirteen concepts and historical results remain preserved. The original
R2 files can be reconstructed exactly using `restore_r2.py` as documented in
REPLAY_COMMANDS. Replaced files are retained in `history/r2_runtime/`; all
other R2 files remain at their inherited paths. `history/prior_r2_review/`
is attributed prior evidence. Original `CONTENTS.md`, research return notes,
embedded absolute paths and older prompts describe their historical scope,
not the active C1 release or further jobs. Current evidence is under
`review/codex_c1/evidence/`, with synthetic fixtures explicitly separated.

Fiving splice / Double-Stamp restart remains OPEN. Deferred concepts remain
NOT_RUN. This closeout does not authorize further research or publication.
