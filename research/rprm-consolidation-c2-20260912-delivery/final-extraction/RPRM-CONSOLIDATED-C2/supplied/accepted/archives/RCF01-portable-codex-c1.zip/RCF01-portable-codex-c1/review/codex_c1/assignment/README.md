These files record the completed Codex C1 assignment. They are provenance, not new instructions to restart this task.
