# Replay commands

Run from the extracted successor root using the existing Python. Choose fresh
output paths outside that root for every command. No installation is required.

The root runner's normal scope includes the 12-case starter. `--skip-starter`
is an explicit narrower scope and is tested separately with runner fixtures.

```text
python -I -B run_portable.py --output-dir ../c1_real_replay
python -I -B verify_successor.py --root . --output ../c1_integrity.json
python -I -B -S review/codex_c1/notes/independent_direct_api.py --package . --work ../c1_api_work --output ../c1_api.json
python -I -B -S review/codex_c1/notes/independent_api_boundaries.py --package . --work ../c1_boundary_work --output ../c1_boundary.json --expect-transport-validation
python -I -B research/core-recovery-r2/check_runner.py --package . --output-dir ../c1_runner_controls
python -I -B history/prior_r2_review/review_runner_receipts.py --package . --replay ../c1_real_replay --work ../c1_receipt_work --output ../c1_receipts.json
python -I -B review/codex_c1/notes/guard_edges.py --package . --work ../c1_guard_work --output ../c1_guards.json
python -I -B -S review/codex_c1/notes/independent_math_calculation.py --output ../c1_math_calculation.json
```

For task-local environment clearing and exact parent command/stdout/stderr
records, wrap an invocation with the included logger. It removes PYTHONPATH
and PYTHONHOME for the child only, disables user-site and bytecode writes,
and enables UTF-8. It makes no global environment change.

```text
python -I -B review/codex_c1/notes/run_logged.py --log ../c1_execution_log --cwd . -- run_portable.py --output-dir ../c1_logged_replay
```

All actual review invocations and exits are preserved in
`review/codex_c1/evidence/`. Original and amended historical replay directories
have their own hashes and scope; do not infer a fresh run from a retained PASS.
Runner fixtures deliberately replace children and are not math replays.

The original R2 is reconstructible exactly from retained bytes without an
external donor, installation, or network dependency:

```text
python -I -B review/codex_c1/notes/restore_r2.py --package . --output ../frozen_r2_restored
```

Then run the restored root with new output paths. The original boundary probe
`review/codex_c1/notes/independent_api_boundaries_baseline.py` expects the known
malformed-map defect and records it as an observation. The report-fixture
harness should exit 2 with `RECEIPT_VALIDATION_GAP_REPRODUCED` against that R2.

The final delivered ZIP is immutable. Its separately supplied final-export
evidence archive records the actual commands run against its fresh extraction,
ZIP SHA-256, all raw final receipts, and preservation checks. These external
records are deliberately excluded from the ZIP they identify.
