"""Task-local, explicit portable assembly; never updates a frozen input."""
import difflib
import hashlib
import json
import shutil
from pathlib import Path

r=Path(__file__).resolve().parents[1]
h=r/'RCF01-CODEX-HANDOFF-01'; b=r/'work/baseline'; s=r/'work/successor'
for name in ('baseline_run','successor_run','c1_run'):
    report=json.loads((r/'evidence'/name/'portable_summary.json').read_text())
    assert report['status']=='PASS' and report['starter_included']
assert json.loads((r/'evidence/c1_run/portable_summary.json').read_text())['envelope_source_sha256']=='e5ad46b6a8dc863b19f41a279ffeed882dad8ad6670a644fc4b3c71bebe59d68'
changed=('run_portable.py','research/core-recovery-r2/run_portable.py',
         'research/core-recovery-r2/check_runner.py',
         'experiments/core_recovery_bridge_01_r2/prestige_envelope.py')
for rel in (*changed,'README.md','MANIFEST.json'):
    target=s/'history/r2_runtime'/rel
    target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(b/rel,target)
shutil.copytree(h/'review_r2',s/'history/prior_r2_review')
shutil.copytree(h/'recovered_sources',s/'recovered_sources')
assignment=s/'review/codex_c1/assignment'; assignment.mkdir(parents=True)
for rel in ('CODEX_START_HERE.md','CURRENT_STATE.md','COMMANDS.md'):
    shutil.copy2(h/rel,assignment/rel)
(assignment/'README.md').write_text('These files record the completed Codex C1 assignment. They are provenance, not new instructions to restart this task.\n',encoding='utf-8')
diff=''.join(''.join(difflib.unified_diff((b/rel).read_text().splitlines(True),(s/rel).read_text().splitlines(True),fromfile='frozen_r2/'+rel,tofile='codex_c1/'+rel)) for rel in changed)
(r/'evidence/final_changes.diff').write_bytes(diff.encode())
shutil.copytree(r/'evidence',s/'review/codex_c1/evidence')
for origin,name in (('baseline_receipt_fixtures','baseline'),('successor_receipt_fixtures','successor'),('successor_controls','controls')):
    shutil.copytree(r/'work'/origin,s/'review/codex_c1/evidence/runner_fixtures'/name,
                    ignore=shutil.ignore_patterns('package'))
shutil.copytree(r/'notes',s/'review/codex_c1/notes')
for name in ('CODEX_REVIEW_AND_CLOSEOUT.md','CARRY_FORWARD_CODEX.md','REPLAY_COMMANDS.md','verify_successor.py'):
    shutil.copy2(r/'notes'/name,s/name)
(s/'README.md').write_text('''# RCF01-portable-codex-c1

**CORRECTED_AND_REVERIFIED within scope.** This is the one active successor
of the frozen R2 package. Root entrypoint: `run_portable.py`.

C1 integrates the independently reviewed runner-report guard and one small
coherent-transport site-map admission fix. The algebra, checker, proofs and
28-case R2 protocol are unchanged; the C1 source hash is explicit in
`SUCCESSOR.json` and the manifest. The R2 implementation directory name is
retained for portable path compatibility.

- [Independent review and closeout](CODEX_REVIEW_AND_CLOSEOUT.md)
- [Concepts, capability and guarantee boundary](CARRY_FORWARD_CODEX.md)
- [Replay commands](REPLAY_COMMANDS.md)
- [Detailed public API review](review/codex_c1/notes/API_REVIEW.md)
- [Independent mathematical review](review/codex_c1/notes/MATH_REVIEW.md)
- [Original meanings review](review/codex_c1/notes/CONCEPT_REVIEW.md)

Use the existing Python; no installation is needed. Keep outputs outside the
extraction and choose a new output directory each time:

```text
python -I -B run_portable.py --output-dir ../c1_replay
python -I -B verify_successor.py --root . --output ../c1_integrity.json
```

The normal runner includes the starter. `--skip-starter` explicitly narrows
the scope. The final ZIP digest and actual final-extraction replay evidence
are supplied separately as `FINAL_EXPORT_REPLAY.md` and an evidence archive;
they are not embedded inside the ZIP they hash.

All thirteen concepts and historical results remain preserved. The original
R2 files can be reconstructed exactly using `restore_r2.py` as documented in
REPLAY_COMMANDS. Replaced files are retained in `history/r2_runtime/`; all
other R2 files remain at their inherited paths. `history/prior_r2_review/`
is attributed prior evidence. Original `CONTENTS.md`, research return notes,
embedded absolute paths and older prompts describe their historical scope,
not the active C1 release or further jobs. Current evidence is under
`review/codex_c1/evidence/`, with synthetic fixtures explicitly separated.

Fiving splice / Double-Stamp restart remains OPEN. Deferred concepts remain
NOT_RUN. This closeout does not authorize further research or publication.
''',encoding='utf-8')
identity={'package':'RCF01-portable-codex-c1','disposition':'CORRECTED_AND_REVERIFIED',
 'parent_zip_sha256':'f33d4dfa04b4451dc3b847bd06121c9a0d1601413939e765c8e42f954102926c',
 'runtime_revision':'CODEX_C1_RECEIPT_GUARD','api_revision':'CODEX_C1_COHERENT_MAP_ADMISSION',
 'mathematical_protocol':'RCF01-envelope-1-r2','protocol_changed':False,
 'core_algebra_changed':False,'envelope_source_changed':True,
 'production_changes':list(changed),'envelope_source_sha256':hashlib.sha256((s/changed[-1]).read_bytes()).hexdigest(),
 'workspace_head':'9b5e132ee36334311f125027c2a719563890a3c1','committed':False,
 'fiving_double_stamp_bridge':'OPEN','deferred_ids':['RCF-P2','RCF-P3','RCF-N1','RCF-PI1'],
 'donor_replay':'NOT_RUN: historical logs retained, original donor trees unavailable',
 'final_export_evidence':'External to immutable ZIP; see separately delivered FINAL_EXPORT_REPLAY.md',
 'not_retroactive_preregistration':True}
(s/'SUCCESSOR.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
files={}
for p in sorted(s.rglob('*')):
    if p.is_file() and p!=s/'MANIFEST.json':
        data=p.read_bytes(); files[p.relative_to(s).as_posix()]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
manifest={'package':identity['package'],'scope':'Exact portable C1 file inventory; not proof or authentication',
 'parent_manifest':'history/r2_runtime/MANIFEST.json','self_exclusion':'MANIFEST.json',
 'not_retroactive_preregistration':True,'files':files}
(s/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'assembled':str(s),'manifest_files':len(files),'identity':identity},indent=2))
