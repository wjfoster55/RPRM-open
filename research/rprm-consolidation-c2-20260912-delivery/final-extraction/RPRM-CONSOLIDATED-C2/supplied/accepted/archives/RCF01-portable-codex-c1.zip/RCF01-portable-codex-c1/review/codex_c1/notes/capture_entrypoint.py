"""Observe an unchanged root entrypoint; retain complete child stdout/stderr.

This wrapper changes no child command or result. It replaces subprocess.run
only to copy its already captured output before the inherited runner takes a
4000-character tail. This is an additional observed real replay; the final ZIP
also receives a direct, unwrapped root-entrypoint replay.
"""
import argparse
import hashlib
import json
import runpy
import subprocess
import sys
from pathlib import Path

p = argparse.ArgumentParser()
p.add_argument('--capture', type=Path, required=True)
p.add_argument('entrypoint', type=Path)
p.add_argument('args', nargs=argparse.REMAINDER)
a = p.parse_args()
a.capture.mkdir(parents=True, exist_ok=False)
original_run = subprocess.run
records = []

def observed_run(*args, **kwargs):
    proc = original_run(*args, **kwargs)
    stem = f'{len(records):02d}'
    rec = {'command': args[0] if args else kwargs.get('args'),
           'cwd': str(kwargs.get('cwd')), 'exit_code': proc.returncode}
    for stream in ('stdout', 'stderr'):
        value = getattr(proc, stream)
        data = value.encode('utf-8') if isinstance(value, str) else value or b''
        (a.capture/f'{stem}_{stream}.txt').write_bytes(data)
        rec[stream + '_bytes_utf8'] = len(data)
        rec[stream + '_sha256'] = hashlib.sha256(data).hexdigest()
    records.append(rec)
    (a.capture/'children.json').write_text(json.dumps(records, indent=2)+'\n', encoding='utf-8')
    return proc

subprocess.run = observed_run
sys.argv = [str(a.entrypoint), *a.args]
runpy.run_path(str(a.entrypoint), run_name='__main__')
