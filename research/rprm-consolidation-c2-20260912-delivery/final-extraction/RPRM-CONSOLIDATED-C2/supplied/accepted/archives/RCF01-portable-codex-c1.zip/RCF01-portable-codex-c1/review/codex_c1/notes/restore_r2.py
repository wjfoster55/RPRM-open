"""Materialize exactly the retained frozen R2 files into a new directory."""
import argparse
import hashlib
import json
from pathlib import Path

p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--package',type=Path,required=True)
p.add_argument('--output',type=Path,required=True)
a=p.parse_args()
manifest_path=a.package/'history/r2_runtime/MANIFEST.json'
manifest=json.loads(manifest_path.read_text(encoding='utf-8'))
a.output.mkdir(parents=True,exist_ok=False)
for rel,record in manifest['files'].items():
    file=a.package/rel
    if hashlib.sha256(file.read_bytes()).hexdigest()!=record['sha256']:
        file=a.package/'history/r2_runtime'/rel
    data=file.read_bytes()
    assert len(data)==record['bytes'] and hashlib.sha256(data).hexdigest()==record['sha256'],rel
    target=a.output/rel
    target.parent.mkdir(parents=True,exist_ok=True)
    target.write_bytes(data)
(a.output/'MANIFEST.json').write_bytes(manifest_path.read_bytes())
print(json.dumps({'status':'PASS','scope':'Exact R2 file reconstruction, no execution',
                  'files':len(manifest['files'])+1,'output':str(a.output.resolve())}))
