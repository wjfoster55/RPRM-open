# Command reference for Codex

These are command shapes, not a shell script. Resolve `<H>` to the absolute handoff root and `<W>` to a fresh work directory outside it; use the actual existing Python executable. Do not paste placeholders literally. Use new output directories for every invocation.

Review source and applicable workspace instructions before executing package code. These commands neither download dependencies nor modify a repository by themselves. Remove inherited PYTHONPATH/PYTHONHOME only in child-process environments where needed.

## Integrity and unmodified baseline

```text
python -B <H>/verify_handoff.py
```

Create `<W>/baseline` by copying the entire `<H>/frozen_r2` tree without changing its bytes. Then:

```text
python -B <W>/baseline/run_portable.py --output-dir <W>/baseline_run
python -B <H>/review_r2/independent_api_checks.py --package <W>/baseline --work <W>/api_work --output <W>/api.json
python -B <W>/baseline/research/core-recovery-r2/check_runner.py --package <W>/baseline --output-dir <W>/baseline_runner_controls
python -B <H>/review_r2/review_runner_receipts.py --package <W>/baseline --replay <W>/baseline_run --work <W>/original_receipt_work --output <W>/original_receipts.json
```

The last command should return 2 on unmodified R2 because it demonstrates the known acceptance gap. Inspect its actual scenario results; an unrelated crash is not a reproduced defect. It is a reporting harness using explicit fixtures, not a mathematical replay.

## Candidate, after independent patch inspection

```text
python -B <H>/review_r2/make_runner_candidate.py --package <W>/baseline --candidate <W>/candidate --patch-output <W>/candidate.patch
python -B <W>/candidate/run_portable.py --output-dir <W>/candidate_run
python -B <W>/candidate/research/core-recovery-r2/check_runner.py --package <W>/candidate --output-dir <W>/candidate_runner_controls
python -B <H>/review_r2/review_runner_receipts.py --package <W>/candidate --replay <W>/baseline_run --work <W>/candidate_receipt_work --output <W>/candidate_receipts.json
```

The helper creates a reviewer-labelled manifest. Inspect and update the successor's identity/ownership honestly when producing the Codex-reviewed export; do not relabel historical evidence or mistake the helper's output for an already published release.

The root `run_portable.py` is the portable execution entrypoint. The copy under `research/core-recovery-r2/` is retained runtime/build source, not an instruction to run it from a tree whose relative dependencies do not match.

## Final export

Export the completed successor outside its input tree. Extract the actual final ZIP into another new directory and repeat its root entrypoint with packaged imports only. Verify identities/links and run the relevant runtime probes against that extraction, not just the source checkout. Supply final external replay records without rewriting the ZIP after calculating its digest.

The existing exporter may assume the original repository layout. Inspect it before use; a small explicit portable export is preferable to pulling in unrelated local files or silently excluding dependencies. The active prompt defines preservation and deliverables.
