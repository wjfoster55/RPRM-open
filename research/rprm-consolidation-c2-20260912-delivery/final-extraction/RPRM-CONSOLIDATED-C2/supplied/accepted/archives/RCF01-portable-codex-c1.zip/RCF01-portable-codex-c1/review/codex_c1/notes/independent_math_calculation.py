#!/usr/bin/env python3
"""Reproduce the bounded independent mathematical calculation from MATH_REVIEW.

Standard library only. No production-module imports, cold artifacts, or
mathematical protocol changes. This is finite calculation evidence, separate
from the written proofs and the production replay.
"""

from __future__ import annotations

import argparse
import json
from fractions import Fraction as Q
from itertools import product
from pathlib import Path


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def calculate() -> dict:
    sites = tuple(range(8))
    mobius = tuple(
        tuple(
            Q((-1) ** (s.bit_count() - t.bit_count()))
            if (t & s) == t else Q(0)
            for t in sites
        )
        for s in sites
    )
    zeta = tuple(
        tuple(Q(1) if (t & s) == t else Q(0) for t in sites)
        for s in sites
    )

    def matrix_vector(matrix, vector):
        return tuple(
            sum((entry * value for entry, value in zip(row, vector)), Q(0))
            for row in matrix
        )

    require(
        all(
            sum(mobius[i][k] * zeta[k][j] for k in sites) == int(i == j)
            for i in sites for j in sites
        ),
        "Dense subset-transform inverse identity failed",
    )

    basis_product_pairs = 0
    for a, b in product(sites, repeat=2):
        coeff_a = tuple(Q(int(t == a)) for t in sites)
        coeff_b = tuple(Q(int(t == b)) for t in sites)
        table_a = matrix_vector(zeta, coeff_a)
        table_b = matrix_vector(zeta, coeff_b)
        actual = matrix_vector(
            mobius, tuple(x * y for x, y in zip(table_a, table_b))
        )[:7]
        predicted = tuple(
            Q(int(a < 7 and b < 7 and (a | b) == t))
            for t in range(7)
        )
        require(actual == predicted, f"Basis product mismatch at {(a, b)}")
        basis_product_pairs += 1

    # Independent carrier for the general retained-site proposition.
    finite_sites = tuple(range(3))
    subsets = [
        frozenset(i for i in finite_sites if mask >> i & 1)
        for mask in range(8)
    ]
    maps = list(product(finite_sites, repeat=3))
    laws = list(product((0, 1), repeat=3))
    criterion_checks = 0
    repair_checks = 0
    for retained in subsets:
        for mapping in maps:
            groups = {}
            for law in laws:
                summary = tuple(law[s] for s in sorted(retained))
                output = tuple(law[mapping[s]] for s in sorted(retained))
                groups.setdefault(summary, set()).add(output)
            descends = all(len(outputs) == 1 for outputs in groups.values())
            image_contained = all(mapping[s] in retained for s in retained)
            require(descends == image_contained, "Retained-site criterion failed")
            criterion_checks += 1

            repair = retained
            while True:
                next_repair = repair | frozenset(mapping[s] for s in repair)
                if next_repair == repair:
                    break
                repair = next_repair
            closed_supersets = [
                candidate for candidate in subsets
                if retained <= candidate
                and all(mapping[s] in candidate for s in candidate)
            ]
            require(
                repair == frozenset.intersection(*closed_supersets),
                "Forward repair differs from intersection of all closed supersets",
            )
            repair_checks += 1

    zero = (Q(0),) * 8
    hxy = (Q(0),) * 7 + (Q(1),)
    flip_h = tuple(s ^ 1 for s in sites)
    require(
        matrix_vector(mobius, zero)[:7] == matrix_vector(mobius, hxy)[:7],
        "Hostile pair did not agree on C2",
    )
    hostile_value = tuple(hxy[flip_h[s]] for s in sites)[6]
    require(hostile_value == 1, "Hostile pair did not separate at mask 6")

    return {
        "kind": "independent mathematical calculation; no production imports",
        "evidence_grade": "finite exact calculation, separate from written proof",
        "production_replay": False,
        "python_linear_transform_identity": True,
        "basis_product_pairs": basis_product_pairs,
        "retained_site_arbitrary_boolean_law_checks": criterion_checks,
        "least_forward_repair_checks": repair_checks,
        "hostile_flip_at_mask6": int(hostile_value),
        "status": "PASS",
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    try:
        result = calculate()
        exit_code = 0
    except Exception as error:
        result = {
            "kind": "independent mathematical calculation; no production imports",
            "status": "FAIL",
            "error_type": type(error).__name__,
            "error": str(error),
        }
        exit_code = 1
    serialized = json.dumps(result, indent=2, sort_keys=True) + "\n"
    with args.output.open("x", encoding="utf-8", newline="\n") as output:
        output.write(serialized)
    print(json.dumps(result, sort_keys=True))
    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
