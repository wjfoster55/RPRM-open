#!/usr/bin/env python3
"""Narrow API boundary observations, separate from accepted finite math tests."""
import argparse
import hashlib
import importlib.util
import json
import sys
from dataclasses import asdict
from pathlib import Path


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--package', type=Path, required=True)
    p.add_argument('--work', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--expect-transport-validation', action='store_true',
                   help='Require repaired length/type/range admission instead of baseline defect')
    args = p.parse_args()
    args.work.mkdir(parents=True, exist_ok=False)
    if args.output.exists():
        raise FileExistsError(args.output)
    source = args.package/'experiments/core_recovery_bridge_01_r2/prestige_envelope.py'
    spec = importlib.util.spec_from_file_location('api_boundary_envelope', source)
    e = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = e
    spec.loader.exec_module(e)
    hot = e.unit('h', family='boolean_cube', contract=e.FULL_CUBE_CONTRACT)
    affine_flip = e.apply_input_map(hot, 'flip_h')
    assert hot.degree_bound == 1 and affine_flip.status == 'REOPEN_REQUIRED'
    assert affine_flip.disposition == 'MANY' and affine_flip.value is None
    e.reset_meter()
    hot_transport = e.coherent_transport(hot, tuple(i^1 for i in range(8)))
    hot_meter = e.meter_snapshot()
    assert hot_transport.status == 'EXACT' and hot_meter['cold_reads'] == 0
    empty_receiver = e.coherent_transport(hot, (7,)*8)
    assert empty_receiver.status == 'EXACT' and empty_receiver.value == ()
    backed = e.unit('h', family='boolean_cube', contract=e.FULL_CUBE_CONTRACT,
                    cold_dir=args.work/'cold', name='transport')
    e.reset_meter()
    coherent = e.coherent_transport(backed, tuple(range(8)))
    valid_meter = e.meter_snapshot()
    assert coherent.status == 'EXACT' and valid_meter['cold_reads'] == 1
    Path(backed.cold_route).unlink()
    e.reset_meter()
    fallback = e.coherent_transport(backed, tuple(range(8)))
    fallback_meter = e.meter_snapshot()
    assert fallback.status == 'EXACT' and fallback.value == coherent.value
    assert fallback_meter['cold_reads'] == fallback_meter['invalidations'] == 1
    tampered = e.unit('h', family='boolean_cube', contract=e.FULL_CUBE_CONTRACT,
                     cold_dir=args.work/'cold', name='tampered_transport')
    Path(tampered.cold_route).write_bytes(b'actual corrupted backing bytes')
    e.reset_meter()
    tamper_fallback = e.coherent_transport(tampered, tuple(range(8)))
    tamper_meter = e.meter_snapshot()
    assert tamper_fallback.status == 'EXACT' and tamper_fallback.value == coherent.value
    assert tamper_meter['cold_reads'] == tamper_meter['invalidations'] == 1
    malformed = []
    mappings = [(-1,)*8, (8,)*8]
    if args.expect_transport_validation:
        mappings += [(0,)*7, (0,)*9, (0,)*7+(True,), (0,)*7+(1.0,), (0,)*7+('1',)]
    for mapping in mappings:
        e.reset_meter()
        result = e.coherent_transport(hot, mapping)
        generic = e.apply_fixed_receiver_map(hot, mapping)
        raw = e.apply_raw_site_map(hot, mapping)
        if args.expect_transport_validation:
            assert result.status == 'UNSUPPORTED' and result.disposition == 'NONE'
            assert result.value is None and e.METER.cold_reads == 0
        else:
            assert result.status == 'EXACT' and result.value == ()
        assert generic.status == raw.status == 'UNSUPPORTED'
        malformed.append({'mapping':mapping,'coherent_result':asdict(result),
                          'generic_status':generic.status,'raw_status':raw.status})
    report = {'status':'OBSERVATIONS_REPRODUCED',
              'scope':'Known valid-carrier limits and bounded malformed-map admission probes; separate from original mathematical protocol',
              'expect_transport_validation':args.expect_transport_validation,
              'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
              'affine_unbacked_flip':{'degree_bound':hot.degree_bound,'result':asdict(affine_flip)},
              'coherent_absent_backing':{'result':asdict(hot_transport),'meter':hot_meter},
              'valid_constant_7_empty_receiver':asdict(empty_receiver),
              'coherent_valid_backing':{'result':asdict(coherent),'meter':valid_meter},
              'coherent_deleted_backing':{'result':asdict(fallback),'meter':fallback_meter},
              'coherent_tampered_backing':{'result':asdict(tamper_fallback),'meter':tamper_meter},
              'malformed_map_results':malformed}
    text = json.dumps(report, indent=2, default=str)+'\n'
    args.output.write_text(text, encoding='utf-8')
    print(text,end='')


if __name__ == '__main__':
    main()
