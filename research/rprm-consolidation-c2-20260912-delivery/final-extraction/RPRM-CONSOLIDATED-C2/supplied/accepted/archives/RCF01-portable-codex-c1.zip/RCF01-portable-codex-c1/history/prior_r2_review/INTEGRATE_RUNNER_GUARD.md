# R2 runtime closeout — integrate the supplied guard, then stop

This is a runner-only integration note, not RCF01 recovery, a new mathematical experiment, or a new publication assignment.

## Accepted work

The attached R2 ZIP matches its advertised SHA-256. Independent full replay passes envelope 28/28 and starter 12/12. The output-family and generic-map repairs pass direct public-API checks, including the hidden composed sum, raw-map metadata, and physical backing corruption. The original five runner scenarios also pass. Preserve those results and all historical source/run bytes.

## Remaining defect and supplied implementation

The unmodified R2 runner still accepts a top-level PASS with absent/empty results, a contradictory failed case, or missing/duplicate/unexpected case IDs. A top-level JSON array crashes the aggregator rather than producing its structured FAIL. The actual mathematical runs were valid; this concerns defensive consumption of child receipts.

Use `patch/runner_receipt_validation.patch` as the proposed minimal repair. It updates the two runtime copies plus schema-valid runner-only fixtures. It does not alter the mathematical envelope, checker, proofs, 28-case protocol, or deferred research status.

The patch was tested here against all eight receipt fixtures, the five existing runner fixtures, and the full unmodified mathematical suite. See REVIEW.md and results. It is reviewer-owned work, not an already integrated upstream release.

## Integration boundary

Use the actual authorized workspace and applicable AGENTS.md. Do not assume HEAD, change frozen R2 bytes silently, commit, push, merge, install packages, publish, access evaluator data, or restart another research lane. Create a clearly named successor/runtime-closeout export. Keep the existing mathematical protocol identity since the mathematical cases are unchanged; give the runtime/export change its own identity.

The base runner SHA-256 is `46ef570e0cef28b41fd735985e5aa72cf6a41af42e93913118c686551e9239da`. Check it before applying a patch. If the local runner already contains an equivalent repair, inspect and test that implementation rather than duplicating it.

`make_runner_candidate.py` can create a separate candidate from the exact supplied portable tree. It refuses a mismatched source pin or an existing candidate directory. Do not treat its review-generated manifest as a historical manifest.

Perform one fresh package replay using only the export's dependencies. Retain the normal controls, explicit starter-skip scope, and the malformed-receipt regression cases. Refresh the export manifest and source identities honestly. Return the actual successor ZIP and a brief closeout naming the unchanged 28/12 mathematical coverage and the runner-only revision.

No generic scheduler, new uncertainty engine, extra application benchmark, forced fiving/Double-Stamp merger, or further formalization round is requested. The OPEN and NOT_RUN research entries remain unchanged. Stop after integration and portable verification.
