# RCF01 Codex C1 — independent review and closeout

12 September 2026. **CORRECTED_AND_REVERIFIED within the stated finite scope.** This review accepts the R2 algebra, composition and output-family repairs, integrates the supplied runner-report guard, and corrects one independently reproduced malformed-map admission defect. It does not reopen concept recovery or the deferred bridge.

The successor is **RCF01-portable-codex-c1**, entered through `run_portable.py`. The R2 directory name is retained for portable path compatibility. Its envelope implementation now has an explicitly identified C1 admission repair; the algebra, mathematical checker, written proofs and 28-case protocol are unchanged. Original module bytes and all historical results remain available. The actual released ZIP hash and fresh-extraction certification are in the separate `FINAL_EXPORT_REPLAY.md` and evidence archive, kept outside the ZIP to avoid changing or self-hashing that artifact.

## Authority and provenance

The user's transfer request and packet `CODEX_START_HERE.md` were the active assignment; `CURRENT_STATE.md` supplied context. Older Cursor prompts and integration notes were historical evidence. Applicable `C:/github/RPRM-open/AGENTS.md`, README and handbook were followed, using the RPRM math-lenses procedure within this packet only.

The workspace HEAD was `9b5e132ee36334311f125027c2a719563890a3c1`, initially clean. All work used newly created directories under `.artifacts/RCF01-CODEX-R3-20260912`; the directory's R3 working label is not the release identity. The supplied handoff, prior exports, tracked repository files and paper were not modified. No commit, push, merge, publication, installation, remote upload or other-project restart occurred.

| Input | SHA-256 |
|---|---|
| Supplied handoff ZIP | `f6dc91d1e9f1dea4b6eb2886b829713bf0b566da132c6f421fb09656808f0fa3` |
| Frozen R2 ZIP | `f33d4dfa04b4451dc3b847bd06121c9a0d1601413939e765c8e42f954102926c` |
| Prior R2 review ZIP | `f873e92239dd7739b38615622fb1e6f4dfb0bb0ade0d694c92de6f74257f6e73` |

Transfer verification checked 488 listed files. Both original manifests and exact expanded ZIP contents matched: 114 R2 manifest entries / 115 files and 353 prior-review entries / 354 files. All ten recovered-source files match the retained original recovery ZIP. These are byte-identity checks, not authentication of authorship or mathematical proofs. See [input preservation](review/codex_c1/evidence/input_preservation.json).

## Independent mathematical and semantic judgment

The carrier is the algebra of exact functions `{0,1}^3 -> Q`; equality is pointwise, with masks using h/x/y in bits 0/1/2. C2 retains seven low-degree coefficients, equivalently values on B2 = sites 0 through 6. The missing coefficient is the hxy interaction. Supplied arithmetic ports are two retained summaries; the receiver is the retained result of rational pointwise addition or multiplication.

Independently reconstructing the proof gives `(fg)_T = sum_(A union B=T) f_A g_B` after Boolean reduction. For retained T, both A and B are retained; no omitted term can contribute. This proves exact compact arithmetic on the declared carrier, without hidden omitted-value reads. The full rational source fiber is an affine line differing by `t*hxy`; a reached Boolean C2 fiber has two laws. One exact hot output is therefore not one uniquely recovered source law.

For arbitrary laws `f:X->Y` with at least two possible values, pullback by H descends to a fixed retained-site receiver S exactly when `H(S) subseteq S`. The necessity witness changes only a site outside S reached from inside S. Repeatedly adding map images yields the least forward-closed superset; induction proves both closure and leastness. This minimality is restricted to retained-site supersets and arbitrary laws. Constrained affine families can need less information; the API does not currently exploit their degree bound to unlock unbacked flips.

The public construction `p=(h*x)*y`, then `s=p+p`, was checked against independently derived eight-site tables. Both hot summaries are zero; p remains Boolean, s is rational, and valid composed backing recovers omitted value 2. Hot arithmetic performs zero backing reads; recipe construction and later reads are separately counted. False Boolean promotion is rejected. Raw h-to-hx maps lose degree/certification, named and generic certified maps share admission, and coherent transport of both question and coordinates remains exact with sufficient hot data.

Real backing deletion, tampering and staleness refuse fabricated reopened answers. Hot answers that are independently sufficient remain available. Dwell enabledness differs between state/event types even when vertex counts agree. Finite fiving retains r while exchanging halves; two fivings change strong winding despite display return. These are distinct carriers and process contracts.

The original concept sources were independently compared with all three registers. All 13 IDs, original meanings, source anchors and unformalized remainders survive. Prestige One remains earned relational access with retained construction and reopening, broader than this exact reuse branch. Approximate grouping and the wider lifecycle are not implemented by C2. Finite fiving, FIVE_IS_SAFE and FIVE.future retain distinct meanings. Cube interpolation, kernel ambiguity and abduction remain separate questions. [Carry-forward](CARRY_FORWARD_CODEX.md) preserves the usable capability and its source meaning in detail.

## Reproduced defects and minimal repairs

| Finding | Reproducer and consequence | C1 change |
|---|---|---|
| Runner accepts unsupported PASS claims | Actual R2 runner accepted absent/empty results, a failed row, and missing/duplicate/unexpected IDs; non-object JSON raised AttributeError with no aggregate summary. This invalidates those reports, not the complete genuine mathematical receipts. | Adopt the inspected patch: validate object shape, nonempty typed rows, every row PASS, and exact unique protocol IDs. Preserve consistent JSON/printed/exit verdicts. Update explicitly synthetic fixtures. |
| Coherent transport admits out-of-carrier maps | Public `coherent_transport(h, (-1,)*8)` and `(8,)*8` returned `ONE/EXACT` with empty value, although both other site-map helpers reject those indices. This is an input-admission defect outside the valid-map theorem. | Replace its length-only check with the existing `_validate_site_map` early return. No receiver, algebra or backing logic changes for valid maps. |

The second correction changes one production module by three lines replacing one line. Its independent regression rejects short/long maps, -1/8 sites, booleans, floats and strings. The valid `(7,)*8` map still gives an exact empty transported receiver. Valid coherent transport with absent, valid, deleted and tampered backing remains exact where hot information suffices. The existing refusal representation is `NONE/UNSUPPORTED`; it denotes rejected admission, not an empty source-law fiber.

The two runtime copies remain identical. [Complete before/after diff](review/codex_c1/evidence/final_changes.diff) identifies both repairs and the entrypoint label. The supplied patch matches the historical candidate after LF normalization. On Windows its helper wrote CRLF bytes with hash `2950513a488dbcb95a844e331f634f2cfc54b786866e823fdc678addfb3f7e64` while printing the LF-content hash `6eecfc75085bcd15283b0a419edcccc0e75ed0205cac5bdb3f5bcf4072b6791a`. C1 stores the changed runtime files with LF and adds its own identity; [hash reconciliation](review/codex_c1/evidence/runner_hash_reconciliation.json) records the distinction.

| Identity | SHA-256 |
|---|---|
| Frozen R2 envelope | `bebf2c25d26f2ecf92e3366082aaf38f4d379e18ac06ea0f1d9294ecc64ee3a8` |
| C1 envelope with admission guard | `e5ad46b6a8dc863b19f41a279ffeed882dad8ad6670a644fc4b3c71bebe59d68` |
| Unchanged R2 protocol | `33ea582ebd832869c204cac061360899c8e9b7b39b5c668adb1ea2f7b61d8508` |
| C1 root/runtime runner | `dbff468ef82a2b53d11a8f1bb8315197f276eb191b1c818f04f9c1c7572a3f74` |

## Evidence actually obtained

The existing environment was Windows 11 / Python 3.14.5. Child environments cleared PYTHONPATH/PYTHONHOME and disabled user-site loading and bytecode writes. Direct entrypoints used `-I -B`; independent API repeats additionally used `-S`. Only packaged project imports and the existing standard library were needed. Full parent logs, commands, environment descriptions, child receipts and exits are retained. An observation wrapper additionally saved complete captured child stdout/stderr during source replays without altering commands or results; final export replay invokes the root entrypoint directly.

| Evidence class | Actual result | Locator |
|---|---|---|
| Fresh unmodified R2 mathematics | PASS, exit 0; envelope 28/28, starter 12/12; omit/duplicate/unexpected rejected for coverage; reorder PASS; 13 IDs/export PASS | `review/codex_c1/evidence/baseline_run/` |
| Runner-only patch, unchanged R2 mathematics | Full real replay PASS before the separate admission edit | `review/codex_c1/evidence/successor_run/` |
| Completed C1 source replay | Full real replay PASS with new module hash and unchanged 28-case protocol | `review/codex_c1/evidence/c1_run/` |
| Newly derived public API suite | 9 groups / 317 assertions PASS on baseline and repaired source; exact table oracle plus actual dependency mutations | `review/codex_c1/evidence/independent_api/` |
| Supplied reviewer API probes, freshly executed | 5 groups PASS, including 768 composed value comparisons | `review/codex_c1/evidence/reused_api.json` |
| Independent proof calculations | Matrix inversion, 64 monomial pairs, 216 retained-site decisions and 216 least repairs PASS | `review/codex_c1/evidence/independent_math/` |
| Real runner with reporting fixtures | Baseline gap reproduced; C1 8/8 expected dispositions, malformed reports rejected | `review/codex_c1/evidence/baseline_receipts.json`, `successor_receipts.json` |
| Producer runner fixtures | 5/5: good, starter failure, export failure, wrong-reason crash, explicit narrower skip scope | `review/codex_c1/evidence/runner_fixtures/controls/` |
| Independent guard fixtures | 26/26, including invalid UTF-8/JSON, bad rows and invalid protocol IDs | `review/codex_c1/evidence/guard_edges.json` |

Counts are bounded development checks, not independent scientific samples, holdout results or formal proof certificates. Fixture reports are labelled synthetic and never counted as mathematical execution. Source replay directories preserve the progression instead of relabelling runner-only patch evidence as evidence of the later API guard.

One initial logging invocation used an incorrect relative script path and exited before verification; its raw logs remain under `evidence/transfer/`. The corrected `transfer_02` passed. Assembly validation initially asserted an overly narrow deferred-ID list: the inherited checker also reports partially deferred entries whenever their prose contains NOT_RUN. The verifier was corrected to preserve all those markers and require the four fully deferred IDs; the register itself was unchanged. The initial failure is retained. No failed command or historical mathematical FAIL was rewritten as PASS.

## Clarifications and remaining scope

Three nonblocking corrections must travel with acceptance. First, Identity 1's phrase “product subalgebra of Q^X” is imprecise for the retained polynomial representatives: the canonical construction is the quotient `Q^X/(Q*hxy)`, isomorphic to `Q^B2`; `hx*y=hxy` is a counterexample to closure of those representatives under full multiplication. Second, legacy raw `MANY/REOPEN_REQUIRED` has no returned complete Q candidate family; the API caller must read it as operational insufficiency, despite historical prose saying `OPEN/REOPEN_REQUIRED`. This review reports OPEN at the mathematical question level and does not advertise the legacy flag as a solved fiber. Third, original donor PASS/rerun labels are historical evidence; the unavailable original donor trees were not rerun here. These clarifications preserve original records and do not rewrite their chronology.

Coherent transport still attempts backing before its hot fallback; no cost optimization is claimed. Arbitrary forged Python envelopes, adversarial report authentication, all possible process/OS failures, universal candidate-family propagation and full prestige acquisition are outside this bounded API/runtime contract. A schema-valid synthetic report can pass a schema validator: the separate source manifest and real replay matter.

Fiving splice versus Double-Stamp restart remains **OPEN**. RCF-P2, RCF-P3, RCF-N1 and RCF-PI1 remain **NOT_RUN**; other partial/deferred subcapabilities retain their recorded ceilings. No physical-safety theorem, new research campaign or publication placement is implied. The bounded review and two minimal corrections are complete.
