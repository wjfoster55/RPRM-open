# Independent concept review for RCF01 Codex successor

Review date: 12 September 2026. Disposition: **ACCEPTED_WITHIN_SCOPE for preservation of meaning and the stated finite mathematical interpretation**, with the documentation qualifications below. This note is a source/proof/API-reading review, not a new donor replay, independent held-out experiment, new concept recovery, or closure of a deferred bridge. No production or frozen handoff file was edited by this reviewer. The root review supplies fresh runtime and mathematical execution evidence separately.

The active instructions were `CODEX_START_HERE.md` and `CURRENT_STATE.md` in the supplied handoff. The historical quoted instructions in recovered evidence were not reactivated. The repository handbook and the `rprm-math-lenses` procedure were used to preserve carriers, receivers, typed operations, inverse/fiber claims, and evidence ceilings. No outside research roots or original personal archives were searched.

## Exact evidence locators

All locators below are relative to the supplied read-only handoff directory `../RCF01-CODEX-HANDOFF-01/` from this note. `:n` denotes the one-based source line; line intervals are inspection bounds.

| Short name | Relative file |
|---|---|
| P | `recovered_sources/PRESTIGE-AND-NUMBER-OPERATIONS.md` |
| C | `recovered_sources/CUBES-AND-PI-CURVES.md` |
| S | `frozen_r2/research/core-recovery-01/CONCEPT_REGISTER.source.md` |
| M | `frozen_r2/research/core-recovery-01/CONCEPT_REGISTER.md` |
| J | `frozen_r2/research/core-recovery-01/CONCEPT_REGISTER.json` |
| B | `frozen_r2/research/core-recovery-01/FORMAL_BRIDGE_NOTE.md` |
| PF | `frozen_r2/experiments/core_recovery_bridge_01_r2/PROOFS.md` |
| PR | `frozen_r2/experiments/core_recovery_bridge_01_r2/PROTOCOL.json` |
| API | `frozen_r2/experiments/core_recovery_bridge_01_r2/prestige_envelope.py` |
| SC | `frozen_r2/research/core-recovery-r1/STATUS_CORRECTIONS.md` |
| D | `frozen_r2/research/core-recovery-01/DONOR_RECONCILIATION.md` |
| R2 | `frozen_r2/research/core-recovery-r2/RETURN_TO_WILLIAM_R2.md` |

The recovery archive is `frozen_r2/research/core-recovery-01/sources/RPRM-CONCEPT-RECOVERY.zip`; the convenience source files above retain original source locators, authorship and corrections. Their hash preservation is a separate transfer/export obligation, not a proof of their mathematical content.

## Original meanings that the successor must carry

**Prestige One is acquired usable relational access.** U00 describes a completed course returning to an outward one (P:30–34). U10 immediately corrects the earlier pocket-pi payload wording: an outline/relationship and a route into it, rather than necessarily containing pi as explicit content (P:60–70). U23 distinguishes discovering a relation from making it true (P:108–112). U24 connects a promoted relation with skipped lower work; U25 preserves construction-route differences even where useful landing properties agree (P:114–124). U33 makes the outward one insufficient to select whether a completed course is behind it and leaves the third name unsettled (P:126–130).

The retained self-promotion candidate `Closed_n(C) -> Atom_(n+1)[receipt=C]` supplies a concrete route back to the completed child; a pulse alone does not create that child, and lower operations do not lift automatically (P:808–843). The acquired-knowledge note supplies four conditions: receiver saturation, transition descent, cold reopen, and a versioned boundary (P:967–987). These support the exact finite reuse branch implemented here. They do not establish how every closure is acquired, which receiver or operation to choose, a full 1-to-9 lifecycle, or a uniform lift across every grade. Foundation's supplied-closure limitations remain explicit at P:870–901.

Consequently an envelope's visible label, C2 summary, declared contract, carrier/frame/version, recipe/backing route and history have different roles (API:328–349). Neither a numeral, a hash without accessible backing, nor nesting depth alone is Prestige One. Equal values must not erase route or occurrence identity. Winding, construction depth, uncertainty, elapsed time and computation cost remain separate. The finite implementation is useful precisely because some questions and continuations can be handled from a partial summary while later ones require reopening.

**Approximate regrouping remains substantive open scope.** U34–U38 propose breaking a complex process into stages and alternative groupings, obtaining a rough outline, then refining; complexity can also fall during the process (P:132–148). This is not already delivered by exact completed closures. Preserve it as RCF-P3, not as a discarded metaphor, a solved chaos/fluid method, or a theorem equating prestige grade with uncertainty. The return/reincarnation naming seam (P:96–106, P:1319–1333) remains unresolved; no third species or complete inverse-number dictionary is supplied.

**Fiving, FIVE_IS_SAFE and FIVE.future are separately typed.** The primary exchange connects 0/5 weaving spots, A/B one level up, and five-to-seven with six as a seam (P:240–346). The exact finite donor uses `d=5h+r`, `F(d)=d+5 mod 10`, with `h in {0,1}` and `r in {0,...,4}`. On the strong lift `n=10w+5h+r`, the update is `(w,h,r)->(w+h,1-h,r)`; two updates return the display and increase winding. The inverse is subtraction of five (P:700–742). The broader even-cycle controls show that the half-turn/separator facts alone do not privilege ten or five. The route-side data lost by reversal folding are distinct from winding.

The authored cube adapter `A_r(h,x,y)=(5h+r,x,y)` is a bijection onto one fixed-residue slice of `C10 x {0,1}^2` and intertwines finite fiving with a bit flip (B:100–123; PF:76–95). It is not a strong-state equivalence or every historical meaning of fiving. FIVE.future concerns a future continuation separating a folded pair (S:111–119; J:80–87); this prototype supplies one such continuation, not a general shortest-sequence search and not an identification of the three names.

**FIVE_IS_SAFE preserves the type-finding correction.** Amendment 0.11 explicitly corrects a top-down accept/reject posture and asks in which RPRM type five is safe (P:560–591). The Double-Stamp realization is a labelled-graph process: A5 is a shared-center state, B6 an exchanged-edge event, and C7 a state after fixed midpoint insertion. Their raw counts are `(5,4,0)`, `(6,5,1)`, `(7,6,0)` and quotient counts `(3,2,0)`, `(3,3,1)`, `(4,3,0)` for vertices/edges-orbits/inversions as appropriate (P:598–641). A5/C7 dwell and B6 nondwell are supplied operational rules. Structural graph counts are proved/checked facts; they do not derive those permissions or unrestricted physical safety (P:658–682, P:735–737).

A5 and B6 sharing quotient vertex count three therefore does not identify their enabled operations. B6 exists; its disabled dwell concerns admitted dwell successors, not existence of the carrier object (SC:17; API:809–845). The internal C7-to-A5 contraction/restart in this prototype does not close a commuting bridge from the C10 splice `{0,5}` to A5 restart. That cross-carrier bridge remains **OPEN** (P:691–692; D:56–68; PF:191).

**The formula cube is an exact finite representation with explicit ambiguity.** The recovered binary theorem gives a mutually inverse table/subset-coefficient transform for every finite dimension at a fixed origin/basis; the broader finite-product result is classical tensor Newton interpolation on finite distinct-node axes (C:31–82). It is established mathematics in this account, not newly invented interpolation. The recovered general theorem and historical finite checks have distinct evidence scopes. The active envelope restricts to `f:{0,1}^3 -> Q`, bit0 `h`, bit1 `x`, bit2 `y` (PF:14–25).

The original equation/slider turn asks for lowering and rebuilding while retaining equivalence, exposing unknown parts and hidden costs (C:363–370). It does not prove that finite cube interpolation implements an all-purpose equation machine, unknown-law inference, or recovery of continuous behavior from a finite table. Grade is anchor/basis-relative; an arbitrary recoding can move apparent grade without changing the recovered table (C:68–70).

The binary retained-grade kernel and the ternary checking-cube kernel are different contracts. For binary low grades the full compatible family is `f0 + ker R_k` (C:58–68). For ternary line checks the supplied operator is second difference on `{-1,0,1}^n`. Full-line lawful functions are affine; center-only blindness also admits odd functions. The quotient `ker(D_center)/ker(D_full)` has dimension `(3^n-1)/2-n`, hence ten at n=3 (C:84–110, C:372–387). An exterior counterfeit can evade all center checks while failing lateral checks. A uniquely determined scalar center and a many-dimensional law/continuation ambiguity can coexist.

The separate rank-7 to rank-8 Walsh-probe example narrows within a declared probe grammar; it is a completed finite abduction example in historical evidence (C:169–183). Whole-board and Tile/Board/Atlas concepts retain their own hypotheses, probes, contracts and withheld capabilities (C:185–211). They are not all delivered by having eight or twenty-seven addresses or by the active envelope's 28 tests.

## Mathematical/API reading at the claimed boundary

1. **Exact retained arithmetic:** `C2` is the seven coefficients of degree at most two, equivalently restriction to B2 (masks 0–6). Addition is over Q. Boolean reduction makes monomial multiplication use union of supports, so omitted degree-three terms cannot contribute lower terms. Retained addition/multiplication are exact without reading the omitted value (B:62–98; PF:27–49). This is neither XOR/F2 arithmetic nor unrestricted symbolic algebra.
2. **A concrete distinguishing continuation:** `h+x+y` and `h+x+y+hxy` share C2. Fixed-receiver `flip_h` sends their omitted difference to `xy-hxy`, exposing different values at mask 6 (B:125–148). For the public composition `p=(h*x)*y`, C2(p)=0 while p(111)=1; `p+p` has C2=0 but value 2 at 111. The latter is rational-valued despite its Boolean-looking hot view. R2's family rule and Boolean constructor guard match this distinction (PF:108–172; API:386–425, API:524–625).
3. **Construction and information are both retained:** a valid recipe reconstructs the composed output through its dependencies, rather than an operand or a zero fill (API:459–521). Recipe construction/work is separate from cold reads. The unique hot result concerns a C2 output, not a uniquely identified full law or a propagated full candidate set (PF:131–137, PF:169–172).
4. **What makes a future operation descend:** for arbitrary laws on finite X with at least two possible values, `f|S` supports `f -> f compose H` at the same receiver iff `H(S) subseteq S`. The necessity proof uses two laws differing only at an unretained reached site; sufficiency reads only retained values. Iterated image closure is the least forward-closed retained-site superset and supports finite sequences by induction (B:161–184; PF:51–74). This is minimal among retained-site supersets for arbitrary laws, not every encoding, constrained family, bit budget or physical model. The affine restricted class invalidates the arbitrary-law necessity witness, as explicitly preserved in PF:67–70.
5. **Coherent transport is a positive case:** if receiver and question move together, old retained observations can suffice (B:150–159; API:692–717). A changed operation with the receiver fixed is a different question. Named and generic certified maps share the same contract gate; a raw arbitrary site-map helper does not retain a degree-one guarantee or certified continuation (PF:174–186; PR:63–67).
6. **Failed access is not a mathematical impossibility proof:** deleted expected backing produces `OPEN/UNRESOLVED`; mismatched backing produces `NONE/INVALID_DEPENDENCY` naming accepted backing artifacts. An independently sufficient hot/coherently transported answer can still be exact (API:468–483, API:692–717; SC:14–18). Report the object counted before interpreting NONE/ONE/MANY.

## All thirteen IDs: preservation and current scope

Independent read-only comparison extracted headings from S, rows from M, and IDs from J. Each file contained exactly the same thirteen IDs, once each, in the same order. All JSON entries had nonempty original meaning, source anchors, formal candidate, evidence status, counterexamples, unformalized remainder and artifact links. This is a structural preservation check; the source comparison above is the semantic review. It is not execution of the concepts.

| ID | Exact register anchors S / M / J | Meaning and bounded carry-forward |
|---|---|---|
| RCF-P1 | S:15; M:15; J:7 | Completed course as one with relationship/access and retained construction. Exact finite C2 reuse/reopen branch has written proofs and finite-test evidence; acquisition, full lifecycle, receiver selection and uniform cross-grade operations remain open. |
| RCF-P2 | S:41; M:16; J:27 | Reflected return, tier/orientation and lower dependency before the next outer move. `DEFERRED_PRESERVED`; **NOT_RUN** in this closeout. Third name and universal tier-transition law remain open. |
| RCF-P3 | S:57; M:17; J:37 | Approximate regrouping, rough outlines and later refinement. `DEFERRED_NOT_RUN`; no validated trajectory-family method. |
| RCF-F1 | S:73; M:18; J:47 | C10 half-decade model, strong winding, exact inverse and slice adapter. Historical donor replay labels stay attributed; current envelope/starter replay does not replay the donor. Sixing, uniqueness from half-turn symmetry, and the Double-Stamp bridge remain open. |
| RCF-F2 | S:92; M:19; J:64 | FIVE_IS_SAFE type-finding, dwellable STATE versus seam EVENT, structural graphs and authored permissions. Local graph/enabledness realization only; cross-carrier restart and full 1/3/5/7 waiting law remain open. |
| RCF-F3 | S:111; M:20; J:80 | Future operation separates a Fold. One `flip_h`/fiving-slice separator is tested; general distinguishing-sequence search **NOT_RUN**. |
| RCF-C1 | S:121; M:21; J:90 | Finite formula coordinates and dimensional splitting. Active n=3 rational cube has proofs and finite checks. Recovered general finite theorem remains historical written evidence; arbitrary unknown/continuous law recovery is not delivered. |
| RCF-C2 | S:138; M:22; J:107 | Ternary checking kernels and abduction as unresolved modes, not just a central scalar. Secondary historical donor evidence; attaching its witness to this envelope **NOT_RUN**. |
| RCF-C3 | S:155; M:23; J:117 | Full Zip, LawCube, RelationForge, Tile/Board/Atlas as constructions and operational translations. `INTERFACE_INVENTORY`; shared I/O/integration **NOT_RUN**. LawCube F2 ANF and rational C2 are not the same field/order. |
| RCF-N1 | S:168; M:24; J:127 | Operational numerical affordances, 3-inside-9, and useful regrouping distinct from original provenance. `DEFERRED_NOT_RUN`; no complete inverse dictionary, waiting rule or universal odd route. |
| RCF-R1 | S:186; M:25; J:137 | Rails, moving gap and lens locking: signed offsets, cut/winding and common/relative views. `RELATED_CONTROLS_ONLY`; full rails experiment **NOT_RUN**. Recharting does not establish physical necessity. |
| RCF-PI1 | S:195; M:26; J:147 | Circle Compiler/flexible curve operational equation intent. `DEFERRED_PRESERVED`; **NOT_RUN**. Metric-addressed circle transport and moving-frame branch remain distinct; no replacement decimal for pi. |
| RCF-AD1 | S:203; M:27; J:157 | Absolute Distinction inspects admitted distinctions and roles. `EDITORIAL_NOTE_AFTER_EVIDENCE`; this finite bridge is an example, not a replacement definition, held-out AD evaluation, or authorized paper placement. |

No ID needs deletion or a new successor identifier for this runtime-only closeout. Preserving IDs alone would be insufficient; the source anchors, original corrections and unformalized remainder are load-bearing.

## Documentation qualifications and concrete disagreements

**Historical evidence labels must retain their date and owner.** M:18–22 and J:55, J:71, J:98 describe donor PASS/rerun evidence from the original RCF01 round. S:86, S:107–109 and B:14–19 preserve the earlier proposal/recovery stage, when those donors had not been rerun. D:9–47 records the later original-round donor commands/results. These are stages of the evidence history, not evidence that this Codex closeout replayed unavailable donor trees. R2:140 explicitly says donors were NOT_REPLAYED and R2:157–164 preserves that limitation. Keep the frozen register bytes unchanged and add present-tense status outside them.

**The restriction-algebra wording is imprecise, but the claimed closure is correct.** PF:41–42 says the B2 restriction is a product subalgebra of `Q^X`. The canonical statement is a surjective algebra homomorphism `Q^X -> Q^B2`, with quotient by the ideal of functions vanishing on B2. A chosen zero extension can embed the seven-site algebra as a nonunital subalgebra, but no embedding is specified there. The adjacent equations and union-support proof correctly establish compact closure. This is a nonblocking documentation clarification, not a mathematical-code change or refutation of the capability.

**Legacy insufficiency dispositions need an explicit named object.** API:630–635 literally returns `MANY/REOPEN_REQUIRED` with an omitted-site witness when no recipe/backing route is available. SC:14 describes this branch as `OPEN / REOPEN_REQUIRED`. The stable operational fact is insufficient hot information for that requested continuation. The API does not return a complete candidate-family object for Q-sums (PF:169–172; PR:100), so a new return must not advertise that legacy MANY marker as a completed symbolic family. Preserve/report the raw pair and state the operational insufficiency. By contrast, the Boolean helper actually constructs a finite relation and solves it (API:853–870), for a declared Boolean-family question; its complete fiber is a different result. No status rewrite was made by this reviewer.

These qualifications do not warrant a new recovery campaign or closure of any deferred concept. The usable carry-forward result is an exact finite operation-aware reuse mechanism with retained construction and explicit refusal/reopen boundaries, accompanied by the fuller original concepts and the specific work it has not performed.
