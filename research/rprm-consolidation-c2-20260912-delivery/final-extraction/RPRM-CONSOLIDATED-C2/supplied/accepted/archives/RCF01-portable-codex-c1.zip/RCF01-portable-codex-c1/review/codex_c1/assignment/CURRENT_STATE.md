# Current state and evidence boundaries

**Handoff date: 12 September 2026**

## What William wants

Transfer the core RPRM recovery/formalization work from Cursor to Codex for a genuine second pair of eyes. Preserve the work; do not restart it. The intended next outcome is an independently assessed, portable finite capability and completion of one remaining runtime guard, not an expanded research campaign.

William treats Prestige One, fiving/FIVE_IS_SAFE, and cube/abduction as core RPRM. Their original meanings must travel alongside each narrow mathematical realization, evidence, and open scope. He wants formalization and testing before deciding whether these belong in an addendum, a companion, Absolute Distinction, or several destinations. Publication placement remains undecided.

## How we got here

The original recovery found useful mathematics and conceptual connections that had not been carried into later rebriefs. The first prototype investigated an exact operation-aware reuse branch: retain seven coefficients of a law on the Boolean three-cube, use them for justified compact arithmetic, and reopen a retained construction when a newly requested operation exposes the omitted interaction.

An early research-only ZIP omitted the runnable experiment. The R1 portable return fixed packaging and retained actual composition recipes. A subsequent review found that a hidden non-Boolean result could retain a Boolean label, a generic map bypassed an admission gate and kept an incorrect degree bound, and the aggregate runner could misreport failures.

R2 corrected those three boundaries. Its submitted portable archive is the frozen baseline here. Last supplied local locator: `research/core-recovery-r2/dist_02/RCF01-portable-r2.zip`; return note `research/core-recovery-r2/RETURN_TO_WILLIAM_R2.md`. Last report said no commit. Do not assume the current working tree or HEAD is unchanged.

## Prior review's disposition — evidence to inspect, not immunity from review

`review_r2/REVIEW.md` records an independent Linux replay of the submitted R2: envelope 28/28 named cases, starter 12/12, expected coverage controls, 13 concept IDs, and export checks. Additional checks include composed arithmetic/maps, false Boolean declarations, coherent transport, and backing-file damage. The source-reported Windows run is separate.

Core results were accepted within their finite scope. The original five runner fixtures also passed, but a further runner probe accepted malformed child reports such as `{"status":"PASS"}` without case rows. The genuine mathematical receipts were complete; the defect concerns what a broken child report could get accepted.

The reviewer supplied and tested a minimal patch affecting the two runner copies and their explicitly synthetic fixtures. Its candidate passed the actual unchanged mathematical replay, five prior runner scenarios, and eight report scenarios. The patch is **not integrated** into the frozen input or a newly issued official successor. Codex must inspect it independently.

## Exact identities

| Item | SHA-256 |
|---|---|
| Submitted R2 ZIP | `f33d4dfa04b4451dc3b847bd06121c9a0d1601413939e765c8e42f954102926c` |
| Prior review ZIP | `f873e92239dd7739b38615622fb1e6f4dfb0bb0ade0d694c92de6f74257f6e73` |
| R2 root runner | `46ef570e0cef28b41fd735985e5aa72cf6a41af42e93913118c686551e9239da` |
| R2 envelope implementation | `bebf2c25d26f2ecf92e3366082aaf38f4d379e18ac06ea0f1d9294ecc64ee3a8` |
| R2 mathematical protocol | `33ea582ebd832869c204cac061360899c8e9b7b39b5c668adb1ea2f7b61d8508` |
| Prior reviewer candidate runner | `6eecfc75085bcd15283b0a419edcccc0e75ed0205cac5bdb3f5bcf4072b6791a` |

The candidate-runner hash records the earlier Linux candidate's exact bytes. Different line endings can change a hash; reconcile and explain such differences rather than treating them as mathematical evidence.

## Keep the claims scoped

ONE/EXACT for a hot result concerns the retained output, not a unique complete law. Boolean multiplication stays Boolean; Q-addition can leave that class invisibly. A raw arbitrary input map is not a certified continuation. A cold-file failure is not an empty mathematical possibility space. Coherently transporting question and coordinates is different from changing the operation while retaining the old question.

The fiving-splice/Double-Stamp restart connection remains OPEN. The wider prestige lifecycle, approximate regrouping, unsettled number-operation vocabulary, and LawCube/RelationForge integrations are not finished by this prototype. Deferred concepts remain NOT_RUN. Historical donor logs are available, but their original code trees are not supplied or independently replayed by the prior review.

## This transfer did not rerun the mathematics

`TRANSFER_VALIDATION.json` records checks performed while assembling this handoff: archive CRC, safe names, exact expanded copies, and both original manifests. It is not new proof, new behavioral testing, or upstream integration. All previous review results retain their original authorship and exposure. The handoff gives Codex the bytes needed for its own bounded review.
