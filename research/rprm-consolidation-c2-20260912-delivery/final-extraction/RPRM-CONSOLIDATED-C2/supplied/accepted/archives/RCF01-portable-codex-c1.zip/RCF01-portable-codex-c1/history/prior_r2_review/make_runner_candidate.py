#!/usr/bin/env python3
"""Create a reviewer-owned candidate; never overwrite the submitted R2 package."""
from __future__ import annotations
import argparse, difflib, hashlib, json, shutil
from pathlib import Path

PIN='46ef570e0cef28b41fd735985e5aa72cf6a41af42e93913118c686551e9239da'
OLD_LOAD='''    try:
        return json.loads(path.read_text(encoding="utf-8")), "ok"
    except json.JSONDecodeError:
        return None, "malformed output"
'''
NEW_LOAD='''    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError):
        return None, "malformed or unreadable output"
    if not isinstance(payload, dict):
        return None, "malformed output: expected a JSON object"
    return payload, "ok"
'''
OLD_PASS='''    if "results" in payload and not isinstance(payload.get("results"), list):
        return False, "malformed results"
    return True, "PASS receipt"
'''
NEW_PASS='''    # A status string alone is not a completed mathematical-case receipt.
    rows = payload.get("results")
    if not isinstance(rows, list) or not rows:
        return False, "missing or empty results"
    if not all(isinstance(row, dict)
               and isinstance(row.get("case_id"), str)
               and bool(row["case_id"])
               and row.get("outcome") in ("PASS", "FAIL")
               and isinstance(row.get("data"), dict) for row in rows):
        return False, "malformed result rows"
    if any(row["outcome"] != "PASS" for row in rows):
        return False, "PASS status contradicts a failed case"
    # Read obligations from the declared protocol, never from emitted rows.
    protocol_path = job.get("protocol_path")
    if not protocol_path:
        return False, "required protocol not supplied"
    protocol, protocol_state = load_json_file(Path(protocol_path))
    if protocol_state != "ok":
        return False, f"invalid protocol: {protocol_state}"
    required = protocol.get("required_case_ids")
    if (not isinstance(required, list) or not required
            or not all(isinstance(cid, str) and cid for cid in required)
            or len(required) != len(set(required))):
        return False, "invalid required_case_ids"
    emitted = [row["case_id"] for row in rows]
    if len(emitted) != len(set(emitted)) or set(emitted) != set(required):
        return False, "PASS receipt has missing, duplicate, or unexpected case IDs"
    return True, "PASS receipt with complete case coverage"
'''

def patch_text(text: str) -> str:
    if text.count(OLD_LOAD)!=1 or text.count(OLD_PASS)!=1:
        raise ValueError('Unexpected runner text; do not apply to a different version')
    text=text.replace(OLD_LOAD,NEW_LOAD).replace(OLD_PASS,NEW_PASS)
    text=text.replace('def named_job(name: str, kind: str, result: dict, output: Path | None = None) -> dict:',
        'def named_job(name: str, kind: str, result: dict, output: Path | None = None,\n              protocol: Path | None = None) -> dict:')
    text=text.replace('    rec["output_path"] = str(output) if output is not None else None\n',
        '    rec["output_path"] = str(output) if output is not None else None\n    rec["protocol_path"] = str(protocol) if protocol is not None else None\n')
    for old,new in [
        ("    ), envelope_out))","    ), envelope_out, protocol=env / \"PROTOCOL.json\"))"),
        ("        ), control_out))","        ), control_out, protocol=env / \"PROTOCOL.json\"))"),
        ("            ), starter_out))","            ), starter_out, protocol=starter / \"PROTOCOL.json\"))"),
    ]:
        if text.count(old)!=1: raise ValueError('Call-site not uniquely found: '+old)
        text=text.replace(old,new)
    return text


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--package',type=Path,required=True)
    ap.add_argument('--candidate',type=Path,required=True)
    ap.add_argument('--patch-output',type=Path,required=True)
    args=ap.parse_args()
    original=(args.package/'run_portable.py').read_bytes()
    if hashlib.sha256(original).hexdigest()!=PIN: raise ValueError('Wrong R2 runner source SHA256')
    old=original.decode(); new=patch_text(old)
    shutil.copytree(args.package,args.candidate)
    changes=[]
    for relative in ('run_portable.py','research/core-recovery-r2/run_portable.py'):
        p=args.candidate/relative
        if p.read_bytes()!=original: raise ValueError('Source copies differ')
        p.write_text(new,encoding='utf-8')
        changes.extend(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+relative,tofile='b/'+relative))
    # Keep the fast producer fixtures valid under the stricter receipt schema.
    # These generated rows are explicitly fixtures, not mathematical executions.
    rel = 'research/core-recovery-r2/check_runner.py'
    harness_old = (args.package/rel).read_text()
    harness_new = harness_old
    row_expr = ("[{\"case_id\": cid, \"outcome\": \"PASS\", \"data\": {\"fixture\": True}} "
                "for cid in json.loads(Path(__file__).with_name(\"PROTOCOL.json\").read_text())[\"required_case_ids\"]]")
    for old_row in (
        '[{"case_id": "FIXTURE", "outcome": "PASS" if not fail else "FAIL"}]',
        '[{"case_id": "FIXTURE", "outcome": "PASS"}]',
        '[{"case_id": "STARTER_FIXTURE", "outcome": "PASS"}]',
    ):
        if harness_new.count(old_row) != 1:
            raise ValueError('Unexpected producer fixture rows')
        harness_new = harness_new.replace(old_row, row_expr)
    # Reflect the intended coverage mutation in the fake emitted rows too.
    marker = 'Path(a.output).write_text(json.dumps(payload) + "\\n", encoding="utf-8")'
    insertion = ("if a.control == \"omit\": payload[\"results\"] = payload[\"results\"][:-1]\n"
                 "elif a.control == \"duplicate\": payload[\"results\"][-1] = payload[\"results\"][0].copy()\n"
                 "elif a.control == \"unexpected\": payload[\"results\"][-1][\"case_id\"] = \"UNDECLARED\"\n")
    harness_new = harness_new.replace(marker, insertion + marker, 1)
    (args.candidate/rel).write_text(harness_new)
    changes.extend(difflib.unified_diff(harness_old.splitlines(True),harness_new.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel))
    args.patch_output.parent.mkdir(parents=True,exist_ok=True)
    args.patch_output.write_text(''.join(changes))
    manifest_path=args.candidate/'MANIFEST.json'; manifest=json.loads(manifest_path.read_text())
    manifest['reviewer_candidate']={'status':'REVIEWER_OWNED_NOT_CURSOR_RELEASE',
        'base_zip_sha256':'f33d4dfa04b4451dc3b847bd06121c9a0d1601413939e765c8e42f954102926c',
        'changes':'runner receipt validation and schema-correct runner-only fixtures; no mathematical implementation/protocol changes',
        'not_retroactive_preregistration':True}
    for relative in ('run_portable.py','research/core-recovery-r2/run_portable.py','research/core-recovery-r2/check_runner.py'):
        b=(args.candidate/relative).read_bytes()
        manifest['files'][relative]={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
    manifest_path.write_text(json.dumps(manifest,indent=2)+'\n')
    print(json.dumps({'candidate':str(args.candidate),'base_runner_sha256':PIN,
        'candidate_runner_sha256':hashlib.sha256(new.encode()).hexdigest(),
        'math_source_and_protocol':'UNCHANGED','patch':str(args.patch_output)},indent=2))
if __name__=='__main__': main()
