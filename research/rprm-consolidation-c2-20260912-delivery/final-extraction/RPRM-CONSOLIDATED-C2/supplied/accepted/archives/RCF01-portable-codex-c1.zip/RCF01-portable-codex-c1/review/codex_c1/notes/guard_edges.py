"""Small independent direct tests of report validation; synthetic, not math."""
import argparse
import copy
import importlib.util
import json
import sys
from pathlib import Path

def main():
    p = argparse.ArgumentParser()
    p.add_argument('--package', type=Path, required=True)
    p.add_argument('--work', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    a = p.parse_args()
    a.work.mkdir(parents=True, exist_ok=False)
    spec = importlib.util.spec_from_file_location('reviewed_runner', a.package/'run_portable.py')
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    base = {'status':'PASS','results':[{'case_id':c,'outcome':'PASS','data':{}} for c in ('A','B')]}
    protocol = {'required_case_ids':['A','B']}
    cases=[]
    def check(name, payload, expected, proto=protocol, exit_code=0, raw=None):
        out=a.work/(name+'.json'); pp=a.work/(name+'_protocol.json')
        if raw is not None: out.write_bytes(raw)
        elif payload is not None: out.write_text(json.dumps(payload),encoding='utf-8')
        pp.write_text(json.dumps(proto),encoding='utf-8')
        ok,reason=m.check_pass_receipt({'exit_code':exit_code,'protocol_path':str(pp)},out)
        row={'case':name,'expected':expected,'accepted':ok,'reason':reason}
        cases.append(row)
        assert ok is expected, row
    check('valid',base,True)
    v=copy.deepcopy(base); v['results'].reverse(); check('reordered',v,True)
    check('nonzero_exit_valid',base,False,exit_code=7)
    check('missing_file',None,False)
    check('invalid_json',None,False,raw=b'{')
    check('invalid_utf8',None,False,raw=b'\xff')
    for name,payload in [('null',None),('array',[]),('string','PASS'),('number',1)]:
        check(name,payload,False,raw=json.dumps(payload).encode())
    for field,value in [('case_id',1),('case_id',''),('outcome',True),('outcome',[]),('data',None),('data',[])]:
        v=copy.deepcopy(base); v['results'][0][field]=value
        check('row_'+field+'_'+str(len(cases)),v,False)
    v=copy.deepcopy(base); v['results'][0]=[]; check('nonobject_row',v,False)
    v=copy.deepcopy(base); del v['results'][0]['data']; check('missing_data',v,False)
    v=copy.deepcopy(base); v['coverage_error']='Coverage mismatch'; check('contradictory_coverage',v,False)
    for i,ids in enumerate((None,[],['A','A'],['A',1],['A',''],['A','C'])):
        check('protocol_'+str(i),base,False,proto={'required_case_ids':ids})
    check('protocol_array',base,False,proto=[])
    report={'status':'PASS','scope':'Independent direct guard fixtures; no mathematical execution',
            'case_count':len(cases),'cases':cases}
    a.output.parent.mkdir(parents=True,exist_ok=True)
    a.output.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(report,indent=2))
    return 0

if __name__=='__main__':
    sys.exit(main())
