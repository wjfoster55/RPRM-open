#!/usr/bin/env python3
"""Exercise actual runner on malformed child receipts in disposable copies.
Reuses prior valid replay receipts as FAST FIXTURES. No mathematical tests
are rerun here; these runs provide only evidence about aggregation behavior.
"""
from __future__ import annotations
import argparse, json, os, shutil, subprocess, sys
from pathlib import Path

ENVELOPE = r'''
import argparse,json,sys
from pathlib import Path
p=argparse.ArgumentParser(); p.add_argument('--output'); p.add_argument('--work'); p.add_argument('--control',default='none'); a=p.parse_args()
root=Path(__file__).resolve().parents[2]; mode=(root/'fixture_mode.txt').read_text().strip()
name='envelope_r2.json' if a.control=='none' else 'envelope_r2_'+a.control+'.json'
payload=json.loads((root/'fixture_receipts'/name).read_text())
payload['fixture_scope']='REUSED RECEIPT FOR RUNNER TEST ONLY; NOT MATHEMATICAL EXECUTION'
if a.control=='none':
    if mode=='status_only': payload={'status':'PASS'}
    elif mode=='empty_results': payload={'status':'PASS','results':[]}
    elif mode=='contradictory_row': payload['results'][0]['outcome']='FAIL'
    elif mode=='missing_case': payload['results']=payload['results'][:-1]
    elif mode=='duplicate_case': payload['results'][-1]=payload['results'][0].copy()
    elif mode=='unexpected_case': payload['results'][-1]['case_id']='UNDECLARED'
    elif mode=='nonobject_json': payload=[]
Path(a.output).parent.mkdir(parents=True,exist_ok=True)
Path(a.output).write_text(json.dumps(payload)+'\n')
print(json.dumps({'scope':'RUNNER FIXTURE ONLY','control':a.control}))
sys.exit(2 if a.control in ('omit','duplicate','unexpected') else 0)
'''
STARTER = r'''
import argparse,json
from pathlib import Path
p=argparse.ArgumentParser(); p.add_argument('--output'); a=p.parse_args()
root=Path(__file__).resolve().parents[1]
payload=json.loads((root/'fixture_receipts'/'starter_replay.json').read_text())
payload['fixture_scope']='REUSED RECEIPT FOR RUNNER TEST ONLY; NOT MATHEMATICAL EXECUTION'
Path(a.output).write_text(json.dumps(payload)+'\n')
print(json.dumps({'scope':'RUNNER FIXTURE ONLY','status':'PASS'}))
'''

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--package',type=Path,required=True)
    ap.add_argument('--replay',type=Path,required=True)
    ap.add_argument('--work',type=Path,required=True)
    ap.add_argument('--output',type=Path,required=True)
    args=ap.parse_args(); args.work.mkdir(parents=True,exist_ok=False)
    env=dict(os.environ); env.pop('PYTHONPATH',None); env.pop('PYTHONHOME',None); env['PYTHONDONTWRITEBYTECODE']='1'
    records=[]
    for mode in ('valid_fixture','status_only','empty_results','contradictory_row','missing_case','duplicate_case','unexpected_case','nonobject_json'):
        case=args.work/mode; root=case/'package'; shutil.copytree(args.package,root)
        (root/'fixture_mode.txt').write_text(mode)
        fixture=root/'fixture_receipts'; fixture.mkdir()
        for name in ('envelope_r2.json','envelope_r2_omit.json','envelope_r2_duplicate.json','envelope_r2_unexpected.json','envelope_r2_reorder.json','starter_replay.json'):
            shutil.copy2(args.replay/name,fixture/name)
        (root/'experiments/core_recovery_bridge_01_r2/check_envelope.py').write_text(ENVELOPE)
        (root/'RPRM-CORE-FORMALIZATION-01/check_bridge.py').write_text(STARTER)
        cmd=[sys.executable,'-B',str(root/'run_portable.py'),'--output-dir',str(case/'run')]
        proc=subprocess.run(cmd,cwd=root,env=env,text=True,capture_output=True,timeout=30)
        (case/'stdout.txt').write_text(proc.stdout); (case/'stderr.txt').write_text(proc.stderr)
        summary_path=case/'run/portable_summary.json'
        summary=json.loads(summary_path.read_text()) if summary_path.is_file() else None
        try: printed=json.loads(proc.stdout.strip().splitlines()[-1])
        except (ValueError,IndexError): printed=None
        row={'case':mode,'exit_code':proc.returncode,'json_status':summary.get('status') if summary else None,
             'printed_status':printed.get('status') if isinstance(printed,dict) else None,
             'summary_written':summary is not None,'expected':'PASS' if mode=='valid_fixture' else 'FAIL',
             'stderr_tail':proc.stderr[-1400:]}
        row['correct_aggregate_behavior']=(row['json_status']==row['printed_status']==row['expected'] and ((proc.returncode==0)==(mode=='valid_fixture')))
        records.append(row)
    report={'scope':'Actual runner with reused child receipts as explicitly substituted fixtures; NO math replay. Export validator remains actual. Manifest not rewritten; its runtime export check does not hash-pin substituted checker bytes.',
        'status':'PASS' if all(r['correct_aggregate_behavior'] for r in records) else 'RECEIPT_VALIDATION_GAP_REPRODUCED','cases':records}
    args.output.parent.mkdir(parents=True,exist_ok=True); args.output.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))
    return 0 if report['status']=='PASS' else 2
if __name__=='__main__': raise SystemExit(main())
