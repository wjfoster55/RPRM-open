#!/usr/bin/env python3
"""Finite direct-table review of RCF01 R2; stdlib only, no checker imports.

Run in a fresh process with -I -B. --package selects a disposable portable
copy, --work must not exist, and --output must not already exist. This script
modifies only its new work files and creates its report. It never edits the
package. Every reference table below is calculated from coordinate values;
the independent coefficient decoder is triangular interpolation, not the
production Mobius transform or its test-runner expected fields.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import itertools
import json
import os
import platform
import sys
import traceback
from dataclasses import asdict, is_dataclass, replace
from fractions import Fraction as Q
from pathlib import Path


SITES = tuple((s % 2, (s // 2) % 2, (s // 4) % 2) for s in range(8))


def encode(value):
    if isinstance(value, Q):
        return str(value)
    if isinstance(value, Path):
        return str(value)
    if is_dataclass(value):
        return encode(asdict(value))
    if isinstance(value, dict):
        return {str(k): encode(v) for k, v in value.items()}
    if isinstance(value, (tuple, list, set, frozenset)):
        return [encode(v) for v in value]
    return value


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def coefficients(table):
    """Solve f(h,x,y)=sum c_j monomial_j(h,x,y) by triangular substitution."""
    powers = SITES
    result = []
    for row, point in enumerate(SITES):
        earlier = sum(result[j] * (point[0] ** powers[j][0]) *
                      (point[1] ** powers[j][1]) * (point[2] ** powers[j][2])
                      for j in range(row))
        result.append(Q(table[row]) - earlier)
    return tuple(result)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--package', required=True, type=Path)
    parser.add_argument('--work', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    package = args.package.resolve()
    work = args.work.resolve()
    output = args.output.resolve()
    if output.exists():
        raise FileExistsError(output)
    work.mkdir(parents=True, exist_ok=False)
    source = package / 'experiments/core_recovery_bridge_01_r2/prestige_envelope.py'
    spec = importlib.util.spec_from_file_location('codex_direct_envelope', source)
    e = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = e
    spec.loader.exec_module(e)
    core_path = Path(sys.modules['rprm.core'].__file__).resolve()
    if core_path != package / 'rprm/core.py':
        raise RuntimeError(f'Wrong core import: {core_path}')
    contract = e.FULL_CUBE_CONTRACT | frozenset({'identity'})
    rows = []
    assertions = 0

    def must(condition, message):
        nonlocal assertions
        assertions += 1
        if not condition:
            raise AssertionError(message)

    def exact(result):
        must(result.status == 'EXACT' and result.disposition == 'ONE', repr(result))
        return result.value

    def promote(table, name, *, family='rational_cube', backed=True, ops=contract):
        return e.promote_cube(table, label='one', contract=ops,
                              cold_dir=work / 'cold' if backed else None,
                              name=name, family=family)

    def case(name, fn):
        before = assertions
        try:
            data = fn()
            row = {'case_id': name, 'outcome': 'PASS', 'data': data}
        except Exception:
            row = {'case_id': name, 'outcome': 'FAIL', 'traceback': traceback.format_exc()}
        row['assertions'] = assertions - before
        rows.append(row)

    def direct_arithmetic():
        samples = [
            (lambda h, x, y: Q(1, 3) + 2*h - x*y + Q(5, 2)*h*x*y,
             lambda h, x, y: Q(-2, 5) + y + Q(3, 7)*h*x),
            (lambda h, x, y: Q(h+x+y), lambda h, x, y: Q(h*x+y)),
            (lambda h, x, y: Q(h), lambda h, x, y: Q(h))]
        receipts = []
        for index, (f, g) in enumerate(samples):
            left = tuple(f(*s) for s in SITES)
            right = tuple(g(*s) for s in SITES)
            a, b = promote(left, f'arith_{index}_a'), promote(right, f'arith_{index}_b')
            must(a.retained == coefficients(left)[:7], 'source interpolation mismatch')
            for op, reference in [('add', tuple(x+y for x, y in zip(left, right))),
                                  ('multiply', tuple(x*y for x, y in zip(left, right)))]:
                before = e.meter_snapshot()
                out = exact(e.add_units(a, b) if op == 'add' else e.multiply_units(a, b))
                after = e.meter_snapshot()
                must(after['cold_reads'] == before['cold_reads'], 'hot arithmetic read backing')
                must(out.retained == coefficients(reference)[:7], 'coefficient oracle mismatch')
                observed = exact(e.read_admitted(out)) + (exact(e.inspect_omitted(out)),)
                must(observed == reference, 'eight-site table mismatch')
                receipts.append({'sample': index, 'operation': op, 'left': left, 'right': right,
                                 'expected': reference, 'observed': observed,
                                 'retained': out.retained, 'hot_cold_reads': 0,
                                 'recipe_constructions': after['constructions']-before['constructions']})
        must(receipts[-1]['observed'] == tuple(Q(h) for h, x, y in SITES), 'h*h != h')
        must(receipts[-2]['observed'] == tuple(Q(2*h) for h, x, y in SITES), 'addition acted as XOR')
        return {'source_pairs': 3, 'complete_tables_compared': 6, 'receipts': receipts}

    def hidden_sum():
        receipts = []
        for backed in (False, True):
            units = [e.unit(axis, family='boolean_cube', contract=contract,
                            cold_dir=work/'cold' if backed else None,
                            name=f'hidden_{backed}_{axis}') for axis in ('h', 'x', 'y')]
            e.reset_meter()
            p = exact(e.multiply_units(exact(e.multiply_units(units[0], units[1])), units[2]))
            result = e.add_units(p, p)
            s = exact(result)
            hot_meter = e.meter_snapshot()
            expected = tuple(Q(2*h*x*y) for h, x, y in SITES)
            must(p.family == 'boolean_cube' and s.family == 'rational_cube', 'family escape missed')
            must(s.retained == coefficients(expected)[:7] == (Q(0),)*7, 'hidden sum summary')
            must(hot_meter['cold_reads'] == 0, 'hidden sum secretly read backing')
            must(hot_meter['constructions'] == (3 if backed else 0), 'recipe accounting')
            must(p.degree_bound == s.degree_bound == 3, 'degree did not track product')
            omitted = e.inspect_omitted(s)
            after_omitted = e.meter_snapshot()
            flipped = e.apply_input_map(s, 'flip_h')
            if backed:
                must(exact(omitted) == expected[7] == 2, 'wrong composed omitted value')
                flipped_values = exact(e.read_admitted(exact(flipped)))
                must(flipped_values == tuple(Q(2*(1-h)*x*y) for h,x,y in SITES[:7]), 'wrong composed flip')
                must(after_omitted['cold_reads'] == 6, 'sum recipe leaf-read accounting')
            else:
                must(omitted.status == flipped.status == 'REOPEN_REQUIRED', 'missing recipe fabricated answer')
                must(omitted.value is None and flipped.value is None, 'insufficient response has value')
            receipts.append({'backed': backed, 'product_family': p.family, 'sum_family': s.family,
                             'sum_expected_table': expected, 'retained': s.retained,
                             'hot_result_witness': result.witness, 'hot_meter': hot_meter,
                             'omitted': omitted, 'after_omitted_meter': after_omitted,
                             'flip_status': flipped.status})
        return receipts

    def input_admission():
        rejected = []
        for site, value in [(0, -1), (3, Q(1, 2)), (7, 2), (7, True), (7, 0.5)]:
            table = [0]*8
            table[site] = value
            try:
                promote(table, f'invalid_{site}', family='boolean_cube', backed=False)
            except e.AdmissionError as error:
                rejected.append({'site': site, 'value': str(value), 'reason': str(error)})
            else:
                raise AssertionError(f'False Boolean declaration admitted: {table}')
        must(len(rejected) == 5, 'missing input rejection')
        return rejected

    def fibers():
        zero = (Q(0),)*7
        actual = e.boolean_fiber_for_compact(zero)
        source_tables = frozenset({(0,)*8, (0,)*7+(1,)})
        must(actual.members == source_tables and actual.disposition == 'MANY', 'Boolean fiber wrong')
        for table in source_tables:
            must(coefficients(table)[:7] == zero, 'independent fiber witness wrong')
        correlated = {a[7]+a[7] for a in source_tables}
        independent = {a[7]+b[7] for a in source_tables for b in source_tables}
        must(correlated == {0,2} and independent == {0,1,2}, 'missing-port correlation erased')
        return {'complete_boolean_sources': sorted(source_tables),
                'complete_correlated_boolean_sum_readout': sorted(correlated),
                'complete_independent_boolean_sum_readout': sorted(independent),
                'rational_zero_C2_family': '{ q*h*x*y : q in Q }',
                'count_scope': 'ONE from add_units names the retained summary, not complete source laws'}

    def maps():
        mappings = {'identity': tuple(range(8))}
        for bit, axis in enumerate(('h','x','y')):
            mappings[f'clamp_{axis}_0'] = tuple(s - ((s//(2**bit))%2)*2**bit for s in range(8))
            mappings[f'clamp_{axis}_1'] = tuple(s + (1-(s//(2**bit))%2)*2**bit for s in range(8))
            mappings[f'flip_{axis}'] = tuple(s + (1-2*((s//(2**bit))%2))*2**bit for s in range(8))
        table = tuple(Q(1,2)+h+2*x+3*y+h*x*y for h,x,y in SITES)
        receipts = []
        for scope, ops in [('full',contract),('narrow',e.ARITH_CONTRACT)]:
            env = promote(table, f'maps_{scope}', ops=ops)
            for name, mapping in mappings.items():
                named = e.apply_input_map(env, name)
                generic = e.apply_fixed_receiver_map(env, mapping)
                admitted = name in ops
                must((named.status,named.disposition) == (generic.status,generic.disposition), 'map admission mismatch')
                must((named.status == 'EXACT') == admitted, 'contract ignored')
                if admitted:
                    expected = tuple(table[mapping[s]] for s in range(7))
                    must(exact(e.read_admitted(exact(named))) == expected, 'named pullback mismatch')
                    must(exact(e.read_admitted(exact(generic))) == expected, 'generic pullback mismatch')
                receipts.append({'scope':scope,'name':name,'mapping':mapping,'status':named.status})
        return receipts

    def raw_map():
        h = e.unit('h', family='boolean_cube', contract=contract, cold_dir=None)
        mapping = tuple(h*x+2*x+4*y for h,x,y in SITES)
        certified = e.apply_fixed_receiver_map(h, mapping)
        must(certified.status == 'UNSUPPORTED', 'non-coordinate map certified')
        raw = e.apply_raw_site_map(h, mapping)
        out = exact(raw)
        reference = tuple(Q(h*x) for h,x,y in SITES)
        must(exact(e.read_admitted(out)) == reference[:7], 'raw hx wrong')
        must(coefficients(reference)[3] == 1 and sum(SITES[3]) == 2, 'hx degree oracle')
        must(out.degree_bound is None and out.contract == frozenset({'read_admitted'}), 'raw guarantees leaked')
        must(raw.witness['certified'] is False, 'raw map marked certified')
        for result in (e.add_units(out,h), e.multiply_units(out,h), e.apply_input_map(out,'flip_h')):
            must(result.status == 'UNSUPPORTED', 'raw helper gained certified continuation')
        return {'mapping':mapping, 'expected_table':reference, 'actual_retained':out.retained,
                'direct_degree':2, 'advertised_degree':out.degree_bound,
                'contract':out.contract, 'certified_status':certified.status, 'raw_witness':raw.witness}

    def transport():
        table = tuple(Q(1,3)+h+2*x+4*y+h*x*y for h,x,y in SITES)
        env = promote(table, 'transport', backed=False, ops=e.ARITH_CONTRACT)
        mapping = tuple((1-h)+2*x+4*y for h,x,y in SITES)
        e.reset_meter()
        actual = e.coherent_transport(env, mapping)
        expected = tuple((s,table[mapping[s]]) for s in range(8) if mapping[s] < 7)
        must(exact(actual) == expected, 'coherent transport mismatch')
        must(e.METER.cold_reads == 0 and actual.witness['used_cold'] is False, 'coherent answer demanded backing')
        must(tuple(s for s,v in expected) == (0,1,2,3,4,5,7), 'receiver failed to move')
        return {'mapping':mapping,'expected':expected,'actual':actual,'meter':e.meter_snapshot()}

    def backing():
        receipts = []
        for mode in ('deleted','tampered','stale_version'):
            units = [e.unit(axis, family='boolean_cube', contract=contract, cold_dir=work/'cold',
                            name=f'{mode}_{axis}') for axis in ('h','x','y')]
            path = Path(units[0].cold_route)
            original = path.read_bytes()
            (work / f'{mode}.original.json').write_bytes(original)
            if mode == 'deleted':
                path.unlink()
            elif mode == 'tampered':
                path.write_bytes(original + b'\nchanged bytes\n')
            else:
                payload = json.loads(original)
                payload['version'] = 'RCF01-envelope-1-r1'
                path.write_text(json.dumps(payload, sort_keys=True, indent=2)+'\n', encoding='utf-8')
                # Bind the actual stale bytes to exercise the context/version gate
                # beyond the ordinary digest mismatch (not merely a valid=False flag).
                units[0] = replace(units[0], cold_sha256=digest(path))
            changed_hash = digest(path) if path.exists() else None
            if path.exists():
                (work / f'{mode}.changed.json').write_bytes(path.read_bytes())
            p = exact(e.multiply_units(exact(e.multiply_units(units[0],units[1])),units[2]))
            s = exact(e.add_units(p,p))
            e.reset_meter()
            cold = e.inspect_omitted(s)
            must(cold.value is None, 'backing failure fabricated exact value')
            must(cold.status == ('UNRESOLVED' if mode == 'deleted' else 'INVALID_DEPENDENCY'), 'wrong backing status')
            if mode == 'stale_version':
                must('version' in str(cold.witness), 'stale context gate not reached')
            before_hot = e.METER.cold_reads
            hot = exact(e.read_admitted(s))
            clamped = exact(e.apply_input_map(s, 'clamp_h_0'))
            must(hot == (Q(0),)*7 and exact(e.read_admitted(clamped)) == hot, 'hot answer poisoned by cold failure')
            must(e.METER.cold_reads == before_hot, 'sufficient hot continuation reopened')
            receipts.append({'mutation':mode,'path':path,'original_sha256':hashlib.sha256(original).hexdigest(),
                             'mutated_sha256':changed_hash,'actual_file_exists':path.exists(),
                             'cold_result':cold,'hot_values':hot,'meter':e.meter_snapshot()})
        return receipts

    def dwell_and_winding():
        a = e.promote_stamp('A5', label='one')
        b = exact(e.split_center(a))
        c = exact(e.insert_midpoint(b))
        restarted = exact(e.contract_restart(c))
        dwell = [e.dwell_enabled(env) for env in (a,b,c)]
        must([r.value for r in dwell] == [True,False,True], 'dwell permission error')
        must([r.witness['type'] for r in dwell] == ['STATE','EVENT','STATE'], 'state/event conflated')
        must(b.stage == 'B6' and b.retained[0] == a.retained[0] == 3, 'count collision missing')
        must(e.count_shortcut_dwell(a.retained) and e.count_shortcut_dwell(b.retained), 'hostile count shortcut')
        must(restarted.stage == 'A5', 'declared restart failed')
        samples = []
        for w,h,r in itertools.product((-2,0,3),(0,1),(0,4)):
            start = (w,h,r)
            one = e.strong_fiving(*start)
            two = e.strong_fiving(*one)
            must(one == (w+h,1-h,r) and two == (w+1,h,r), 'winding erased')
            must(10*one[0]+5*one[1]+one[2] == 10*w+5*h+r+5, 'strong integer increment')
            must(e.fiving_display(e.fiving_display(5*h+r)) == 5*h+r, 'finite involution failed')
            samples.append({'start':start,'one':one,'two':two})
        adapter_checks = 0
        for r,h,x,y in itertools.product(range(5),(0,1),(0,1),(0,1)):
            d,xx,yy = e.adapter_A(h,x,y,r)
            must((e.fiving_display(d),xx,yy) == (5*(1-h)+r,x,y), 'finite adapter square failed')
            adapter_checks += 1
        return {'stages':[a.stage,b.stage,c.stage,restarted.stage], 'dwell':dwell,
                'summaries':[a.retained,b.retained,c.retained], 'winding_samples':samples,
                'adapter_checks':adapter_checks, 'fiving_DoubleStamp_equivalence':'OPEN'}

    for name, fn in [('DIRECT_RATIONAL_TABLES', direct_arithmetic),
                     ('HIDDEN_COMPOSED_SUM', hidden_sum), ('FALSE_BOOLEAN_ADMISSION',input_admission),
                     ('SOURCE_VERSUS_OUTPUT_FIBERS',fibers), ('NAMED_GENERIC_CONTRACT',maps),
                     ('RAW_NONAFFINE_MAP',raw_map), ('COHERENT_HOT_TRANSPORT',transport),
                     ('PHYSICAL_BACKING_DAMAGE',backing), ('DWELL_WINDING_ADAPTER',dwell_and_winding)]:
        case(name,fn)
    report = {
        'status':'PASS' if all(r['outcome']=='PASS' for r in rows) else 'FAIL',
        'scope':'Finite independent development tests; no universal soundness, speed, physics, or open-bridge claim',
        'assertions':assertions, 'results':rows,
        'context':{'command':sys.orig_argv,'package':package,'work':work,'cwd':Path.cwd(),
                   'python':sys.version,'executable':sys.executable,'platform':platform.platform(),
                   'isolated':sys.flags.isolated,'dont_write_bytecode':sys.dont_write_bytecode,
                   'PYTHONPATH_present':'PYTHONPATH' in os.environ,
                   'PYTHONHOME_present':'PYTHONHOME' in os.environ,
                   'sys_path':sys.path,'envelope_module':source,'rprm_core_module':core_path},
        'source_sha256':{str(source.relative_to(package)):digest(source),
                         str(core_path.relative_to(package)):digest(core_path),
                         'independent_direct_api.py':digest(Path(__file__))}}
    output.parent.mkdir(parents=True,exist_ok=True)
    text = json.dumps(encode(report),indent=2)+'\n'
    output.write_text(text,encoding='utf-8')
    print(text,end='')
    return 0 if report['status']=='PASS' else 2


if __name__ == '__main__':
    raise SystemExit(main())
