"""Verify Codex C1 file identities, retained R2 source, and semantic coverage.

Integrity/packaging checks only; execute run_portable.py for mathematical replay.
"""
import argparse
import hashlib
import importlib.util
import json
import re
import zipfile
from pathlib import Path, PurePosixPath

def sha(data):
    return hashlib.sha256(data).hexdigest()

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    a=p.parse_args(); root=a.root.resolve()
    failures=[]
    manifest=json.loads((root/'MANIFEST.json').read_text(encoding='utf-8'))
    files=manifest['files']
    actual={x.relative_to(root).as_posix() for x in root.rglob('*') if x.is_file()}
    assert actual == set(files)|{'MANIFEST.json'}, 'Manifest file set differs'
    for rel,rec in files.items():
        parts=PurePosixPath(rel)
        assert not parts.is_absolute() and '..' not in parts.parts and '\\' not in rel
        file=root/rel
        assert not file.is_symlink() and file.resolve().is_relative_to(root)
        data=file.read_bytes()
        assert len(data)==rec['bytes'] and sha(data)==rec['sha256'], rel
    prior=json.loads((root/'history/r2_runtime/MANIFEST.json').read_text(encoding='utf-8'))
    changed=[]
    for rel,rec in prior['files'].items():
        data=(root/rel).read_bytes()
        if sha(data)!=rec['sha256']:
            changed.append(rel)
            data=(root/'history/r2_runtime'/rel).read_bytes()
        assert len(data)==rec['bytes'] and sha(data)==rec['sha256'], rel
    expected=['README.md','run_portable.py','research/core-recovery-r2/run_portable.py',
              'research/core-recovery-r2/check_runner.py',
              'experiments/core_recovery_bridge_01_r2/prestige_envelope.py']
    assert set(changed)==set(expected), changed
    recovery=root/'research/core-recovery-01/sources/RPRM-CONCEPT-RECOVERY.zip'
    with zipfile.ZipFile(recovery) as z:
        assert z.testzip() is None
        for file in (root/'recovered_sources').iterdir():
            assert z.read(file.name)==file.read_bytes(), file.name
    validator=root/'research/core-recovery-r2/check_export.py'
    spec=importlib.util.spec_from_file_location('export_check',validator)
    module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    module.inspect_packaged_tree(root)
    semantics=module.inspect_register(root,root/'research/core-recovery-01/CONCEPT_REGISTER.json')
    # The inherited checker also labels partially deferred entries whenever
    # their evidence prose contains NOT_RUN; preserve those markers too.
    assert {'RCF-P2','RCF-P3','RCF-N1','RCF-PI1'} <= set(semantics['deferred'])
    checked_links=[]
    for doc in ('README.md','CODEX_REVIEW_AND_CLOSEOUT.md','CARRY_FORWARD_CODEX.md'):
        for link in re.findall(r'\]\(([^)]+)\)',(root/doc).read_text(encoding='utf-8')):
            if '://' in link or link.startswith('#'): continue
            path=link.split('#')[0]
            assert (root/path).exists(), (doc,path)
            checked_links.append({'document':doc,'target':path})
    report={'status':'PASS','scope':'File integrity and semantic/artifact coverage, not proof or mathematical replay',
            'manifest_files':len(files),'parent_files_preserved':len(prior['files']),
            'changed_parent_paths':sorted(changed),'semantic_coverage':semantics,
            'relative_links':checked_links,
            'envelope_sha256':sha((root/'experiments/core_recovery_bridge_01_r2/prestige_envelope.py').read_bytes()),
            'protocol_sha256':sha((root/'experiments/core_recovery_bridge_01_r2/PROTOCOL.json').read_bytes())}
    assert not a.output.exists()
    a.output.parent.mkdir(parents=True,exist_ok=True)
    a.output.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(report,indent=2))

if __name__=='__main__':
    main()
