# RCF01-R2 review — core repairs accepted; one runner-only closeout

**12 September 2026. Independent local replay and targeted review.**

## Disposition

Accept the mathematical/API repairs in R2 and preserve them as completed finite development work. The supplied package actually replays successfully. Its original three runner regressions also pass. One remaining receipt-validation weakness permits the aggregate runner to accept malformed or contradictory child reports. This does **not** invalidate the actual mathematical runs: their rows were inspected and independently checked.

A reviewer-owned patch is supplied and tested. It changes the two runner copies and their explicitly synthetic runner fixtures, not the envelope implementation, mathematical checker, proofs, or case protocol. The patched copy also completes the full replay. This is a software closeout, not another recovery or formalization campaign. The original ZIP has not been modified, and no user repository, commit, remote branch, or paper was changed.

## Input and evidence identities

Authoritative input: `RCF01-portable-r2.zip`.

SHA-256: `f33d4dfa04b4451dc3b847bd06121c9a0d1601413939e765c8e42f954102926c`, exactly matching William's supplied digest.

115 ZIP members; 114 manifest-listed files, all matching their hashes and sizes. Safe extraction rejected absolute/traversing/duplicate/symlink member names before processing. The original recovery ZIP and original source concept register match the earlier conversation attachments byte-for-byte. All 38 compared files in the historical RCF01, R1, and recovery directories match the previously reviewed R1 `dist_02` package. Those comparisons do not authenticate a remote repository history.

The replay used Linux and Python 3.13.5, with `PYTHONPATH` and `PYTHONHOME` unset and only packaged imports. Cursor's submitted Windows/Python 3.14.5 results remain separate source-reported executions. Historical donor code trees are still not supplied and were not independently replayed.

See `results/input_inventory.json`, `results/integrity_preservation.json`, and `results/final_source_identity.json`.

## 1. The submitted R2 actually runs

The unmodified `run_portable.py` exited 0. Its JSON and printed summary both report PASS:

| Required job | Exit / finding |
|---|---|
| Envelope | 0; 28/28 named rows PASS |
| Omit, duplicate, unexpected | 2 each; expected coverage-rejection receipts |
| Reorder | 0; all 28 cases preserved |
| Concept IDs | 0; 13 IDs |
| Export / record check | 0 |
| Inherited starter | 0; 12/12 named rows PASS |

Evidence: `results/replay/portable_summary.json`, individual receipts in that directory, and `results/portable_exit.txt`. The starter's 12 cases include its larger finite enumeration; 28 and 12 are named-case counts, not independent scientific systems or a summed empirical sample size.

## 2. Output-family repair accepted

Independent checks construct Boolean-valued coordinate units and form `p=(h*x)*y`, then `s=p+p`. Both backed and unbacked versions have zero C2 summaries. The product correctly remains `boolean_cube`; the sum correctly becomes `rational_cube` despite its invisible value 2 at the omitted site.

Compact multiplication and addition perform zero backing-file reads. The backed chain records three composition-recipe constructions. Reopening obtains the actual composed sum and returns 2 at the omitted site. The fixed-receiver flip exposes 2 at mask 6 without reverting to a Boolean label. Without backing, the omitted-site request and fixed-receiver flip require reopening rather than fabricate an exact result.

Twenty-four false Boolean declarations were rejected: a negative, fractional, or value-2 entry placed at each of the eight sites. The production promotion constructor therefore checks the supplied complete table rather than certifying its full type from seven visible values.

This is a sound conservative rule: Boolean multiplication is closed; ordinary rational addition is not. `ONE/EXACT` here names a unique **retained output summary**, not a unique compatible complete law. Full candidate-family propagation remains outside this API.

## 3. Map-interface repair accepted

Twenty comparisons across all ten named mappings and two operation contracts show identical named/generic admission decisions. Admitted results agree with separately calculated table pullbacks. Ten invalid-map paths reject wrong length, out-of-range, floating-point, or Boolean-as-index entries.

The generic certified path rejects the non-coordinate map `(0,0,0,1,0,0,0,1)`. Its explicitly raw counterpart evaluates the expected `hx` values, has no degree bound, carries `certified=false`, and retains only the read-admitted contract. A subsequent certified flip or multiplication is refused.

A separate exact table oracle checks 16 constructed input pairs through six arithmetic/map steps each: 96 composed steps, 768 value comparisons. All agree; all advertised Boolean families and degree bounds remain sound for these cases. Forty-eight cube symmetries also preserve the coherently transported hot receiver without backing.

Physical corruption/deletion of a required composed-result dependency gives INVALID_DEPENDENCY / UNRESOLVED, not an exact fabricated omitted value. Restoring the dependency restores the exact value. Independently sufficient hot answers remain available during the backing-file failure.

Evidence for sections 2–3: `independent_api_checks.py` and `results/independent_api.json`. These are constructed development checks with a direct-table reference, not holdout evaluation, historical donor replay, a speed contest, or proof of arbitrary Python correctness.

## 4. Original runner faults fixed; receipt validation remains incomplete

The producer's five runner-only fixtures were rerun. A failed starter, failed export check, and unrelated negative-control crash now yield exit 2 and consistent FAIL summaries. A valid fixture passes. Explicit starter skipping produces the stated narrower scope. Evidence: `results/runner_controls.json`.

However, `check_pass_receipt` still trusts the top-level PASS too much. In disposable package copies, the actual runner was supplied these fixture outputs for its envelope child:

| Fixture receipt | Submitted R2 aggregate |
|---|---|
| Valid complete receipt | PASS, exit 0 — correct |
| `{"status":"PASS"}` with no results | PASS, exit 0 — incorrect |
| PASS with an empty results list | PASS, exit 0 — incorrect |
| PASS with a failed case row | PASS, exit 0 — incorrect |
| PASS with a missing, duplicate, or unexpected case ID | PASS, exit 0 — incorrect in each case |
| A JSON array rather than an object | Parent exception, exit 1, no structured summary |

These are **reporting fault injections**, not new mathematical runs. The fast fixtures reuse prior good receipts to isolate runner behavior. The genuine mathematical runner did not emit these malformed records during either full replay. Export validation remained active; it does not hash-pin substituted checker bytes. No claim of bypassing the delivered source-hash check is made.

Evidence: `review_runner_receipts.py`, `results/runner_receipt_faults_extended.json`, and the corresponding actual subprocess summaries under `results/receipt_fixture_details/original/`.

## 5. Tested reviewer patch

`patch/runner_receipt_validation.patch` adds object validation, mandatory nonempty typed case rows, all-case PASS checking, and exact unique case-ID coverage against the existing protocol. It handles non-object JSON as structured FAIL. It does not derive required cases from emitted rows or add a new registry.

The runner-only producer fixtures are updated to emit schema-valid, explicitly synthetic records. That is fixture maintenance, not replacing missing mathematical evidence.

On the reviewer candidate:

- All five existing producer runner scenarios pass.
- The eight receipt scenarios correctly preserve the valid case and reject the seven malformed/contradictory cases.
- The unchanged mathematical suite replays again: envelope 28/28, starter 12/12; expected controls, IDs, and export validation all pass; aggregate exit 0.

Evidence: `results/candidate_producer_controls.json`, `results/candidate_runner_receipts_extended.json`, and `results/candidate_replay_02/portable_summary.json`.

Candidate runner SHA-256: `6eecfc75085bcd15283b0a419edcccc0e75ed0205cac5bdb3f5bcf4072b6791a`.

Envelope SHA-256 remains `bebf2c25d26f2ecf92e3366082aaf38f4d379e18ac06ea0f1d9294ecc64ee3a8`; protocol remains `33ea582ebd832869c204cac061360899c8e9b7b39b5c668adb1ea2f7b61d8508`.

The candidate has fresh reviewer-owned manifest metadata; it is not Cursor's official release or a retroactive preregistration. One earlier combined tool invocation was interrupted by a tool timeout. Its partial candidate receipts are retained and explicitly NOT_COMPLETED; only the fresh `candidate_replay_02` is counted as the completed candidate replay.

## 6. What should be carried forward

The finite exact-reuse branch now demonstrates compact arithmetic, composed-result reconstruction through retained recipes, sound operation-specific output classes, declared map admission, coherent transport, and distinct dependency-failure outcomes. These are useful completed capabilities, not merely names in a register.

The fiving-splice to Double-Stamp restart bridge remains OPEN. Deferred concepts remain NOT_RUN. The broader Prestige One lifecycle, original number-operation vocabulary, approximate regrouping, and LawCube/RelationForge integrations are not settled by this prototype. No physical-safety, universal compression, performance, or independent scientific discovery claim is added.

**Recommended disposition:** accept and freeze R2's core results; integrate the tested runner guard in a clearly identified successor export; then close this review lane. No new mathematical assignment is needed to finish this software repair.
