"""Deliberately unsafe ablation: drop joint boundary relation, keep marginals."""

from __future__ import annotations

from itertools import product

from .grammar import group_sat_masks, project_mask
from .ir import Factor, Kind, factor_holds
from .grammar import clause_from_lits


def triangle_unsafe_counterexample() -> dict:
    """Preserve a concrete counterexample: two DIFFERENT edges vs the third.

    Block: a!=b, b!=c. Joint boundary relation is a==c.
    Unsafe: keep only that a and c are each individually {0,1}.
    Rest: a!=c is then SAT, while the original formula is UNSAT.
    """
    clauses = [(1, 2), (-1, -2), (2, 3), (-2, -3), (3, 1), (-3, -1)]
    factors = [clause_from_lits(c, fid=i + 1) for i, c in enumerate(clauses)]
    block = factors[:4]
    rest = factors[4:]
    scope = (1, 2, 3)
    sat = group_sat_masks(block, scope, {"table_rows": 0})
    boundary = (1, 3)
    joint = project_mask(scope, sat, boundary)
    n_b = len(boundary)
    joint_rows = []
    for mask in range(1 << n_b):
        if (joint >> mask) & 1:
            joint_rows.append({boundary[i]: (mask >> i) & 1 for i in range(n_b)})
    # individual permitted values
    allowed = {1: {0, 1}, 3: {0, 1}}
    unsafe_sat_rest = []
    for bits in product((0, 1), (0, 1)):
        asg = {1: bits[0], 3: bits[1], 2: 0}
        rest_ok = all(factor_holds(f, asg) for f in rest)
        in_joint = asg[1] == asg[3]
        if rest_ok and not in_joint:
            unsafe_sat_rest.append(asg)
    original_unsat = True
    # original all six clauses
    unsat = True
    for mask in range(8):
        asg = {1: mask & 1, 2: (mask >> 1) & 1, 3: (mask >> 2) & 1}
        if all(factor_holds(f, asg) for f in factors):
            unsat = False
            break
    return {
        "name": "triangle_two_edges_vs_third",
        "original_unsat": unsat,
        "joint_boundary_rows": joint_rows,
        "unsafe_cartesian_sat_with_rest": unsafe_sat_rest,
        "unsafe_unsound": bool(unsafe_sat_rest) and unsat,
        "kept_out_of_candidate": True,
    }
