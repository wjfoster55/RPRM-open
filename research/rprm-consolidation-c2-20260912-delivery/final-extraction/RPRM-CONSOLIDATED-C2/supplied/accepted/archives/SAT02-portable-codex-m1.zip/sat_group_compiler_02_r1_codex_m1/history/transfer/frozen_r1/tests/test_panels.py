from __future__ import annotations

import unittest

from sat_group_compiler.backends import get_probe, independent_label, signed_graph_baseline
from sat_group_compiler.compiler import compile_cnf
from sat_group_compiler.controls import add_tautologies, complement_cnf, duplicate_some_clauses, rename_cnf, reorder_cnf
from sat_group_compiler.dimacs import parse_dimacs
from sat_group_compiler.generators import different_cycle, triangle_fixture
from sat_group_compiler.ir import cnf_holds
from sat_group_compiler.protocol import load_protocol, stage_limits


def limits():
    return stage_limits(load_protocol(), "smoke", "W3")


TRI = "p cnf 3 6\n1 2 0\n-1 -2 0\n2 3 0\n-2 -3 0\n3 1 0\n-3 -1 0\n"


class ControlTests(unittest.TestCase):
    def test_triangle_unsat_survives_presentation(self):
        variants = [
            TRI,
            rename_cnf(TRI, {1: 3, 2: 1, 3: 2}),
            complement_cnf(TRI, {2}),
            reorder_cnf(TRI, 3),
            duplicate_some_clauses(TRI, 3),
            add_tautologies(TRI, 3),
        ]
        for text in variants:
            result = compile_cnf(text, mode="C", limits=limits(), variant="W3")
            self.assertEqual(result.status, "UNSAT", msg=result.derivation)

    def test_sat_witness_maps_under_complement(self):
        text = "p cnf 2 2\n1 0\n-2 0\n"
        r = compile_cnf(text, mode="A", limits=limits())
        self.assertEqual(r.status, "SAT")
        flipped = complement_cnf(text, {1})
        r2 = compile_cnf(flipped, mode="A", limits=limits())
        self.assertEqual(r2.status, "SAT")
        self.assertEqual(r2.assignment[1], 0)
        self.assertEqual(r2.assignment[2], 0)


class SignedGraphBaselineTests(unittest.TestCase):
    def test_odd_unsat_even_sat(self):
        odd = different_cycle(5, 23, "development")
        even = different_cycle(6, 23, "development")
        p_odd = parse_dimacs(odd.dimacs)
        p_even = parse_dimacs(even.dimacs)
        self.assertEqual(signed_graph_baseline(p_odd.n_vars, p_odd.clauses).status, "UNSAT")
        self.assertEqual(signed_graph_baseline(p_even.n_vars, p_even.clauses).status, "SAT")
        c_odd = compile_cnf(odd.dimacs, mode="B", limits=limits())
        c_even = compile_cnf(even.dimacs, mode="B", limits=limits())
        self.assertEqual(c_odd.status, "UNSAT")
        self.assertEqual(c_even.status, "SAT")
        self.assertTrue(cnf_holds(p_even.clauses, c_even.assignment))

    def test_oracle_matches_triangle(self):
        p = parse_dimacs(TRI)
        lab = independent_label(p.n_vars, p.clauses, 12, 5)
        self.assertEqual(lab.status, "UNSAT")
        self.assertEqual(lab.method, "exhaustive")


class ProbeTests(unittest.TestCase):
    def test_probe_reports(self):
        probe = get_probe()
        self.assertIn("closure_sat", probe)
        self.assertIn("affine", probe)
        self.assertIn("pysat", probe)
        self.assertTrue(probe.get("stdlib_gf2"))


if __name__ == "__main__":
    unittest.main()
