"""Load frozen protocol_v2.json, stage limits, and variant overlays."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any

PROTOCOL_DIR = Path(__file__).resolve().parent.parent
PROTOCOL_PATH = PROTOCOL_DIR / "protocol_v2.json"


def canonical_json_bytes(obj: object) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode("utf-8")


def load_protocol() -> dict[str, Any]:
    text = PROTOCOL_PATH.read_text(encoding="utf-8")
    data = json.loads(text)
    if not isinstance(data, dict):
        raise TypeError("protocol_v2.json must be an object")
    return data


def protocol_sha256(data: dict[str, Any] | None = None) -> str:
    payload = data if data is not None else load_protocol()
    return hashlib.sha256(canonical_json_bytes(payload)).hexdigest()


def stage_limits(
    protocol: dict[str, Any],
    stage: str,
    variant: str | None = None,
) -> dict[str, float | int | bool | str]:
    limits = protocol["limits"][stage]
    group = protocol["group_rule"]
    out: dict[str, float | int | bool | str] = {
        "max_seconds": float(limits["max_seconds"]),
        "max_candidates": int(limits["max_candidates"]),
        "max_rewrites": int(limits["max_rewrites"]),
        "max_table_rows": int(limits["max_table_rows"]),
        "max_factors": int(group["max_factors"]),
        "max_scope": int(group["max_scope"]),
        "max_temp_table_vars": int(protocol["temporary_table"]["max_vars"]),
        "max_speculation_depth": int(protocol["temporary_table"]["max_speculation_depth"]),
        "max_beam": int(protocol["temporary_table"]["max_beam"]),
        "max_temp_tables": int(protocol["temporary_table"]["max_tables"]),
        "allow_temp_table": False,
        "use_support_index": False,
        "cache_policy": str(protocol["cache_policy_default"]),
        "variant": variant or "",
    }
    if variant:
        spec = protocol["variants"][variant]
        out["max_factors"] = int(spec["max_factors"])
        out["max_scope"] = int(spec.get("max_scope", out["max_scope"]))
        out["allow_temp_table"] = bool(spec.get("allow_temp_table", False))
        out["use_support_index"] = bool(spec.get("use_support_index", False))
        out["variant"] = variant
    return out
