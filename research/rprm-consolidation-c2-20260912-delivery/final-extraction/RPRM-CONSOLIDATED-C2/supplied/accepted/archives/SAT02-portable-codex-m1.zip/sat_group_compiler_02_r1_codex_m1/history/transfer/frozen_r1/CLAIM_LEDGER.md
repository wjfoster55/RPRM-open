# SAT02-R1 claim ledger

**Carrier:** Boolean `{0,1}` for Stage 1 specimens; declared native `{0,1,2}` for the three-color specimen. Not a P=NP claim. Not a new general proof system.

**Evidence grades used here:** finite test; original-run record; independent review replay; successor regression; withdrawn or narrowed claim.

| Claim | Domain | Fiber | Grade | Status |
| --- | --- | --- | --- | --- |
| Protected 3-variable XOR / four-clause parity is recovered by W4 as `P:1,2,3=1` under explicit retain `{1,2,3}` | that fixture, retain contract | ONE | finite test + original run + review replay | **accepted** |
| Ordinary W3 does not recover that parity atom in one 2–3-factor grammar group | same fixture | ONE | finite test | **accepted** |
| W3-T takes exact TABLE `TBL:1,2,3:97` with structural cost 15→18, then 23→6 to parity, without enlarging the window | same fixture | ONE | finite test | **accepted**; not a universal SAT shortcut |
| Native star: `exists X (X≠A ∧ X≠B ∧ X≠C)` iff `|{A,B,C}|≤2` on `{0,1,2}`; 21/27 extendable; pair projections all 9 | declared 3-color carrier | ONE | known restatement + finite test | **accepted** |
| Two overlapping `USES_AT_MOST_2_COLORS` factors accept 147/243 assignments; the union atom accepts 93/243; separator `(0,0,1,1,2)` | two-star specimen | ONE | finite test | **accepted** |
| Saved SAT02 decisive SAT/UNSAT and SAT witnesses on reconstructed generators | 466 saved rows, n≤12 | ONE within that reconstruction | independent review 239/239 and 323/323 | **accepted as original-run mathematics**; not a replay of original dispatch bytes |
| 982 local transform/recovery receipts pass a separate math check | saved receipts | ONE within that interpreter | independent review | **accepted**; local check ≠ whole-chain proof |
| Ten-seed protocol was fully executed | declared seeds `{23,29,31,37,41}` and `{20011,20021,20047,20063,20089}` | NONE as a complete fiber | original generator uses `seeds[0]` then `seeds[1:3]` | **rejected as a completed-protocol claim**; 6 run / 4 NOT_RUN |
| Connected-group generator enumerates every connected subset under the declared caps, independent of ID order | incidence graph, declared max_factors/max_scope | original SAT02: NONE (missed 2 of 6 ID orders on path 1—3—2); successor: ONE vs exhaustive oracle on that specimen | finite test | original **incomplete**; successor **repaired** |
| Receipt checker certifies closed-form / complete table recovery and is a whole-solver derivation | stored group identities | original checker: MANY false accepts; successor: local relation check only | finite test | original **rejected**; successor **local_relation_checked** only |
| `max_table_rows` is a complete work budget; `wall_s` is end-to-end including receipt checks; freeze source digest is a frozen input identity | original measuring apparatus | NONE as advertised | review diagnostics | **narrowed / withdrawn** as complete claims; successor accounts template/projection separately, includes checker in `wall_s`, excludes `versions.json` from source digest |
| Panel tallies are a clean speed ranking of W3/W4/W3-T/W4-I | development/evaluation 22-instance splits | OPEN | descriptive counts only | **not accepted** as certification |
| No compact combination of overlapping at-most-two-color factors exists | two-star specimen | NONE as a general impossibility | conceptual correction | **rejected**; no *single named atom* on the union is supported; the pair is already compact |

## Original SAT02 status (authoritative)

SAT02 was completed locally and has now been reviewed. Its local exact results are accepted; its protocol coverage is partial; its comparative and certification claims need correction or explicit narrowing.
