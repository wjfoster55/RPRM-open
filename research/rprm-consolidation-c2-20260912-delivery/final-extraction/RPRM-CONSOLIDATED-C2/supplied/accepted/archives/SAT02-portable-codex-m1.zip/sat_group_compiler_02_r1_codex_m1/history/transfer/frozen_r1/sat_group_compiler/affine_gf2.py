"""Known GF(2) Gaussian elimination. Baseline algebra, not discovery."""

from __future__ import annotations


def gf2_solve(
    equations: list[tuple[tuple[int, ...], int]],
    n_vars: int,
) -> tuple[str, dict[int, int] | None, str]:
    """Solve xor-equations over GF(2). Each equation is (variables, rhs)."""
    cols = list(range(1, n_vars + 1))
    col_index = {var: i for i, var in enumerate(cols)}
    rows: list[list[int]] = []
    for vars_, rhs in equations:
        if rhs not in (0, 1):
            raise ValueError("non-binary GF(2) rhs")
        row = [0] * (n_vars + 1)
        for var in vars_:
            row[col_index[var]] ^= 1
        row[-1] = int(rhs) & 1
        rows.append(row)
    rank = 0
    pivot_for_col = [-1] * n_vars
    for col in range(n_vars):
        pivot = None
        for r in range(rank, len(rows)):
            if rows[r][col]:
                pivot = r
                break
        if pivot is None:
            continue
        rows[rank], rows[pivot] = rows[pivot], rows[rank]
        pivot_for_col[col] = rank
        for r in range(len(rows)):
            if r != rank and rows[r][col]:
                for c in range(col, n_vars + 1):
                    rows[r][c] ^= rows[rank][c]
        rank += 1
    for row in rows:
        if not any(row[:n_vars]) and row[-1]:
            return "UNSAT", None, "stdlib_gf2_gaussian"
    assignment = {var: 0 for var in range(1, n_vars + 1)}
    for col in range(n_vars - 1, -1, -1):
        pr = pivot_for_col[col]
        if pr < 0:
            continue
        acc = rows[pr][-1]
        for c in range(col + 1, n_vars):
            if rows[pr][c]:
                acc ^= assignment[cols[c]]
        assignment[cols[col]] = acc
    return "SAT", assignment, "stdlib_gf2_gaussian"
