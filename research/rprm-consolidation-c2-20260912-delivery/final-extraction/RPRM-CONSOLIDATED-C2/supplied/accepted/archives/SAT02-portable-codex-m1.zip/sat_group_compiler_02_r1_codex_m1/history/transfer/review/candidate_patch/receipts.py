"""Independently checkable receipts. Does not re-invoke the compiler or trust validation strings."""

from __future__ import annotations

import json
from typing import Any

from .arithmetic import penalty_from_clauses
from .encode import factors_to_clauses
from .grammar import group_sat_masks, project_mask
from .ir import Factor, Kind, canonical_json_bytes, cnf_holds, parse_canon
from .signed_uf import SignedUF


def receipt_payload(receipt: Any) -> dict[str, Any]:
    return {
        "input_factor_ids": list(receipt.input_factor_ids),
        "input_identities": list(receipt.input_identities),
        "boundary": list(receipt.boundary),
        "eliminated": list(receipt.eliminated),
        "replacement": list(receipt.replacement),
        "promise": receipt.promise,
        "scope": list(receipt.scope),
        "group_sat_mask": receipt.group_sat_mask,
        "orig_cost": receipt.orig_cost,
        "new_cost": receipt.new_cost,
        "recovery": receipt.recovery,
        "note": receipt.note,
        "speculative": receipt.speculative,
    }


def serialized_receipts_bytes(receipts: list[Any]) -> bytes:
    return canonical_json_bytes([receipt_payload(r) for r in receipts])


def _apply_closed_form(recov_map: dict[Any, Any], boundary_asg: dict[int, int]) -> dict[int, int] | None:
    result = dict(boundary_asg)
    pending = [(int(var), spec) for var, spec in recov_map.items()]
    progressed = True
    while pending and progressed:
        progressed = False
        remaining: list[tuple[int, Any]] = []
        for var, spec in pending:
            if not isinstance(spec, (list, tuple)) or len(spec) < 2:
                return None
            kind, arg = spec[0], spec[1]
            if kind == "const":
                result[var] = int(arg)
                progressed = True
                continue
            lit = int(arg)
            src = abs(lit)
            if src not in result:
                remaining.append((var, spec))
                continue
            bit = result[src]
            result[var] = bit if lit > 0 else 1 - bit
            progressed = True
        pending = remaining
    if pending:
        return None
    return result


def _admitted_boundary_assignments(
    scope: tuple[int, ...],
    sat_mask: int,
    boundary: tuple[int, ...],
) -> list[dict[int, int]]:
    n = len(scope)
    seen: set[tuple[int, ...]] = set()
    rows: list[dict[int, int]] = []
    for mask in range(1 << n):
        if not (sat_mask >> mask) & 1:
            continue
        asg = {scope[i]: (mask >> i) & 1 for i in range(n)}
        key = tuple(asg[v] for v in boundary)
        if key in seen:
            continue
        seen.add(key)
        rows.append({v: asg[v] for v in boundary})
    return rows


def check_rewrite_receipt(receipt: dict[str, Any]) -> dict[str, Any]:
    """Replay the claimed local transformation from stored identities and masks.

    Trusts neither receipt['validation'] nor a second compile_cnf call.
    This is a local relation/recovery check on the stored group. It does not
    bind original live factor IDs or replay a whole-solver derivation.
    """
    reasons: list[str] = []
    promise = receipt.get("promise")
    try:
        inputs = [parse_canon(s, fid=i + 1) for i, s in enumerate(receipt["input_identities"])]
        repl = [parse_canon(s, fid=1000 + i) for i, s in enumerate(receipt["replacement"])]
    except Exception as exc:
        return {"ok": False, "grade": "rejected", "reasons": [f"parse:{exc}"]}
    scope = tuple(int(v) for v in receipt["scope"])
    boundary = tuple(int(v) for v in receipt["boundary"])
    eliminated = tuple(int(v) for v in receipt["eliminated"])
    bset, eset, sset = set(boundary), set(eliminated), set(scope)
    if bset & eset or bset | eset != sset:
        reasons.append("scope_partition")
    meter = {"table_rows": 0}
    recomputed = group_sat_masks(inputs, scope, meter)
    stored = int(receipt.get("group_sat_mask") or 0)
    if recomputed != stored:
        reasons.append("stored_group_sat_mask_mismatch")
    if promise == "B":
        if eliminated:
            reasons.append("promise_B_with_eliminated_vars")
        repl_mask = group_sat_masks(repl, scope, meter)
        if repl_mask != recomputed:
            reasons.append("promise_B_sat_set_mismatch")
    elif promise == "C":
        keep = boundary
        if not keep:
            want_false = recomputed == 0
            got_false = any(f.kind is Kind.FALSE for f in repl)
            got_true = (not repl) or all(f.kind is Kind.TRUE for f in repl)
            if want_false != got_false:
                reasons.append("empty_boundary_false_mismatch")
            if not want_false and not got_true and not got_false:
                reasons.append("empty_boundary_not_true")
        else:
            proj = project_mask(scope, recomputed, keep)
            repl_mask = group_sat_masks(repl, keep, meter)
            if proj != repl_mask:
                reasons.append("promise_C_projection_mismatch")
        recov = receipt.get("recovery") or {}
        # No satisfying input means no boundary assignment needs a witness.
        # This uses the independently recomputed relation, not the stored mask.
        if eliminated and recomputed:
            recov_type = recov.get("type")
            admitted = _admitted_boundary_assignments(scope, recomputed, boundary)
            if recov_type == "closed_form":
                recov_map = recov.get("map") or {}
                if not recov_map:
                    reasons.append("recovery_missing")
                elif set(map(int, recov_map)) != eset:
                    # Recover only the removed variables; retain the boundary.
                    reasons.append("recovery_output_scope")
                else:
                    for boundary_asg in admitted:
                        recovered = _apply_closed_form(recov_map, boundary_asg)
                        if recovered is None:
                            reasons.append("recovery_missing")
                            break
                        if not set(eliminated) <= set(recovered):
                            reasons.append("recovery_missing")
                            break
                        if any(recovered.get(v) != bit for v, bit in boundary_asg.items()):
                            reasons.append("recovery_changes_boundary")
                            break
                        if any(recovered.get(v) not in (0, 1) for v in scope):
                            reasons.append("recovery_nonbinary")
                            break
                        if not all(factor_holds_safe(f, recovered) for f in inputs):
                            reasons.append("recovery_wrong")
                            break
            elif recov_type == "lex_table":
                rows = recov.get("rows") or []
                for boundary_asg in admitted:
                    matches = [
                        row
                        for row in rows
                        if {int(k): int(v) for k, v in row.get("boundary", {}).items()} == boundary_asg
                    ]
                    if len(matches) != 1:
                        reasons.append("recovery_row_coverage")
                        break
                    internal = {int(k): int(v) for k, v in matches[0].get("internal", {}).items()}
                    if set(internal) != eset:
                        reasons.append("recovery_output_scope")
                        break
                    if any(bit not in (0, 1) for bit in internal.values()):
                        reasons.append("recovery_nonbinary")
                        break
                    asg = dict(boundary_asg)
                    asg.update(internal)
                    if not set(eliminated) <= set(asg):
                        reasons.append("recovery_row_coverage")
                        break
                    if not all(factor_holds_safe(f, asg) for f in inputs):
                        reasons.append("recovery_row_misses_original_group")
                        break
            else:
                reasons.append("recovery_missing")
    elif promise == "A":
        orig_clauses = tuple(factors_to_clauses(inputs))
        new_clauses = tuple(factors_to_clauses(repl))
        orig_pen = penalty_from_clauses(orig_clauses)
        new_pen = penalty_from_clauses(new_clauses)
        n = max(scope) if scope else 1
        for mask in range(1 << max(len(scope), 1)):
            asg = {var: 0 for var in range(1, n + 1)}
            for i, var in enumerate(scope):
                asg[var] = (mask >> i) & 1
            if orig_pen.evaluate(asg) != new_pen.evaluate(asg):
                reasons.append("promise_A_penalty_mismatch")
                break
    else:
        reasons.append(f"unknown_promise:{promise}")

    if any(f.kind is Kind.TABLE for f in repl) and not receipt.get("speculative"):
        reasons.append("table_presented_as_ordinary_compression")
    ok = not reasons
    return {
        "ok": ok,
        "grade": "local_relation_checked" if ok else "rejected",
        "reasons": reasons,
        "table_rows_replayed": meter["table_rows"],
        "did_not_trust_validation_string": True,
        "did_not_invoke_compiler": True,
        "binds_original_factor_ids": False,
        "whole_solver_derivation_replayed": False,
    }


def factor_holds_safe(factor: Factor, assignment: dict[int, int]) -> bool:
    from .ir import factor_holds

    try:
        return factor_holds(factor, assignment)
    except Exception:
        return False


def check_signed_uf_conflict(identities: list[str]) -> dict[str, Any]:
    factors = [parse_canon(s, fid=i + 1) for i, s in enumerate(identities)]
    uf = SignedUF()
    for factor in factors:
        if factor.kind is Kind.UNIT:
            if not uf.assign(abs(factor.lits[0]), 1 if factor.lits[0] > 0 else 0):
                return {"ok": True, "grade": "checked_derivation", "kind": "signed_uf_conflict"}
        elif factor.kind is Kind.SAME:
            if not uf.union(factor.lits[0], factor.lits[1], False):
                return {"ok": True, "grade": "checked_derivation", "kind": "signed_uf_conflict"}
        elif factor.kind is Kind.DIFFERENT:
            if not uf.union(factor.lits[0], factor.lits[1], True):
                return {"ok": True, "grade": "checked_derivation", "kind": "signed_uf_conflict"}
        elif factor.kind is Kind.FALSE:
            return {"ok": True, "grade": "checked_derivation", "kind": "false_factor"}
    return {"ok": False, "grade": "rejected", "kind": "no_conflict_replayed"}


def corrupt_receipt(receipt: dict[str, Any], kind: str) -> dict[str, Any]:
    out = json.loads(json.dumps(receipt))
    if kind == "wrong_mapping":
        if out.get("recovery", {}).get("map"):
            key = next(iter(out["recovery"]["map"]))
            out["recovery"]["map"][key] = ["const", 1 - int(out["recovery"]["map"][key][1] or 0)]
        else:
            out["boundary"] = [999]
    elif kind == "wrong_recovery_bit":
        recov = out.setdefault("recovery", {"type": "closed_form", "map": {}})
        recov["type"] = "closed_form"
        recov["map"] = {"1": ["const", 1]}
    elif kind == "illegal_elimination":
        out["eliminated"] = list(out.get("boundary") or [1])
        out["promise"] = "C"
    elif kind == "mask_flip":
        out["group_sat_mask"] = int(out.get("group_sat_mask") or 0) ^ 1
    else:
        raise ValueError(kind)
    return out
