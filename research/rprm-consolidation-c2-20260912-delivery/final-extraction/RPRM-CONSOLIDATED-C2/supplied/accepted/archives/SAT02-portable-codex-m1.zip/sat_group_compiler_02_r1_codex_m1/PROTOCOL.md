# PROTOCOL v2 — SAT grouped-representation compiler experiment 02

Frozen before outcome panels. Revisions after seeing evaluation results require a new version and new holdout seeds.

**Carriers:** Boolean `{0,1}` for Stage 1. Declared native `{0,1,2}` for Stage 2 only. Not the RPRM centered-half carrier, not a real relaxation. GF(2) is used only after a residual is certified affine and handed to a labeled baseline.

**Claim ceiling:** exploratory preprocessor plus a small native three-color specimen. `UNRESOLVED` / `RESOURCE_LIMIT` / `SKIPPED` are valid. This protocol does not support a `P=NP` claim.

## Candidate versus evaluator

The Boolean candidate receives DIMACS CNF bytes, this public configuration, and (when the local test contract says so) an explicit retained-variable list. It does not receive family labels, planted witnesses, block labels, expected parity bits, or human elimination orders.

## Promises (do not exchange)

- **A.** Exact penalty/function equality on the binary domain.
- **B.** Identical zero set on the same named variables.
- **C.** Exact existential projection onto a declared boundary, with witness recovery.

Removing duplicate clauses is B, not A. Duplicate literals in one clause are A (`x²=x` on `{0,1}`).

## Group generation (repair versus v1)

Connected groups are generated lazily from the variable-incidence graph. Disconnected tuples are not materialised. Deadline, candidate, rewrite, and table-row checks run during generation. Scope and group-size caps come from configuration (`protocol_v2.json` and the selected variant), not from hard-coded 6 / 2 / 3 in the compiler.

## Variants (Stage 1)

Same repaired core, ordinary replacement scoring, scope cap, and applicable budgets:

| Arm | Window | Temporary TABLE | Index |
| --- | --- | --- | --- |
| W3 | 2–3 factors | no | no |
| W4 | 2–4 factors | no | no |
| W3-T | 2–3 factors | yes, ≤6 Boolean vars, depth/beam/table caps | no |
| W4-I | 2–4 factors | no | public same-support / incidence index first |

A TABLE is not compression because it has one object ID. W3-T may take a first step that does not shrink cost. Leftover TABLE residuals are `UNRESOLVED`, not a decision.

Mode A remains normalize + UP. Mode B is pairs only. Mode C without a variant uses the protocol `group_rule.max_factors` (3).

## Recognition versus solving

Recovering `P:x,y,z=b` under contract B on all eight named assignments is the XOR recognition success criterion. Replacing an isolated block by `TRUE` after finding one assignment is not parity recognition. Known GF(2) elimination may close an eligible recovered parity residual; it is not a general mixed XOR/OR solver.

## Measurement

Exclusive phase times: parse, initial simplify, group generation, recognition, selection, validation, recovery, rewrite apply, rewrite native-close, residual encode, affine. Independent `wall_s` from the start of `compile_cnf`. Do not reconstruct total time by summing overlapping counters.

Hybrid totals: candidate `wall_s` + residual solver seconds + lift seconds, each once.

Proof/recovery/witness sizes are actual serialized JSON bytes. Initial IR bytes are recorded before simplification. Peak process RSS is a labeled OS observation, not an exact sum of object sizes.

Cache policy is explicit: default `cold` (clear recognition templates at the start of a run). `warm` is opt-in.

Solver timeouts are enforced by killing a worker process. Time-limit outcomes are `RESOURCE_LIMIT`, never `UNSAT`.

## Receipts

Each grouping rewrite stores input identities, scope, sat-mask, boundary, eliminated variables, replacement, promise, and recovery. An independent checker replays the local transformation from those identities. It does not invoke the compiler and does not trust the `validation` string. Compiler-local checks plus oracle agreement are not automatically an independently replayed UNSAT proof. Unsupported proof checking (DRAT) is recorded as not checked.

## Fingerprints

A claimed reproduction must match protocol SHA-256, source SHA-256, effective configuration, and dependency versions (Python, python-sat, optional NariZoo imports). Protocol hash alone is not enough.

## Seeds

Development: `23, 29, 31, 37, 41`.
Evaluation: `20011, 20021, 20047, 20063, 20089`.
V1 evaluation seeds `{10007, 10009, 10037, 10039, 10061}` are regressions, not fresh holdouts.

## Stage 2 (declared native)

Variables in `{0,1,2}`. Internal center `X` with neighbors `A,B,C` and `X≠A, X≠B, X≠C` projects to `USES_AT_MOST_2_COLORS(A,B,C)`. Do not enumerate `3^k` to construct the k-neighbor rule. Automatic recovery of this carrier from raw CNF is not required.

## Commands

From `experiments/sat_group_compiler_02/`:

```powershell
$env:PYTHONPATH = (Get-Location).Path
python run.py freeze
python run.py verify-seed
python run.py test
python run.py watchdog
python run.py smoke
python run.py stress
python run.py stage1
python run.py stage2
python run.py panels --split development
python run.py panels --split evaluation
python run.py controls
python run.py unsafe
python run.py minimality
```
