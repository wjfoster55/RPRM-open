# SAT02–Codex M1: integrate the remaining local-checker maintenance and close out

**12 September 2026 · This is the single active assignment.**

William is transferring the remaining SAT02 maintenance to Codex. The research
closeout is accepted. The last owner response explicitly left the candidate
`REVIEWER_TESTED_NOT_INTEGRATED`, awaiting a later integration instruction.
**This handoff is that instruction: inspect, integrate, verify, export, and close
out the bounded checker correction now.** Do not return only another acceptance
note, plan, or suggestion to integrate later.

This is not Task03. It is not a fresh SAT benchmark, a new proof system, a paper
revision, or permission to activate Fluid or Yang–Mills. The supplied one-file
candidate is prior evidence to inspect, not a patch to trust blindly.

## 1. Authority and source reconciliation

Read applicable workspace `AGENTS.md`, then `CURRENT_STATE.md`, the latest
`status/CLOSEOUT_R1_STATUS.md`, and the focused source set below. Record your real
workspace, current Git HEAD/status when available, Python version, and command
paths. Do not assume a historical Windows path points to these exact bytes.

The uploaded submitted R1 is in `inputs/sat_group_compiler_02_r1.zip`, with an exact
extraction in `frozen_r1/`. Verify `INPUT_BINDINGS.json` and `HANDOFF_MANIFEST.json`
using `verify_handoff.py` before execution. Source hashing is transfer evidence,
not proof of the mathematical statements.

Keep this entire handoff, its archives, and its historical evidence read-only.
Create a new work area OUTSIDE it and outside the user's existing R1 tree; use
fresh paths such as `sat_group_compiler_02_r1_codex_m1`. If a chosen destination
exists, choose a fresh one—never reset, delete, overwrite, or discard local work.
One owner/writer is enough; do not start parallel lane workers or competing
worktrees for this maintenance.

The status overlay names a candidate at a historical relative path. Use the
actual packaged candidate at `review/candidate_patch/`. No missing local path
needs an archive hunt or user re-upload. Original SAT02 panels are supplied as
saved bytes; the full source archive also remains available under `inputs/`.

No commit, stage, push, merge, publication, paper-source edit, package installation,
paid compute, secret access, held-out evaluation access, or unrelated project
restart is authorized. Return requested deliverables through the task's normal
artifact/attachment mechanism, not an external upload or remote repository write.
Old prompts in copied trees are historical; this top-level assignment supersedes
them procedurally for M1 only.

## 2. Focused reading; do not restart discovery

Read:

- `status/CLOSEOUT_R1_STATUS.md`, the latest meaning of the owner closeout;
- `review/REVIEW.md`, especially the two remaining checker issues, candidate
  explanation, and known review-run limitations;
- `review/CLOSEOUT_MESSAGE.md`;
- `review/candidate_patch/PATCH_IDENTITY.json`, the small diff, replacement
  `receipts.py`, `apply_to_fresh_copy.py`, and the six regression tests;
- the actual R1 `sat_group_compiler/receipts.py`, its recovery evaluator, and the
  minimal related IR/compiler code needed to inspect that contract;
- R1 `CLAIM_LEDGER.md`, `PROTOCOL_R1_LIMITS.md`, `SEED_STATUS.json`, the existing
  test entrypoint and receipt tests;
- `review/tools/review_successor.py` and the existing interpreter under
  `reference_interpreter/scripts/review_sat02.py` where needed for saved receipts.

Do not treat the latest overlay as proof that the patch was already applied.
Expected checker SHA-256 BEFORE integration:

`ececdfdfa4c074b094810c1b58cfe081086cfd638f7e04f34cfc5997184d0c8d`

Expected candidate checker SHA-256 if the supplied candidate is adopted unchanged:

`137d2748bffc085af709707275333a54166aa85229365fb2745f6f6bc0b3ea3f`

A different live hash requires reconciliation, not forcing the replacement. An
already-equivalent fix can be verified and recorded rather than applied twice.

## 3. Reproduce the exact outstanding boundaries in a fresh baseline copy

Run the existing R1 suite from a disposable copy; the prior expected count is 73.
Then run the supplied six regressions against that same unpatched implementation,
keeping their output separate. The earlier reviewer saw three of six fail; check
actual failing identities and reasons rather than merely matching a failure count.
They cover closed-form boundary overwrite, table boundary overwrite, and a valid
empty relation that should need no witness, with positive and hostile controls.

If using test discovery, initially preserve the old 73-test tree. Add the six-test
file only in the disposable test copy or successor. Keep original test files
unchanged; do not modify the checks to obtain a pass. Log command, environment,
source hash, stdout/stderr, exit code, discovered test IDs, and real outcomes.
Use normal Python with assertions enabled and avoid accidental imports from the
live repository. A subprocess may use a process-local path pointing to its own
fresh package; do not change global environment settings.

Inspect two proof obligations directly:

1. For every satisfying retained assignment b, the recovered assignment must
   satisfy the original **local relation** and restrict to the same b. A recovery
   returning a different satisfying boundary is invalid. Restricting output keys
   to the eliminated variables must protect both recovery representations.
2. When the independently evaluated input relation is empty, its existential
   projection is empty. There is no satisfying b needing a witness. The checker
   must still verify the input mask and FALSE replacement and reject a false
   zero-mask claim or a TRUE replacement for an empty input.

Keep `whole_solver_derivation_replayed=False` and `binds_original_factor_ids=False`
where those are the existing scope. Do not upgrade a local check into a certified
whole-solver UNSAT chain.

## 4. Integrate the smallest justified correction

Inspect the supplied one-file candidate. If correct for these obligations, use it
in a fresh maintenance successor. `apply_to_fresh_copy.py` copies R1, checks the
before/after hashes, and replaces only `sat_group_compiler/receipts.py`; it does not
run panels or create an official export. Inspect it before invoking it.

The helper deliberately labels its generated record as a REVIEW_CANDIDATE and
leaves the historical `HASHES.json` unchanged. Preserve that as an intermediate
record. Add a separate M1 integration record and final manifest once you have
actually integrated and verified the successor. Do not treat the old owner's
hash record as an integrity manifest for changed code, or rewrite it to backdate
history. Preserve the original latest overlay as historical input; write an M1
status instead of altering its statement that the patch was not then integrated.

Only the local checker, its six focused tests, maintenance status/README/claim
clarifications, packaging metadata, and necessary test entrypoint may change.
Compilation, grouping, workload protocol, structural score, seed declarations,
budgets, and original panel JSON stay untouched. Preserve the successful group,
timer, and fingerprint repairs. Use an existing minimal test entrypoint; do not
build another general runner framework.

If independent inspection finds a concrete relevant flaw in the proposed patch,
show a minimal reproducer and make the smallest necessary correction in M1.
Record a different candidate identity and why. Nonblocking ideas and broader
parser hardening remain limitations, not reasons to start a rewrite or another
research campaign.

## 5. Verify the integrated result with bounded, existing evidence

Required acceptance evidence:

- Original R1 tests still pass: 73 existing cases, unchanged. The six supplied
  review regressions pass as well. Report 73 + 6, or 79 with that decomposition,
  not 79 independent experiments.
- Both recovery forms preserve retained boundary values. Correct recovery remains
  accepted; wrong, missing, incomplete, overlapping-scope and boundary-overwriting
  recovery for a nonempty relation remain rejected at the appropriate boundary.
- Empty input with correct FALSE projection and no recovery is accepted. An
  asserted zero mask on nonempty input and TRUE-for-empty replacement are rejected.
- Replay the **982 existing local receipts** against the integrated checker and
  the supplied review interpretation, including its output-scope guard. The prior
  R1 count was 932 accepted / 50 falsely rejected; the prior candidate accepted
  all 982. Reconcile actual new outcomes, don't copy counts from prior JSON.
  This is replay of already-saved evidence, not panel generation, new seeds,
  a newly independent method, or a whole original-instance proof.
- Retain the accepted local XOR/W3-T and native three-color examples. The existing
  bounded `review_successor.py` can recheck those, the finite group oracle, and
  saved receipts together. It does not regenerate benchmark panels. Its exit
  code is not sufficient by itself: inspect `saved_receipts_recheck.json` for
  982 records, zero rejections, and zero independent errors after integration,
  and the control rows for the expected accepts/rejects. The same script is
  designed to record the old R1 defects without necessarily failing its aggregate.
- Verify only the permitted source changes. Keep the three original protocol
  files and seed-status record byte-identical, and retain the original archives.

Use `COMMANDS.md` for the inspected command shapes and helper dependencies.
Record optional-backend availability honestly. The bounded standard-library
checks do not require recreating the original Windows/PySAT/NariZoo performance
environment. No package installation, `freeze`, `panels`, `smoke`, `stress`, seed
backfill, or performance campaign is requested. Existing unit tests may use small
exposed fixtures; distinguish those from the forbidden panel-generation commands.

## 6. Deliver an actual maintenance successor, then stop

Produce **one unambiguous active build** such as `SAT02-portable-codex-m1.zip`,
with implementation, current tests, input/protocol identities, portable test
entrypoint, the unchanged original R1/source records or clear historical copies,
and an accurate maintenance README and claim ledger. Include saved data and the
needed review interpreter for claimed receipt reproducibility, either within the
build or in its explicitly paired evidence archive. Avoid an active export inside
itself or unrelated project payloads.

Preserve original `HASHES.json`, protocols, owner return, and overlay as historical
records. The successor's current docs must distinguish:

- accepted partial research: unchanged;
- owner-submitted R1: frozen with its documented checker limitations;
- reviewed candidate: historical prior evidence;
- M1 integrated checker and its fresh verification: the new maintenance result.

Extract the **final ZIP** into a fresh directory away from the original workspace
and frozen handoff. Test using only delivered dependencies. Repeat the 73+6 suite
and saved-receipt checks in that delivered environment, check the file manifest,
and retain the final commands, environment, child result records, exit codes,
stdout/stderr, before/after diff and actual source hashes. Do not report a
pre-export working-tree test as the final-ZIP replay.

Keep final replay receipts external to the already-hashed build. Return them as
`SAT02-codex-m1-final-evidence.zip` or an equally unambiguous companion. Return a
SHA-256 text file for each final archive. Do not alter a build after publishing
its hash or create a circular self-hash.

The readable return, `CODEX_M1_REVIEW_AND_CLOSEOUT.md`, should say whether the
candidate was accepted unchanged or modified with a reproducer, what is genuinely
integrated, which commands actually ran, and what remains outside the claim. A
suitable disposition is `INTEGRATED_AND_VERIFIED_WITHIN_LOCAL_SCOPE` if earned;
otherwise report the exact blocker and retained partial completion honestly.
Attach the actual files through the available artifact mechanism; a Windows path
alone is not a portable delivery. No external repository write is authorized.

## 7. Claim ceiling and other lanes

Keep **6 RUN / 4 NOT_RUN**. Preserve W3-T 15→18 then 23→6 as a local structural
route, not time or a universal SAT shortcut. Preserve the correct 147/243 two-factor
conjunction and the rejection of the 93/243 single-union substitution. Do not claim
a complete work budget, clean speed ranking, ten-seed completion, whole-solver
proof, new tractable SAT family, or P versus NP result.

C1, Lind–Reichardt, and AD's 14/16-versus-14/16 pilot stay closed. Fluid and
Yang–Mills remain undispatched. No Task03 and no automatic next experiment.

**Finish this authorized maintenance integration, return the build and evidence,
then stop. The research result is not reopened by doing the repair.**
