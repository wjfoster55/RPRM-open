Original SAT02 completed return is frozen at:

`C:\github\rprm-pnp\experiments\sat_group_compiler_02\`

Do not copy or rewrite `results/` into this successor. Independent review calculations remain in `../sat02_review_01_package/SAT02-REVIEW-01/results/`.
