"""Intermediate representation: grammar factors, promises, serialization."""

from __future__ import annotations

from dataclasses import dataclass, replace
from enum import Enum
import hashlib
import json


class Kind(str, Enum):
    TRUE = "TRUE"
    FALSE = "FALSE"
    UNIT = "UNIT"
    CLAUSE = "CLAUSE"
    SAME = "SAME"
    DIFFERENT = "DIFFERENT"
    PARITY = "PARITY"
    AMO = "AMO"
    XO = "XO"
    TABLE = "TABLE"


class Promise(str, Enum):
    A = "A"
    B = "B"
    C = "C"


@dataclass(frozen=True)
class Factor:
    id: int
    kind: Kind
    lits: tuple[int, ...] = ()
    parity: bool = False
    promise: Promise = Promise.B
    table_mask: int = 0

    def vars(self) -> tuple[int, ...]:
        if self.kind in (Kind.TRUE, Kind.FALSE):
            return ()
        if self.kind in (Kind.SAME, Kind.DIFFERENT, Kind.PARITY, Kind.TABLE):
            return tuple(sorted(self.lits))
        return tuple(sorted({abs(lit) for lit in self.lits}))

    def structural_cost(self) -> int:
        k = len(self.lits)
        if self.kind is Kind.TRUE:
            return 0
        if self.kind is Kind.FALSE:
            return 0
        if self.kind is Kind.UNIT:
            return 2
        if self.kind is Kind.SAME:
            return 3
        if self.kind is Kind.DIFFERENT:
            return 3
        if self.kind is Kind.CLAUSE:
            return 2 + k
        if self.kind is Kind.PARITY:
            return 3 + k
        if self.kind is Kind.AMO:
            return 2 + k
        if self.kind is Kind.XO:
            return 3 + k
        if self.kind is Kind.TABLE:
            # Temporary object only. One ID is not compression.
            return 10 + (1 << k)
        raise AssertionError(self.kind)

    def canon_string(self) -> str:
        if self.kind is Kind.TRUE:
            return "T"
        if self.kind is Kind.FALSE:
            return "F"
        if self.kind is Kind.PARITY:
            bits = ",".join(str(v) for v in self.lits)
            return f"P:{bits}={int(self.parity)}"
        if self.kind is Kind.TABLE:
            bits = ",".join(str(v) for v in self.lits)
            return f"TBL:{bits}:{self.table_mask:x}"
        payload = ",".join(str(v) for v in self.lits)
        return f"{self.kind.value[0]}:{payload}"


def _lit_val(lit: int, assignment: dict[int, int]) -> int:
    bit = assignment[abs(lit)]
    if bit not in (0, 1):
        raise ValueError("non-binary assignment rejected")
    return bit if lit > 0 else 1 - bit


def factor_holds(factor: Factor, assignment: dict[int, int]) -> bool:
    if factor.kind is Kind.TRUE:
        return True
    if factor.kind is Kind.FALSE:
        return False
    if factor.kind is Kind.UNIT:
        return _lit_val(factor.lits[0], assignment) == 1
    if factor.kind is Kind.CLAUSE:
        return any(_lit_val(lit, assignment) == 1 for lit in factor.lits)
    if factor.kind is Kind.SAME:
        a, b = factor.lits
        return assignment[a] == assignment[b]
    if factor.kind is Kind.DIFFERENT:
        a, b = factor.lits
        return assignment[a] != assignment[b]
    if factor.kind is Kind.PARITY:
        acc = 0
        for var in factor.lits:
            acc ^= assignment[var]
        return bool(acc) is factor.parity
    if factor.kind is Kind.AMO:
        return sum(_lit_val(lit, assignment) for lit in factor.lits) <= 1
    if factor.kind is Kind.XO:
        return sum(_lit_val(lit, assignment) for lit in factor.lits) == 1
    if factor.kind is Kind.TABLE:
        mask = 0
        for i, var in enumerate(factor.lits):
            bit = assignment[var]
            if bit not in (0, 1):
                raise ValueError("non-binary assignment rejected")
            if bit:
                mask |= 1 << i
        return bool((factor.table_mask >> mask) & 1)
    raise AssertionError(factor.kind)


def normalize_signed_pair(lit_a: int, lit_b: int) -> Factor:
    a, b = abs(lit_a), abs(lit_b)
    sign_diff = (lit_a < 0) ^ (lit_b < 0)
    if a > b:
        a, b = b, a
    kind = Kind.DIFFERENT if sign_diff else Kind.SAME
    return Factor(id=-1, kind=kind, lits=(a, b))


def canon_factor_payload(factor: Factor) -> Factor:
    if factor.kind in (Kind.TRUE, Kind.FALSE):
        return replace(factor, lits=(), parity=False, table_mask=0)
    if factor.kind in (Kind.SAME, Kind.DIFFERENT):
        a, b = sorted(factor.lits)
        return replace(factor, lits=(a, b), parity=False, table_mask=0)
    if factor.kind is Kind.PARITY:
        return replace(factor, lits=tuple(sorted(factor.lits)), table_mask=0)
    if factor.kind is Kind.TABLE:
        return replace(factor, lits=tuple(factor.lits), parity=False)
    if factor.kind in (Kind.UNIT, Kind.CLAUSE, Kind.AMO, Kind.XO):
        lits = tuple(sorted(factor.lits, key=lambda lit: (abs(lit), lit < 0)))
        return replace(factor, lits=lits, parity=False, table_mask=0)
    return factor


def parse_canon(text: str, fid: int = -1) -> Factor:
    if text == "T":
        return Factor(id=fid, kind=Kind.TRUE)
    if text == "F":
        return Factor(id=fid, kind=Kind.FALSE)
    if text.startswith("P:"):
        body, par = text[2:].split("=", 1)
        lits = tuple(int(part) for part in body.split(",") if part)
        return Factor(id=fid, kind=Kind.PARITY, lits=lits, parity=bool(int(par)))
    if text.startswith("TBL:"):
        _, rest = text.split(":", 1)
        vars_part, mask_part = rest.rsplit(":", 1)
        lits = tuple(int(part) for part in vars_part.split(",") if part)
        return Factor(id=fid, kind=Kind.TABLE, lits=lits, table_mask=int(mask_part, 16))
    kind_ch, payload = text.split(":", 1)
    lits = tuple(int(part) for part in payload.split(",") if part)
    mapping = {
        "U": Kind.UNIT,
        "C": Kind.CLAUSE,
        "S": Kind.SAME,
        "D": Kind.DIFFERENT,
        "A": Kind.AMO,
        "X": Kind.XO,
    }
    if kind_ch not in mapping:
        raise ValueError(f"unknown canon {text!r}")
    return Factor(id=fid, kind=mapping[kind_ch], lits=lits)


def cnf_holds(clauses: tuple[tuple[int, ...], ...], assignment: dict[int, int]) -> bool:
    for clause in clauses:
        if not clause:
            return False
        if not any(_lit_val(lit, assignment) == 1 for lit in clause):
            return False
    return True


def ir_canon_key(factors: list[Factor]) -> str:
    parts = sorted(canon_factor_payload(f).canon_string() for f in factors if f.kind is not Kind.TRUE)
    return "|".join(parts)


def ir_hash(factors: list[Factor]) -> str:
    return hashlib.sha256(ir_canon_key(factors).encode("utf-8")).hexdigest()


def ir_bytes(factors: list[Factor]) -> bytes:
    return ir_canon_key(factors).encode("utf-8")


def total_cost(factors: list[Factor]) -> int:
    return sum(f.structural_cost() for f in factors if f.kind is not Kind.TRUE)


def live_vars(factors: list[Factor]) -> set[int]:
    out: set[int] = set()
    for factor in factors:
        out.update(factor.vars())
    return out


def canonical_json_bytes(obj: object) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode("utf-8")
