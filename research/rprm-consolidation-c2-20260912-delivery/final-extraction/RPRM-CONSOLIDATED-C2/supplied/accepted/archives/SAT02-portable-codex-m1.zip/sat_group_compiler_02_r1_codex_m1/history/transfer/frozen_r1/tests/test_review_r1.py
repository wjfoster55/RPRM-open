"""SAT02-R1 review closeout regressions. Not a panel rerun and not seed backfill."""

from __future__ import annotations

import itertools
import tempfile
import time
import unittest
from pathlib import Path

from sat_group_compiler.cli import panel_instances, seed_coverage
from sat_group_compiler.compiler import compile_cnf
from sat_group_compiler.fingerprints import source_file_hashes, source_sha256, write_json
from sat_group_compiler.grouping import (
    GroupBudget,
    connected_subsets_oracle,
    iter_connected_groups,
)
from sat_group_compiler.ir import Factor, Kind
from sat_group_compiler.native3 import overlapping_conjunction_versus_union_atom
from sat_group_compiler.protocol import load_protocol, stage_limits
from sat_group_compiler.receipts import check_rewrite_receipt, receipt_payload


XOR = "p cnf 3 4\n1 2 3 0\n1 -2 -3 0\n-1 2 -3 0\n-1 -2 3 0\n"
DIFF = "p cnf 2 2\n1 2 0\n-1 -2 0\n"


def limits(variant="W3", **overrides):
    lim = dict(stage_limits(load_protocol(), "smoke", variant))
    lim.update(overrides)
    return lim


def unlimited() -> GroupBudget:
    return GroupBudget(check=lambda: True, meter={})


def path_factors(scope_order: list[tuple[int, int]]) -> list[Factor]:
    return [Factor(id=i, kind=Kind.CLAUSE, lits=scope) for i, scope in enumerate(scope_order, start=1)]


class SeedCoverageTests(unittest.TestCase):
    def test_declared_ten_effective_six_four_not_run(self):
        cov = seed_coverage()
        self.assertEqual(cov["declared_count"], 10)
        self.assertEqual(cov["run_count"], 6)
        self.assertEqual(cov["not_run_count"], 4)
        self.assertEqual(cov["execution"], "partial")
        self.assertFalse(cov["backfill_into_original_result"])
        names = {(row["split"], row["seed"], row["status"]) for row in cov["not_run"]}
        self.assertEqual(
            names,
            {
                ("development", 37, "NOT_RUN"),
                ("development", 41, "NOT_RUN"),
                ("evaluation", 20063, "NOT_RUN"),
                ("evaluation", 20089, "NOT_RUN"),
            },
        )

    def test_panel_builder_still_ignores_fourth_and_fifth_seeds(self):
        seeds = [23, 29, 31, 37, 41]
        inst = panel_instances("development", seeds)
        ids = " ".join(i.instance_id for i in inst)
        self.assertIn("seed=23", ids)
        self.assertIn("seed=29", ids)
        self.assertIn("seed=31", ids)
        self.assertNotIn("seed=37", ids)
        self.assertNotIn("seed=41", ids)


class GroupingRepairTests(unittest.TestCase):
    def test_path_1_3_2_emits_complete_triple_in_all_id_orders(self):
        scopes = [(1, 2), (3, 4), (2, 3)]
        found = 0
        missed = 0
        for order in itertools.permutations(scopes):
            factors = path_factors(list(order))
            gb = unlimited()
            groups = list(iter_connected_groups(factors, 3, 6, gb, min_factors=2))
            triples = [g for g in groups if len(g) == 3]
            if triples:
                found += 1
            else:
                missed += 1
            oracle = connected_subsets_oracle(factors, 3, 6, min_factors=2)
            emitted_ids = {frozenset(f.id for f in g) for g in groups}
            self.assertEqual(emitted_ids, oracle)
            self.assertIn(frozenset(f.id for f in factors), oracle)
        self.assertEqual(found, 6)
        self.assertEqual(missed, 0)

    def test_exhausted_budget_does_not_build_adjacency(self):
        factors = [Factor(id=i + 1, kind=Kind.CLAUSE, lits=(1, i + 2)) for i in range(80)]
        dead = GroupBudget(check=lambda: False, meter={})
        groups = list(iter_connected_groups(factors, 3, 80, dead, min_factors=2))
        self.assertEqual(groups, [])
        self.assertEqual(dead.meter.get("adjacency_pairs", 0), 0)


class ReceiptCheckerTests(unittest.TestCase):
    def _diff_payload(self, **overrides) -> dict:
        payload = {
            "boundary": [1],
            "eliminated": [2],
            "group_sat_mask": 6,
            "input_factor_ids": [3, 4],
            "input_identities": ["C:1,2", "C:-1,-2"],
            "new_cost": 0,
            "orig_cost": 8,
            "promise": "C",
            "recovery": {"map": {"2": ["lit", -1]}, "type": "closed_form"},
            "replacement": ["T"],
            "scope": [1, 2],
            "speculative": False,
        }
        payload.update(overrides)
        return payload

    def test_correct_closed_form_accepted(self):
        checked = check_rewrite_receipt(self._diff_payload())
        self.assertTrue(checked["ok"], msg=checked)
        self.assertEqual(checked["grade"], "local_relation_checked")
        self.assertFalse(checked["binds_original_factor_ids"])
        self.assertFalse(checked["whole_solver_derivation_replayed"])

    def test_wrong_closed_form_rejected(self):
        payload = self._diff_payload(recovery={"map": {"2": ["lit", 1]}, "type": "closed_form"})
        checked = check_rewrite_receipt(payload)
        self.assertFalse(checked["ok"])
        self.assertIn("recovery_wrong", checked["reasons"])

    def test_missing_recovery_rejected(self):
        checked = check_rewrite_receipt(self._diff_payload(recovery={}))
        self.assertFalse(checked["ok"])
        self.assertIn("recovery_missing", checked["reasons"])

    def test_empty_and_incomplete_lex_table_rejected(self):
        empty = self._diff_payload(recovery={"rows": [], "type": "lex_table"})
        self.assertIn("recovery_row_coverage", check_rewrite_receipt(empty)["reasons"])
        incomplete = self._diff_payload(
            recovery={
                "type": "lex_table",
                "rows": [{"boundary": {"1": 0}, "internal": {"2": 1}}],
            }
        )
        self.assertIn("recovery_row_coverage", check_rewrite_receipt(incomplete)["reasons"])

    def test_overlapping_partition_rejected(self):
        payload = self._diff_payload(eliminated=[1, 2])
        checked = check_rewrite_receipt(payload)
        self.assertFalse(checked["ok"])
        self.assertIn("scope_partition", checked["reasons"])

    def test_bogus_ids_still_locally_ok_but_unbound(self):
        payload = self._diff_payload(input_factor_ids=[999, 1000])
        checked = check_rewrite_receipt(payload)
        self.assertTrue(checked["ok"], msg=checked)
        self.assertFalse(checked["binds_original_factor_ids"])

    def test_failed_receipt_does_not_keep_derivation_grade(self):
        import sat_group_compiler.receipts as recmod

        orig = recmod.check_rewrite_receipt

        def boom(payload):
            return {
                "ok": False,
                "grade": "rejected",
                "reasons": ["TEST_INJECTION"],
                "did_not_invoke_compiler": True,
                "did_not_trust_validation_string": True,
            }

        recmod.check_rewrite_receipt = boom
        try:
            r = compile_cnf(XOR, mode="C", limits=limits("W4"), variant="W4", retain=[1, 2, 3], use_affine=False)
        finally:
            recmod.check_rewrite_receipt = orig
        self.assertEqual(r.status, "UNRESOLVED")
        self.assertEqual(r.claim_grade, "receipt_rejected")
        self.assertFalse(all(c.get("ok", True) for c in r.receipt_checks))

    def test_wall_time_includes_receipt_checks(self):
        import sat_group_compiler.receipts as recmod

        orig = recmod.check_rewrite_receipt

        def delayed(payload):
            time.sleep(0.02)
            return orig(payload)

        recmod.check_rewrite_receipt = delayed
        try:
            start = time.perf_counter()
            r = compile_cnf(XOR, mode="C", limits=limits("W4"), variant="W4", retain=[1, 2, 3], use_affine=False)
            elapsed = time.perf_counter() - start
        finally:
            recmod.check_rewrite_receipt = orig
        self.assertGreaterEqual(r.meter.receipt_check_s, 0.015)
        self.assertGreaterEqual(r.meter.wall_s, 0.015)
        self.assertGreaterEqual(elapsed, 0.015)


class SpecimenPreservationTests(unittest.TestCase):
    def test_w3t_temporary_table_cost_then_parity(self):
        r = compile_cnf(XOR, mode="C", limits=limits("W3-T"), variant="W3-T", retain=[1, 2, 3], use_affine=False)
        self.assertGreaterEqual(len(r.receipts), 2)
        first, second = r.receipts[0], r.receipts[1]
        self.assertEqual(first.orig_cost, 15)
        self.assertEqual(first.new_cost, 18)
        self.assertEqual(first.replacement, ["TBL:1,2,3:97"])
        self.assertTrue(first.speculative)
        self.assertEqual(second.orig_cost, 23)
        self.assertEqual(second.new_cost, 6)
        self.assertTrue(any(s.startswith("P:1,2,3=1") for s in r.residual + r.recognized))
        w3 = compile_cnf(XOR, mode="C", limits=limits("W3"), variant="W3", retain=[1, 2, 3], use_affine=False)
        self.assertFalse(any(s.startswith("P:") for s in w3.residual + w3.recognized))

    def test_three_color_conjunction_is_not_the_union_atom(self):
        versus = overlapping_conjunction_versus_union_atom()
        self.assertEqual(versus["boundary_assignments"], 243)
        self.assertEqual(versus["two_factor_conjunction_accepted"], 147)
        self.assertEqual(versus["single_union_atom_accepted"], 93)
        self.assertEqual(versus["separating_example"], [0, 0, 1, 1, 2])


class BudgetAndFingerprintBoundsTests(unittest.TestCase):
    def test_table_row_cap_does_not_charge_template_rows(self):
        r = compile_cnf(
            XOR,
            mode="C",
            limits=limits("W3-T", max_table_rows=8),
            variant="W3-T",
            retain=[1, 2, 3],
            use_affine=False,
        )
        self.assertGreater(r.meter.template_construction_rows, r.meter.table_rows)
        self.assertTrue(r.meter.effective_config["template_and_projection_not_in_table_row_cap"])
        self.assertEqual(r.meter.effective_config["table_row_cap_charges"], "meter.table_rows_only")
        self.assertTrue(r.meter.effective_config["temporary_table_follows_selected_top_path"])

    def test_source_digest_stable_after_writing_versions(self):
        root = Path(__file__).resolve().parents[1]
        before = source_sha256(root)
        self.assertNotIn("versions.json", source_file_hashes(root))
        with tempfile.TemporaryDirectory() as tmp:
            copy = Path(tmp)
            (copy / "probe.py").write_text("x = 1\n", encoding="utf-8")
            first = source_sha256(copy)
            write_json(copy / "versions.json", {"source_sha256": first})
            second = source_sha256(copy)
            self.assertEqual(first, second)
        self.assertNotIn("versions.json", source_file_hashes(copy))
        self.assertEqual(before, source_sha256(root))


if __name__ == "__main__":
    unittest.main()
