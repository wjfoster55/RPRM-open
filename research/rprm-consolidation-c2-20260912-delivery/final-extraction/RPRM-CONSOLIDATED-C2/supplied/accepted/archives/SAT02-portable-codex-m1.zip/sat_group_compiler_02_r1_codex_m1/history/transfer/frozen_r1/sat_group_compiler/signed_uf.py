"""Signed union-find for SAME/DIFFERENT plus units."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class SignedUF:
    parent: dict[int, int] = field(default_factory=dict)
    parity: dict[int, int] = field(default_factory=dict)
    root_value: dict[int, int] = field(default_factory=dict)

    def _ensure(self, var: int) -> None:
        if var not in self.parent:
            self.parent[var] = var
            self.parity[var] = 0

    def find(self, var: int) -> tuple[int, int]:
        self._ensure(var)
        if self.parent[var] == var:
            return var, 0
        root, par = self.find(self.parent[var])
        self.parity[var] ^= par
        self.parent[var] = root
        return root, self.parity[var]

    def union(self, a: int, b: int, different: bool) -> bool:
        ra, pa = self.find(a)
        rb, pb = self.find(b)
        rel = int(different) ^ pa ^ pb
        if ra == rb:
            return rel == 0
        self.parent[rb] = ra
        self.parity[rb] = rel
        if rb in self.root_value:
            mapped = self.root_value[rb] ^ rel
            if ra in self.root_value and self.root_value[ra] != mapped:
                return False
            if ra not in self.root_value:
                self.root_value[ra] = mapped
            del self.root_value[rb]
        return True

    def assign(self, var: int, value: int) -> bool:
        if value not in (0, 1):
            raise ValueError("non-binary unit")
        root, par = self.find(var)
        needed = value ^ par
        if root in self.root_value:
            return self.root_value[root] == needed
        self.root_value[root] = needed
        return True

    def value_of(self, var: int) -> int | None:
        self._ensure(var)
        root, par = self.find(var)
        if root not in self.root_value:
            return None
        return self.root_value[root] ^ par

    def relation(self, a: int, b: int) -> int | None:
        ra, pa = self.find(a)
        rb, pb = self.find(b)
        if ra != rb:
            return None
        return pa ^ pb

    def assignment_map(self, variables: list[int], default_free: int = 0) -> dict[int, int]:
        out: dict[int, int] = {}
        for var in variables:
            root, par = self.find(var)
            if root not in self.root_value:
                self.root_value[root] = default_free
            out[var] = self.root_value[root] ^ par
        return out
