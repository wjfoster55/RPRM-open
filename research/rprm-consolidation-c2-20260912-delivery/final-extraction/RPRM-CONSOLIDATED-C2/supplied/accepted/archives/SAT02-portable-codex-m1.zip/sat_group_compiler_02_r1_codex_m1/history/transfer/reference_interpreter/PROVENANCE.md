# Existing reviewer interpreter

`scripts/review_sat02.py` is byte-identical to
`../review/tools/prior_review_sat02.py`, itself the earlier SAT02 review interpreter.
It is relocated solely to match `review_successor.py`'s `--prior-review` interface.
No code was changed and no new independent implementation is claimed.

`review_successor.py` adds an explicit check that recovery outputs name only the
eliminated variables. This augmentation and the interpretation's limits are
documented in the original closeout review. Use it for the bounded saved-receipt
recheck, not as a whole-solver proof.
