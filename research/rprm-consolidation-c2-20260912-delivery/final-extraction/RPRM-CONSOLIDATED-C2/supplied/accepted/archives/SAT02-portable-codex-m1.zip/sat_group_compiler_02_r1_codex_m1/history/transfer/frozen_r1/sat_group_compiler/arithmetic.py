"""Factored exact integer penalty expressions on the binary domain."""

from __future__ import annotations

from dataclasses import dataclass
from itertools import product


@dataclass(frozen=True)
class LitFail:
    """Failure of one signed literal: x if the literal is negative, else 1-x."""

    var: int
    negated_literal: bool

    def evaluate(self, assignment: dict[int, int]) -> int:
        value = assignment[self.var]
        if value not in (0, 1):
            raise ValueError("non-binary assignment rejected")
        return value if self.negated_literal else 1 - value


@dataclass(frozen=True)
class Product:
    terms: tuple[LitFail, ...]
    coeff: int = 1

    def evaluate(self, assignment: dict[int, int]) -> int:
        acc = self.coeff
        for term in self.terms:
            acc *= term.evaluate(assignment)
        return acc

    def max_coeff_bits(self) -> int:
        return abs(self.coeff).bit_length()


@dataclass(frozen=True)
class Penalty:
    """Sum of factored clause-failure products. Empty formula is 0."""

    summands: tuple[Product, ...]

    def evaluate(self, assignment: dict[int, int]) -> int:
        return sum(item.evaluate(assignment) for item in self.summands)

    def constant_offset(self) -> int:
        """Failure of the all-unconstrained empty-product parts (empty clauses)."""
        return sum(item.coeff for item in self.summands if not item.terms)

    def max_coeff_bits(self) -> int:
        return max((item.max_coeff_bits() for item in self.summands), default=0)

    def zero_on_binary(self, n_vars: int, used: set[int] | None = None) -> bool:
        keys = sorted(used if used is not None else range(1, n_vars + 1))
        for bits in product((0, 1), repeat=len(keys)):
            assignment = {var: 0 for var in range(1, n_vars + 1)}
            assignment.update(zip(keys, bits, strict=True))
            if self.evaluate(assignment) == 0:
                return True
        return False


def lit_fail(literal: int) -> LitFail:
    if literal == 0:
        raise ValueError("literal 0 is invalid")
    return LitFail(var=abs(literal), negated_literal=literal < 0)


def clause_failure(literals: tuple[int, ...], coeff: int = 1) -> Product:
    return Product(terms=tuple(lit_fail(lit) for lit in literals), coeff=coeff)


def penalty_from_clauses(clauses: tuple[tuple[int, ...], ...]) -> Penalty:
    return Penalty(tuple(clause_failure(clause) for clause in clauses))


def different_pair_sum(a: int, b: int) -> int:
    return (1 - a) * (1 - b) + a * b


def different_square(a: int, b: int) -> int:
    return (a + b - 1) ** 2


def same_pair_sum(a: int, b: int) -> int:
    return a * (1 - b) + (1 - a) * b


def same_square(a: int, b: int) -> int:
    return (a - b) ** 2


def verify_binary_identities() -> dict[str, bool]:
    different_ok = True
    same_ok = True
    poly_diff_equal_over_z = True
    for a, b in product((0, 1), repeat=2):
        if different_pair_sum(a, b) != different_square(a, b):
            different_ok = False
        if same_pair_sum(a, b) != same_square(a, b):
            same_ok = False
    # Over Z they differ off {0,1}; check one off-domain point without accepting it as SAT.
    if different_pair_sum(2, 0) == different_square(2, 0):
        poly_diff_equal_over_z = True
    else:
        poly_diff_equal_over_z = False
    return {
        "different_binary": different_ok,
        "same_binary": same_ok,
        "different_polynomials_equal_over_Z": poly_diff_equal_over_z,
    }


def reject_fractional(assignment: dict[int, object]) -> None:
    for var, value in assignment.items():
        if isinstance(value, bool) or value not in (0, 1):
            raise ValueError(f"non-binary value for variable {var}: {value!r}")
