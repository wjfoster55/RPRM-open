"""Import labeled existing backends; independent oracles; enforced timeouts."""

from __future__ import annotations

import multiprocessing as mp
import sys
import time
from dataclasses import dataclass
from itertools import combinations
from pathlib import Path
from typing import Any

from .affine_gf2 import gf2_solve
from .ir import Kind

MILLENNIUM_ROOT = Path(r"C:\github\NariZoo\millennium_rprm")
NARIZOO_ROOT = Path(r"C:\github\NariZoo")


def classify_cnf(clauses: tuple[tuple[int, ...], ...]) -> dict[str, Any]:
    """Syntactic eligibility computed from input. Not a family hint."""
    max_width = 0
    horn = True
    two_cnf = True
    for clause in clauses:
        seen: set[int] = set()
        cleaned: list[int] = []
        taut = False
        for lit in clause:
            if lit in seen:
                continue
            if -lit in seen:
                taut = True
                break
            seen.add(lit)
            cleaned.append(lit)
        if taut:
            continue
        width = len(cleaned)
        max_width = max(max_width, width)
        if width > 2:
            two_cnf = False
        positives = sum(1 for lit in cleaned if lit > 0)
        if positives > 1:
            horn = False
    return {
        "max_width": max_width,
        "is_2cnf": two_cnf,
        "is_horn": horn,
        "computed": True,
        "not_a_family_label": True,
    }


def probe_external() -> dict[str, Any]:
    info: dict[str, Any] = {
        "closure_sat": False,
        "affine": False,
        "two_sat": False,
        "horn": False,
        "robdd": False,
        "pysat": False,
        "pysat_solver": None,
        "stdlib_gf2": True,
        "errors": {},
        "paths": {
            "millennium_root": str(MILLENNIUM_ROOT),
            "narizoo_root": str(NARIZOO_ROOT),
        },
    }
    for path in (str(NARIZOO_ROOT), str(MILLENNIUM_ROOT)):
        if path not in sys.path:
            sys.path.insert(0, path)
    try:
        import closure_sat  # type: ignore

        info["closure_sat"] = True
        info["closure_sat_module"] = closure_sat
    except Exception as exc:
        info["errors"]["closure_sat"] = repr(exc)
    try:
        from millennium_rprm.semantic_compiler.affine import AffineBackend, XorEquation  # type: ignore

        info["affine"] = True
        info["AffineBackend"] = AffineBackend
        info["XorEquation"] = XorEquation
    except Exception as exc:
        try:
            from semantic_compiler.affine import AffineBackend, XorEquation  # type: ignore

            info["affine"] = True
            info["AffineBackend"] = AffineBackend
            info["XorEquation"] = XorEquation
        except Exception as exc2:
            info["errors"]["affine"] = repr(exc) + " | " + repr(exc2)
    try:
        from millennium_rprm.semantic_compiler.two_sat import TwoSatBackend  # type: ignore

        info["two_sat"] = True
        info["TwoSatBackend"] = TwoSatBackend
    except Exception as exc:
        info["errors"]["two_sat"] = repr(exc)
    try:
        from millennium_rprm.semantic_compiler.horn import HornBackend  # type: ignore

        info["horn"] = True
        info["HornBackend"] = HornBackend
    except Exception as exc:
        info["errors"]["horn"] = repr(exc)
    try:
        from millennium_rprm.semantic_compiler.robdd import ROBDDBackend  # type: ignore

        info["robdd"] = True
        info["ROBDDBackend"] = ROBDDBackend
    except Exception as exc:
        info["errors"]["robdd"] = repr(exc)
    try:
        from pysat.solvers import Glucose3

        info["pysat"] = True
        info["pysat_solver"] = "Glucose3"
        info["Glucose3"] = Glucose3
    except Exception as exc:
        info["errors"]["pysat"] = repr(exc)
    return info


_PROBE: dict[str, Any] | None = None


def get_probe() -> dict[str, Any]:
    global _PROBE
    if _PROBE is None:
        _PROBE = probe_external()
    return _PROBE


def reset_probe() -> None:
    global _PROBE
    _PROBE = None


@dataclass
class OracleResult:
    status: str
    assignment: dict[int, int] | None
    method: str
    seconds: float
    proof_checked: bool
    skipped_reason: str | None = None
    extra: dict[str, Any] | None = None


def exhaustive_sat(
    n_vars: int,
    clauses: tuple[tuple[int, ...], ...],
    max_n: int,
) -> OracleResult:
    start = time.perf_counter()
    if n_vars > max_n:
        return OracleResult("SKIPPED", None, "exhaustive", 0.0, False, "n>exhaustive_max_n")
    if n_vars == 0:
        unsat = any(len(cl) == 0 for cl in clauses)
        return OracleResult(
            "UNSAT" if unsat else "SAT",
            {} if not unsat else None,
            "exhaustive",
            time.perf_counter() - start,
            True,
        )
    from .ir import cnf_holds

    for mask in range(1 << n_vars):
        assignment = {var: (mask >> (var - 1)) & 1 for var in range(1, n_vars + 1)}
        if cnf_holds(clauses, assignment):
            return OracleResult("SAT", assignment, "exhaustive", time.perf_counter() - start, True)
    return OracleResult("UNSAT", None, "exhaustive", time.perf_counter() - start, True)


def _pysat_worker(n_vars: int, clauses: tuple[tuple[int, ...], ...], conn) -> None:
    try:
        from pysat.solvers import Glucose3

        solver = Glucose3(use_timer=True)
        try:
            for clause in clauses:
                if not clause:
                    conn.send(("UNSAT", None, False))
                    return
                solver.add_clause(list(clause))
            sat = solver.solve()
            if sat:
                model = solver.get_model()
                assignment = {var: 0 for var in range(1, n_vars + 1)}
                if model:
                    for lit in model:
                        if lit == 0:
                            continue
                        assignment[abs(lit)] = 1 if lit > 0 else 0
                conn.send(("SAT", assignment, False))
            else:
                conn.send(("UNSAT", None, False))
        finally:
            solver.delete()
    except Exception as exc:
        conn.send(("FAILURE", None, repr(exc)))


def _slow_stub_worker(sleep_s: float, conn) -> None:
    time.sleep(float(sleep_s))
    conn.send(("SAT", {1: 0}, False))


def _run_killable(target, args, timeout_s: float, method: str) -> OracleResult:
    start = time.perf_counter()
    ctx = mp.get_context("spawn")
    parent, child = ctx.Pipe(duplex=False)
    proc = ctx.Process(target=target, args=(*args, child))
    proc.start()
    child.close()
    timed_out = False
    if parent.poll(timeout_s):
        payload = parent.recv()
    else:
        timed_out = True
        payload = None
        proc.terminate()
        proc.join(1.0)
        if proc.is_alive():
            proc.kill()
            proc.join(1.0)
    if proc.is_alive():
        proc.kill()
        proc.join(1.0)
    elapsed = time.perf_counter() - start
    parent.close()
    if timed_out:
        return OracleResult(
            "RESOURCE_LIMIT",
            None,
            method,
            elapsed,
            False,
            "enforced_timeout_killed_worker",
            extra={"timeout_s": timeout_s, "enforced": True},
        )
    status, assignment, extra = payload[0], payload[1], payload[2]
    if status == "FAILURE":
        return OracleResult("FAILURE", None, method, elapsed, False, str(extra))
    proof = False
    return OracleResult(status, assignment, method, elapsed, proof)


def pysat_sat(
    n_vars: int,
    clauses: tuple[tuple[int, ...], ...],
    timeout_s: float,
) -> OracleResult:
    probe = get_probe()
    if not probe.get("pysat"):
        return OracleResult(
            "SKIPPED",
            None,
            "pysat",
            0.0,
            False,
            f"pysat unavailable: {probe.get('errors', {}).get('pysat')}",
        )
    return _run_killable(_pysat_worker, (n_vars, clauses), timeout_s, "pysat-Glucose3-killable")


def slow_stub(timeout_s: float, sleep_s: float) -> OracleResult:
    """Deterministic watchdog: a worker that sleeps, not a hard SAT instance."""
    return _run_killable(_slow_stub_worker, (sleep_s,), timeout_s, "slow_stub_watchdog")


def independent_label(
    n_vars: int,
    clauses: tuple[tuple[int, ...], ...],
    exhaustive_max_n: int,
    timeout_s: float,
) -> OracleResult:
    if n_vars <= exhaustive_max_n:
        return exhaustive_sat(n_vars, clauses, max_n=exhaustive_max_n)
    return pysat_sat(n_vars, clauses, timeout_s)


def min_degree_order(n_vars: int, clauses: tuple[tuple[int, ...], ...]) -> tuple[int, ...]:
    adj: list[set[int]] = [set() for _ in range(n_vars + 1)]
    for clause in clauses:
        vs = {abs(lit) for lit in clause if lit}
        for a, b in combinations(vs, 2):
            adj[a].add(b)
            adj[b].add(a)
    remaining = set(range(1, n_vars + 1))
    order: list[int] = []
    while remaining:
        pick = min(remaining, key=lambda v: (len(adj[v] & remaining), v))
        order.append(pick)
        remaining.remove(pick)
    return tuple(order)


def baseline_d_bucket(
    n_vars: int,
    clauses: tuple[tuple[int, ...], ...],
    max_n: int,
    max_width: int,
) -> OracleResult:
    start = time.perf_counter()
    probe = get_probe()
    if n_vars > max_n:
        return OracleResult(
            "RESOURCE_LIMIT",
            None,
            "bucket_elim_min_degree",
            time.perf_counter() - start,
            False,
            "n>baseline_d_max_n",
        )
    if not probe.get("closure_sat"):
        return OracleResult(
            "SKIPPED",
            None,
            "bucket_elim_min_degree",
            time.perf_counter() - start,
            False,
            f"closure_sat unavailable: {probe.get('errors', {}).get('closure_sat')}",
        )
    order = min_degree_order(n_vars, clauses)
    try:
        result = probe["closure_sat_module"].solve_cnf(n_vars, clauses, order=order)
    except Exception as exc:
        return OracleResult("SKIPPED", None, "bucket_elim_min_degree", time.perf_counter() - start, False, repr(exc))
    elapsed = time.perf_counter() - start
    if result.induced_width > max_width:
        return OracleResult(
            "RESOURCE_LIMIT",
            None,
            "bucket_elim_min_degree",
            elapsed,
            False,
            f"induced_width={result.induced_width}>{max_width}",
            extra={"induced_width": result.induced_width, "rows": result.combined_rows_examined},
        )
    if result.satisfiable:
        assignment = {i + 1: int(bit) for i, bit in enumerate(result.assignment)}
        return OracleResult(
            "SAT",
            assignment,
            "bucket_elim_min_degree",
            elapsed,
            True,
            extra={"induced_width": result.induced_width, "rows": result.combined_rows_examined},
        )
    return OracleResult(
        "UNSAT",
        None,
        "bucket_elim_min_degree",
        elapsed,
        True,
        extra={"induced_width": result.induced_width, "rows": result.combined_rows_examined},
    )


def signed_graph_baseline(
    n_vars: int,
    clauses: tuple[tuple[int, ...], ...],
) -> OracleResult:
    start = time.perf_counter()
    for clause in clauses:
        cleaned = []
        seen = set()
        taut = False
        for lit in clause:
            if lit in seen:
                continue
            if -lit in seen:
                taut = True
                break
            seen.add(lit)
            cleaned.append(lit)
        if taut:
            continue
        if len(cleaned) == 0:
            return OracleResult("UNSAT", None, "signed_graph_baseline", time.perf_counter() - start, True)
        if len(cleaned) > 2:
            return OracleResult(
                "NOT_APPLICABLE",
                None,
                "signed_graph_baseline",
                time.perf_counter() - start,
                False,
                "clause_width>=3",
            )
    status, asg = _two_sat_implication(n_vars, clauses)
    elapsed = time.perf_counter() - start
    if status == "SAT":
        return OracleResult("SAT", asg, "signed_graph_baseline", elapsed, True)
    if status == "UNSAT":
        return OracleResult("UNSAT", None, "signed_graph_baseline", elapsed, True)
    return OracleResult(status, None, "signed_graph_baseline", elapsed, False, "unknown")


def _two_sat_implication(
    n_vars: int, clauses: tuple[tuple[int, ...], ...]
) -> tuple[str, dict[int, int] | None]:
    from collections import defaultdict

    graph: dict[int, list[int]] = defaultdict(list)
    for clause in clauses:
        cleaned = []
        seen = set()
        taut = False
        for lit in clause:
            if lit in seen:
                continue
            if -lit in seen:
                taut = True
                break
            seen.add(lit)
            cleaned.append(lit)
        if taut:
            continue
        if len(cleaned) == 0:
            return "UNSAT", None
        if len(cleaned) == 1:
            lit = cleaned[0]
            graph[-lit].append(lit)
        elif len(cleaned) == 2:
            a, b = cleaned
            graph[-a].append(b)
            graph[-b].append(a)
        else:
            return "NOT_APPLICABLE", None

    nodes = set(range(-n_vars, 0)) | set(range(1, n_vars + 1))
    index = 0
    stack: list[int] = []
    on = set()
    idx: dict[int, int] = {}
    low: dict[int, int] = {}
    scc_id: dict[int, int] = {}
    scc_count = 0

    def dfs(v: int) -> None:
        nonlocal index, scc_count
        idx[v] = index
        low[v] = index
        index += 1
        stack.append(v)
        on.add(v)
        for w in graph.get(v, ()):
            if w not in idx:
                dfs(w)
                low[v] = min(low[v], low[w])
            elif w in on:
                low[v] = min(low[v], idx[w])
        if low[v] == idx[v]:
            while True:
                w = stack.pop()
                on.remove(w)
                scc_id[w] = scc_count
                if w == v:
                    break
            scc_count += 1

    for v in nodes:
        if v not in idx:
            dfs(v)
    for var in range(1, n_vars + 1):
        if scc_id.get(var, -1) == scc_id.get(-var, -2):
            return "UNSAT", None
    assignment: dict[int, int] = {}
    for var in range(1, n_vars + 1):
        assignment[var] = 1 if scc_id[var] < scc_id[-var] else 0
    return "SAT", assignment


def affine_close_factors(factors: list[Any], n_vars: int) -> tuple[str, dict[int, int] | None, str]:
    """Known GF(2) close. Stdlib gaussian is the self-contained baseline."""
    eqs: list[tuple[tuple[int, ...], int]] = []
    seen: set[int] = set()
    for factor in factors:
        if factor.kind is Kind.TRUE:
            continue
        if factor.kind is Kind.FALSE:
            return "UNSAT", None, "stdlib_gf2_gaussian"
        if factor.kind is Kind.UNIT:
            var = abs(factor.lits[0])
            eqs.append(((var,), 1 if factor.lits[0] > 0 else 0))
            seen.add(var)
        elif factor.kind is Kind.SAME:
            a, b = factor.lits
            eqs.append(((a, b), 0))
            seen.update((a, b))
        elif factor.kind is Kind.DIFFERENT:
            a, b = factor.lits
            eqs.append(((a, b), 1))
            seen.update((a, b))
        elif factor.kind is Kind.PARITY:
            eqs.append((tuple(factor.lits), int(factor.parity)))
            seen.update(factor.lits)
        else:
            return "NOT_AFFINE", None, "mixed residual"
    return gf2_solve(eqs, n_vars)
