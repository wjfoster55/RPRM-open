from __future__ import annotations

import unittest

from sat_group_compiler.arithmetic import (
    clause_failure,
    penalty_from_clauses,
    reject_fractional,
    verify_binary_identities,
)
from sat_group_compiler.compiler import compile_cnf
from sat_group_compiler.dimacs import DimacsError, parse_dimacs
from sat_group_compiler.grammar import clause_from_lits
from sat_group_compiler.ir import Kind, Promise, cnf_holds
from sat_group_compiler.protocol import load_protocol, protocol_sha256, stage_limits
from sat_group_compiler.unsafe import triangle_unsafe_counterexample


def limits(variant=None):
    return stage_limits(load_protocol(), "smoke", variant)


class DimacsTests(unittest.TestCase):
    def test_empty_formula(self):
        p = parse_dimacs("p cnf 2 0\n")
        self.assertEqual(p.n_vars, 2)
        self.assertEqual(p.clauses, ())

    def test_empty_clause(self):
        p = parse_dimacs("p cnf 1 1\n0\n")
        self.assertEqual(p.clauses, ((),))

    def test_out_of_range(self):
        with self.assertRaises(DimacsError):
            parse_dimacs("p cnf 1 1\n2 0\n")

    def test_missing_header(self):
        with self.assertRaises(DimacsError):
            parse_dimacs("1 0\n")

    def test_header_mismatch_warning(self):
        p = parse_dimacs("p cnf 1 9\n1 0\n")
        self.assertTrue(p.warnings)

    def test_unused_declared(self):
        p = parse_dimacs("p cnf 3 1\n1 0\n")
        self.assertEqual(p.n_vars, 3)


class ArithmeticTests(unittest.TestCase):
    def test_identities(self):
        ids = verify_binary_identities()
        self.assertTrue(ids["different_binary"])
        self.assertTrue(ids["same_binary"])
        self.assertFalse(ids["different_polynomials_equal_over_Z"])

    def test_empty_clause_constant_one(self):
        pen = penalty_from_clauses(((),))
        self.assertEqual(pen.constant_offset(), 1)
        self.assertEqual(pen.evaluate({1: 0}), 1)

    def test_duplicate_lits_promise_a(self):
        pen = penalty_from_clauses(((1, 1),))
        self.assertEqual(pen.evaluate({1: 0}), 1)
        self.assertEqual(pen.evaluate({1: 1}), 0)
        self.assertEqual(clause_failure((1, 1)).evaluate({1: 0}), 1)

    def test_duplicate_clauses_change_penalty_not_zero_set(self):
        one = penalty_from_clauses(((1,),))
        two = penalty_from_clauses(((1,), (1,)))
        self.assertEqual(one.evaluate({1: 0}), 1)
        self.assertEqual(two.evaluate({1: 0}), 2)
        self.assertEqual(one.evaluate({1: 1}), 0)
        self.assertEqual(two.evaluate({1: 1}), 0)

    def test_reject_fractional(self):
        with self.assertRaises(ValueError):
            reject_fractional({1: 0.5})


class CompilerSmokeTests(unittest.TestCase):
    def test_empty_sat(self):
        r = compile_cnf("p cnf 2 0\n", mode="A", limits=limits())
        self.assertEqual(r.status, "SAT")
        self.assertTrue(cnf_holds((), r.assignment))

    def test_empty_clause_unsat(self):
        r = compile_cnf("p cnf 1 1\n0\n", mode="A", limits=limits())
        self.assertEqual(r.status, "UNSAT")

    def test_tautology_sat(self):
        r = compile_cnf("p cnf 1 1\n1 -1 0\n", mode="A", limits=limits())
        self.assertEqual(r.status, "SAT")

    def test_unit(self):
        r = compile_cnf("p cnf 1 1\n1 0\n", mode="A", limits=limits())
        self.assertEqual(r.status, "SAT")
        self.assertEqual(r.assignment[1], 1)

    def test_triangle_unsat_pairs(self):
        text = "p cnf 3 6\n1 2 0\n-1 -2 0\n2 3 0\n-2 -3 0\n3 1 0\n-3 -1 0\n"
        a = compile_cnf(text, mode="A", limits=limits())
        b = compile_cnf(text, mode="B", limits=limits())
        c = compile_cnf(text, mode="C", limits=limits("W3"))
        self.assertEqual(a.status, "UNRESOLVED")
        self.assertEqual(b.status, "UNSAT")
        self.assertEqual(c.status, "UNSAT")
        self.assertTrue(b.receipts)

    def test_exactly_one_triple_advantage(self):
        text = "p cnf 3 4\n-1 -2 0\n-1 -3 0\n-2 -3 0\n1 2 3 0\n"
        b = compile_cnf(text, mode="B", limits=limits())
        c = compile_cnf(text, mode="C", limits=limits("W3"), variant="W3")
        self.assertEqual(b.status, "UNRESOLVED")
        self.assertEqual(c.status, "SAT")
        self.assertTrue(cnf_holds(((-1, -2), (-1, -3), (-2, -3), (1, 2, 3)), c.assignment))

    def test_xor3_stall_w3(self):
        text = "p cnf 3 4\n1 2 3 0\n1 -2 -3 0\n-1 2 -3 0\n-1 -2 3 0\n"
        c = compile_cnf(text, mode="C", limits=limits("W3"), variant="W3", retain=[1, 2, 3], use_affine=False)
        self.assertEqual(c.status, "UNRESOLVED")
        self.assertFalse(any(s.startswith("P:") for s in c.residual))

    def test_malformed(self):
        r = compile_cnf("p cnf 1 1\n2 0\n", mode="A", limits=limits())
        self.assertEqual(r.status, "MALFORMED")

    def test_no_pysat_in_compiler_source(self):
        from pathlib import Path

        src = Path(__file__).resolve().parents[1] / "sat_group_compiler" / "compiler.py"
        self.assertNotIn("pysat", src.read_text(encoding="utf-8"))

    def test_wall_time_recorded(self):
        r = compile_cnf("p cnf 1 1\n1 0\n", mode="A", limits=limits())
        self.assertGreaterEqual(r.meter.wall_s, 0.0)
        self.assertGreater(r.meter.initial_ir_bytes, 0)


class PromiseTests(unittest.TestCase):
    def test_tautology_true_factor(self):
        f = clause_from_lits((1, -1), fid=1)
        self.assertEqual(f.kind, Kind.TRUE)
        self.assertEqual(f.promise, Promise.A)

    def test_dup_lits_become_unit(self):
        f = clause_from_lits((1, 1), fid=1)
        self.assertEqual(f.kind, Kind.UNIT)


class UnsafeTests(unittest.TestCase):
    def test_counterexample_preserved(self):
        payload = triangle_unsafe_counterexample()
        self.assertTrue(payload["unsafe_unsound"])
        self.assertTrue(payload["kept_out_of_candidate"])


class ProtocolTests(unittest.TestCase):
    def test_hash_stable(self):
        a = protocol_sha256()
        b = protocol_sha256()
        self.assertEqual(a, b)
        self.assertEqual(len(a), 64)
        self.assertEqual(load_protocol()["protocol_version"], "v2")


if __name__ == "__main__":
    unittest.main()
