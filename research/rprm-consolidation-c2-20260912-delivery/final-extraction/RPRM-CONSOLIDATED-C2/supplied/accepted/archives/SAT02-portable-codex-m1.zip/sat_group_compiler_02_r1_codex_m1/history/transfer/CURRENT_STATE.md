# SAT02-R1 current state for Codex M1

**Snapshot: 12 September 2026. Source review and maintenance handoff, not a new experiment.**

## Decision already made

SAT02-R1 is an accepted **partial research closeout**. Do not reopen the research
question to finish a checker integration. The accepted local results are the exact
protected XOR/W3-T route and three-color specimens. Comparative and whole-solver
certification claims are not accepted as originally stated.

The owner has NOT integrated the reviewer's one-file patch. The latest user-supplied
`status/CLOSEOUT_R1_STATUS.md` explicitly qualifies the old owner row calling the
checker repaired. Group-ID generation, timing-boundary, and fingerprint-output
repairs remain in force.

## Exact pending maintenance

1. Recovery can overwrite retained boundary variables and still be labelled
   `local_relation_checked`. For retained A in A != X, producing a satisfying pair
   with a *different A* is not reconstruction of the requested boundary.
2. The R1 checker rejects 50 valid empty-local-relation receipts for missing
   recovery. Empty local relations have no satisfying boundary assignments that
   require witnesses. Emptiness must be independently recomputed; it cannot be
   inferred merely from a receipt's asserted zero mask.

The reviewer candidate changes only `sat_group_compiler/receipts.py`. It enforces
output keys equal to the eliminated variables, retains the original boundary,
checks recovered Boolean values, and treats recovery on a recomputed empty
relation as vacuous. The earlier review reports 73 existing tests plus six focused
regressions passing and all 982 saved receipts accepted by the candidate. These
are **prior review results**, not execution performed by this handoff or Codex.

## Identities

| Artifact | SHA-256 |
|---|---|
| Submitted R1 ZIP | `26c17cb940a599afecb08f16c993a4f646aa347138a59812ea70aaa326dc155a` |
| Original SAT02 ZIP | `a32587d9657ce87366632c8bd93c25bff757b5ac575bda8dfde76602bd26b9ea` |
| Previous closeout review ZIP | `593225835432ae123138c450acc6856eec0bbad50ffd436e9b3002888ac7b2be` |
| Latest overlay | `da573f5ddc0e42eeecc75ada34a9d8d970f655bb95c54046fde4cb4a211c74fe` |
| Submitted R1 checker | `ececdfdfa4c074b094810c1b58cfe081086cfd638f7e04f34cfc5997184d0c8d` |
| Reviewer candidate checker | `137d2748bffc085af709707275333a54166aa85229365fb2745f6f6bc0b3ea3f` |

`INPUT_BINDINGS.json` records the input bytes and extracted mirrors. The current
package confirms the uploaded identities, **not the state of William's live
unuploaded checkout**. Verify the actual working files before integrating.

## Claims that must survive unchanged

| Item | Preserved scope |
|---|---|
| W3-T route | Temporary TABLE score 15→18, followed by 23→6. A local structural route, not elapsed time or a universal SAT shortcut. |
| Three-color star | 21/27 boundary assignments extend; all pair projections have all nine assignments. |
| Overlapping three-color factors | The correct two-factor conjunction accepts 147/243. The single union atom accepts 93/243 and is not equivalent. |
| Original seed coverage | Development 23, 29, 31 and evaluation 20011, 20021, 20047 RUN. Development 37, 41 and evaluation 20063, 20089 NOT_RUN. |
| Saved panels | 466 existing result rows; 982 local receipts. Rechecking them is not a new panel run or a complete solver proof. |
| Test history | Original 57/57; submitted R1 73/73; the review's six additional regressions remain a separate set until explicitly integrated. |
| Work accounting | Primary table-row cap is not a complete work budget. No clean speed ranking or ten-seed completion. |
| Proof boundary | Local relation/recovery checking, not original-factor-ID binding or complete original-instance solver derivation. |
| Source history | Preserve unavailable pre-run inventories as unavailable. Do not reconstruct historical logs and call them original evidence. |

A retained two-factor relation need not be flattened into a single named atom to
be useful. The next scientific operation would need its own question and budget;
that is outside this integration.

## Finish condition

One fresh maintenance successor with an inspected, integrated checker correction,
existing tests and six targeted regressions rerun, saved receipts reconciled,
accurate source/diff identity, and an actual final-ZIP replay. Return the portable
ZIP and external evidence with separate SHA-256 files, then stop.

All other lane states are unchanged. No new research, full panel run, seed backfill,
Task03, commit, push, merge, publication, installation, or other-lane dispatch.

Sources: latest status overlay; `review/REVIEW.md` §§Decision, Remaining issues,
One-file candidate, What closes; `review/CLOSEOUT_MESSAGE.md`; R1
`PROTOCOL_R1_LIMITS.md`, `SEED_STATUS.json`, and `CLAIM_LEDGER.md`.
