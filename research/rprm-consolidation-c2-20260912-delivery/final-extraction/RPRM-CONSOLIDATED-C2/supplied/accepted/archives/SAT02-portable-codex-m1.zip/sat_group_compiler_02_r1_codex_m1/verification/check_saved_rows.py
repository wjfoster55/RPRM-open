"""Emit every saved local outcome and narrow M1 hostile controls. No panels.

The prior interpreter and output-scope guard are reused from the supplied review;
they are not a newly independent method or a whole-instance verifier.
"""
import argparse
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from sat_group_compiler.receipts import check_rewrite_receipt, _apply_closed_form

def sha(data):
    return hashlib.sha256(data).hexdigest()

def save(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n', encoding='utf-8')

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--output', type=Path, required=True)
    args = ap.parse_args()
    out = args.output.resolve()
    assert not out.is_relative_to(ROOT), 'Keep verification evidence external to the build'
    out.mkdir(parents=True, exist_ok=False)
    spec = importlib.util.spec_from_file_location('prior_oracle_rows', ROOT / 'verification/prior/scripts/review_sat02.py')
    prior = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(prior)

    def independent(p):
        errors = prior.independent_receipt(p)
        if p.get('eliminated'):
            rec = p.get('recovery') or {}
            gone = set(p['eliminated'])
            if rec.get('type') == 'closed_form':
                if set(map(int, rec.get('map', {}))) != gone:
                    errors.append('recovery_output_not_exactly_eliminated')
            if rec.get('type') == 'lex_table':
                for row in rec.get('rows', []):
                    if set(map(int, row.get('internal', {}))) != gone:
                        errors.append('recovery_output_not_exactly_eliminated')
        return sorted(set(errors))

    records = []
    panels = []
    for panel in ['smoke', 'stress', 'stage1', 'development', 'evaluation']:
        data = (ROOT / 'saved/results' / (panel + '.json')).read_bytes()
        rows = json.loads(data)
        counts = {}
        for i, row in enumerate(rows):
            status = str(row.get('candidate_status', '<absent>'))
            counts[status] = counts.get(status, 0) + 1
            for j, payload in enumerate(row.get('receipts', [])):
                mask = sum(1 << sum(a[v] << k for k, v in enumerate(payload['scope']))
                    for a in prior.assignments(payload['scope'])
                    if all(prior.atom_truth(atom, a) for atom in payload['input_identities']))
                records.append({'panel': panel, 'row': i, 'receipt': j,
                    'payload_sha256': sha(json.dumps(payload, sort_keys=True, separators=(',', ':')).encode()),
                    'checker': check_rewrite_receipt(payload), 'independent_errors': independent(payload),
                    'independently_recomputed_mask': mask, 'stored_mask': payload['group_sat_mask'],
                    'promise': payload['promise'], 'replacement': payload['replacement'],
                    'recovery_type': (payload.get('recovery') or {}).get('type', 'none')})
        panels.append({'panel': panel, 'sha256': sha(data), 'result_rows': len(rows), 'saved_status_counts': counts,
            'receipt_count': sum(len(r.get('receipts', [])) for r in rows)})
    save(out / 'all_982_receipt_rows.json', records)

    base = {'promise': 'C', 'scope': [1, 2], 'boundary': [1], 'eliminated': [2],
        'input_identities': ['D:1,2'], 'replacement': ['T'], 'group_sat_mask': 6,
        'recovery': {'type': 'closed_form', 'map': {'2': ['lit', -1]}}}
    controls = []

    def control(name, changes, ok, reason=None):
        p = copy.deepcopy(base)
        p.update(copy.deepcopy(changes))
        actual = check_rewrite_receipt(p)
        row = {'name': name, 'payload': p, 'expected_ok': ok, 'expected_reason': reason, 'checker': actual,
            'matches_expected': actual['ok'] == ok and (reason is None or reason in actual['reasons'])}
        if not p['eliminated'] and p.get('recovery'):
            traces = []
            for b in prior.assignments(p['boundary']):
                if not all(prior.atom_truth(atom, b) for atom in p['input_identities']):
                    continue
                rec = p['recovery']
                recovered = dict(b)
                if rec['type'] == 'closed_form':
                    recovered = _apply_closed_form(rec['map'], b)
                elif rec['type'] == 'lex_table':
                    for entry in rec['rows']:
                        if {int(k): int(v) for k, v in entry['boundary'].items()} == b:
                            recovered.update({int(k): int(v) for k, v in entry['internal'].items()})
                            break
                traces.append({'boundary': b, 'recovered': recovered,
                    'preserves_boundary': all(recovered.get(k) == v for k, v in b.items()),
                    'satisfies_local_relation': all(prior.atom_truth(atom, recovered) for atom in p['input_identities'])})
            row['recovery_traces'] = traces
        controls.append(row)

    good_table = {'type': 'lex_table', 'rows': [
        {'boundary': {'1': 0}, 'internal': {'2': 1}}, {'boundary': {'1': 1}, 'internal': {'2': 0}}]}
    control('valid_closed', {}, True)
    control('valid_table', {'recovery': good_table}, True)
    control('wrong_closed', {'recovery': {'type': 'closed_form', 'map': {'2': ['lit', 1]}}}, False, 'recovery_wrong')
    wrong_table = copy.deepcopy(good_table)
    wrong_table['rows'][0]['internal']['2'] = 0
    control('wrong_table', {'recovery': wrong_table}, False, 'recovery_row_misses_original_group')
    control('missing_recovery', {'recovery': {}}, False, 'recovery_missing')
    control('empty_table', {'recovery': {'type': 'lex_table', 'rows': []}}, False, 'recovery_row_coverage')
    control('incomplete_table', {'recovery': {'type': 'lex_table', 'rows': good_table['rows'][:1]}}, False, 'recovery_row_coverage')
    control('overlap_partition', {'eliminated': [1, 2]}, False, 'scope_partition')
    control('closed_boundary_overwrite', {'recovery': {'type': 'closed_form', 'map': {'1': ['lit', -1], '2': ['lit', -1]}}}, False, 'recovery_output_scope')
    control('table_boundary_overwrite', {'recovery': {'type': 'lex_table', 'rows': [
        {'boundary': {'1': 0}, 'internal': {'1': 1, '2': 0}}, {'boundary': {'1': 1}, 'internal': {'1': 0, '2': 1}}]}}, False, 'recovery_output_scope')
    control('nonbinary_closed', {'recovery': {'type': 'closed_form', 'map': {'2': ['const', 2]}}}, False, 'recovery_nonbinary')
    control('nonbinary_table', {'recovery': {'type': 'lex_table', 'rows': [
        {'boundary': {'1': 0}, 'internal': {'2': 2}}, {'boundary': {'1': 1}, 'internal': {'2': 2}}]}}, False, 'recovery_nonbinary')
    empty = {'input_identities': ['U:1', 'U:-1'], 'scope': [1], 'boundary': [], 'eliminated': [1],
             'group_sat_mask': 0, 'replacement': ['F'], 'recovery': {}}
    control('empty_no_witness', empty, True)
    control('false_zero_nonempty', {'group_sat_mask': 0, 'recovery': {}}, False, 'stored_group_sat_mask_mismatch')
    control('true_for_empty', dict(empty, replacement=['T']), False, 'empty_boundary_false_mismatch')
    retained_empty = {'input_identities': ['U:2', 'U:-2'], 'group_sat_mask': 0, 'replacement': ['F'], 'recovery': {}}
    control('empty_retained_no_witness', retained_empty, True)
    control('empty_retained_wrong_projection', dict(retained_empty, replacement=['T']), False, 'promise_C_projection_mismatch')
    identity = {'boundary': [1, 2], 'eliminated': [], 'replacement': ['D:1,2'], 'recovery': {}}
    control('no_elimination_identity', identity, True)
    control('no_elimination_closed_overwrite', dict(identity, recovery={'type': 'closed_form', 'map': {'1': ['lit', -1], '2': ['lit', -2]}}), False, 'recovery_output_scope')
    control('no_elimination_table_overwrite', dict(identity, recovery={'type': 'lex_table', 'rows': [
        {'boundary': {'1': 0, '2': 1}, 'internal': {'1': 1, '2': 0}},
        {'boundary': {'1': 1, '2': 0}, 'internal': {'1': 0, '2': 1}}]}), False, 'recovery_output_scope')
    control('no_elimination_empty_closed_identity', dict(identity, recovery={'type': 'closed_form', 'map': {}}), True)
    control('no_elimination_empty_table_identity', dict(identity, recovery={'type': 'lex_table', 'rows': []}), True)
    control('no_elimination_complete_table_identity', dict(identity, recovery={'type': 'lex_table', 'rows': [
        {'boundary': {'1': 0, '2': 1}, 'internal': {}}, {'boundary': {'1': 1, '2': 0}, 'internal': {}}]}), True)
    save(out / 'm1_boundary_controls.json', controls)
    failures = [c['name'] for c in controls if not c['matches_expected']]
    rejected = [r for r in records if not r['checker']['ok']]
    independent_errors = [r for r in records if r['independent_errors']]
    scope_ok = all(r['checker']['binds_original_factor_ids'] is False and r['checker']['whole_solver_derivation_replayed'] is False for r in records)
    summary = {'panels': panels, 'result_rows': sum(p['result_rows'] for p in panels), 'receipt_count': len(records),
        'accepted': len(records) - len(rejected), 'rejected': len(rejected), 'independent_errors': len(independent_errors),
        'control_count': len(controls), 'control_failures': failures, 'scope_flags_remain_false': scope_ok,
        'checker_sha256': sha((ROOT/'sat_group_compiler/receipts.py').read_bytes()),
        'prior_interpreter_sha256': sha((ROOT/'verification/prior/scripts/review_sat02.py').read_bytes()),
        'claim': 'Saved local relation/recovery replay; no new panels or whole-solver proof.'}
    save(out / 'row_audit_summary.json', summary)
    print(json.dumps(summary, indent=2))
    assert len(records) == 982 and summary['result_rows'] == 466 and scope_ok
    assert not rejected and not independent_errors and not failures

if __name__ == '__main__':
    main()
