"""Calibration only. Not the automatic compiler and not a performance result."""

from __future__ import annotations

import json
from pathlib import Path

from sat_group_compiler.arithmetic import (
    different_pair_sum,
    different_square,
    same_pair_sum,
    same_square,
    verify_binary_identities,
)
from sat_group_compiler.backends import independent_label
from sat_group_compiler.dimacs import parse_dimacs
from sat_group_compiler.generators import triangle_fixture

ROOT = Path(__file__).resolve().parent


def main() -> int:
    identities = verify_binary_identities()
    tri = triangle_fixture()
    parsed = parse_dimacs(tri.dimacs)
    whole = independent_label(parsed.n_vars, parsed.clauses, 12, 5.0)
    pairs = [
        independent_label(3, parsed.clauses[0:2], 12, 5.0).status,
        independent_label(3, parsed.clauses[2:4], 12, 5.0).status,
        independent_label(3, parsed.clauses[4:6], 12, 5.0).status,
    ]
    impossible = True
    for a in (0, 1):
        for b in (0, 1):
            for c in (0, 1):
                if 2 * (a + b + c) == 3:
                    impossible = False
    fractional = 0.5 + 0.5 + 0.5
    payload = {
        "role": "calibration_only_not_compiler_performance",
        "identities": identities,
        "sample_different_00": [different_pair_sum(0, 0), different_square(0, 0)],
        "sample_same_10": [same_pair_sum(1, 0), same_square(1, 0)],
        "triangle_clauses": len(parsed.clauses),
        "triangle_whole": whole.status,
        "each_pair": pairs,
        "2(a+b+c)=3_impossible_on_binary": impossible,
        "fractional_half_is_not_a_boolean_witness": True,
        "real_sum_check_2_times_three_halves": 2 * fractional,
    }
    out = ROOT / "results" / "verify_seed.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    print(json.dumps(payload, indent=2))
    if not identities["different_binary"] or not identities["same_binary"]:
        return 1
    if identities["different_polynomials_equal_over_Z"]:
        return 1
    if whole.status != "UNSAT" or pairs != ["SAT", "SAT", "SAT"]:
        return 1
    if not impossible:
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
