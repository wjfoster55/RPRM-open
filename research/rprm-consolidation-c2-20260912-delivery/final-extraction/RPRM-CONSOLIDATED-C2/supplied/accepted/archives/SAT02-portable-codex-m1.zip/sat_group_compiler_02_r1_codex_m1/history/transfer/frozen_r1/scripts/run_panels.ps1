$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot\..
$env:PYTHONPATH = (Get-Location).Path
python run.py freeze
python run.py panels --split development
python run.py panels --split evaluation
python run.py controls
python run.py unsafe
python run.py minimality
