"""Evaluator-only instance generators. Labels are not given to the candidate."""

from __future__ import annotations

from dataclasses import dataclass
import random

from .dimacs import to_dimacs


@dataclass
class EvalInstance:
    instance_id: str
    dimacs: str
    family: str
    split: str
    seed: int | None
    notes: str = ""


def _shuffle_clauses(clauses: list[tuple[int, ...]], rng: random.Random) -> list[tuple[int, ...]]:
    out = []
    for clause in clauses:
        lits = list(clause)
        rng.shuffle(lits)
        out.append(tuple(lits))
    rng.shuffle(out)
    return out


def same_clauses(a: int, b: int) -> list[tuple[int, ...]]:
    return [(a, -b), (-a, b)]


def different_clauses(a: int, b: int) -> list[tuple[int, ...]]:
    return [(a, b), (-a, -b)]


def triangle_fixture() -> EvalInstance:
    dimacs = "p cnf 3 6\n1 2 0\n-1 -2 0\n2 3 0\n-2 -3 0\n3 1 0\n-3 -1 0\n"
    return EvalInstance("cal:triangle", dimacs, "triangle", "calibration", None, "supplied fixture")


def different_cycle(n: int, seed: int, split: str) -> EvalInstance:
    rng = random.Random(seed)
    clauses: list[tuple[int, ...]] = []
    for i in range(1, n + 1):
        j = i + 1 if i < n else 1
        clauses.extend(different_clauses(i, j))
    clauses = _shuffle_clauses(clauses, rng)
    return EvalInstance(
        f"{split}:diff_cycle:n={n}:seed={seed}",
        to_dimacs(n, clauses),
        "diff_cycle",
        split,
        seed,
        f"length {n}",
    )


def same_path(n: int, seed: int, split: str) -> EvalInstance:
    rng = random.Random(seed)
    clauses: list[tuple[int, ...]] = []
    for i in range(1, n):
        clauses.extend(same_clauses(i, i + 1))
    clauses = _shuffle_clauses(clauses, rng)
    return EvalInstance(
        f"{split}:same_path:n={n}:seed={seed}",
        to_dimacs(n, clauses),
        "same_path",
        split,
        seed,
    )


def different_tree(n: int, seed: int, split: str) -> EvalInstance:
    rng = random.Random(seed)
    clauses: list[tuple[int, ...]] = []
    for i in range(2, n + 1):
        parent = rng.randint(1, i - 1)
        clauses.extend(different_clauses(parent, i))
    clauses = _shuffle_clauses(clauses, rng)
    return EvalInstance(
        f"{split}:diff_tree:n={n}:seed={seed}",
        to_dimacs(n, clauses),
        "diff_tree",
        split,
        seed,
    )


def signed_graph(n: int, m: int, seed: int, split: str, with_units: bool = False) -> EvalInstance:
    rng = random.Random(seed)
    edges: set[tuple[int, int]] = set()
    clauses: list[tuple[int, ...]] = []
    while len(edges) < m and len(edges) < n * (n - 1) // 2:
        a = rng.randint(1, n)
        b = rng.randint(1, n)
        if a == b:
            continue
        key = (min(a, b), max(a, b))
        if key in edges:
            continue
        edges.add(key)
        if rng.randrange(2) == 0:
            clauses.extend(same_clauses(*key))
        else:
            clauses.extend(different_clauses(*key))
    if with_units and n >= 1:
        clauses.append((rng.choice([1, -1, n, -n]),))
    clauses = _shuffle_clauses(clauses, rng)
    return EvalInstance(
        f"{split}:signed_graph:n={n}:m={m}:seed={seed}:u={int(with_units)}",
        to_dimacs(n, clauses),
        "signed_graph",
        split,
        seed,
    )


def amo3() -> EvalInstance:
    dimacs = "p cnf 3 3\n-1 -2 0\n-1 -3 0\n-2 -3 0\n"
    return EvalInstance("cal:amo3", dimacs, "amo3", "calibration", None, "triple-advantage fixture")


def xor3_four_clauses() -> EvalInstance:
    dimacs = "p cnf 3 4\n1 2 3 0\n1 -2 -3 0\n-1 2 -3 0\n-1 -2 3 0\n"
    return EvalInstance("cal:xor3_cnf4", dimacs, "xor3_cnf4", "calibration", None, "parity as four clauses")


def exactly_one_system(k: int, seed: int, split: str) -> EvalInstance:
    rng = random.Random(seed)
    clauses: list[tuple[int, ...]] = [tuple(range(1, k + 1))]
    for i in range(1, k + 1):
        for j in range(i + 1, k + 1):
            clauses.append((-i, -j))
    clauses = _shuffle_clauses(clauses, rng)
    return EvalInstance(
        f"{split}:xo:k={k}:seed={seed}",
        to_dimacs(k, clauses),
        "exactly_one",
        split,
        seed,
    )


def random_3cnf(n: int, m: int, seed: int, split: str) -> EvalInstance:
    rng = random.Random(seed)
    clauses: list[tuple[int, ...]] = []
    for _ in range(m):
        vs = rng.sample(range(1, n + 1), 3)
        lits = tuple(v if rng.randrange(2) else -v for v in vs)
        clauses.append(lits)
    clauses = _shuffle_clauses(clauses, rng)
    return EvalInstance(
        f"{split}:rand3:n={n}:m={m}:seed={seed}",
        to_dimacs(n, clauses),
        "random_3cnf",
        split,
        seed,
    )


def mixed_parity_or(n: int, seed: int, split: str) -> EvalInstance:
    rng = random.Random(seed)
    clauses: list[tuple[int, ...]] = []
    # one 3-XOR as four clauses on 1,2,3 if n>=3
    if n >= 3:
        clauses.extend(
            [
                (1, 2, 3),
                (1, -2, -3),
                (-1, 2, -3),
                (-1, -2, 3),
            ]
        )
    for _ in range(max(1, n // 2)):
        vs = rng.sample(range(1, n + 1), min(3, n))
        clauses.append(tuple(v if rng.randrange(2) else -v for v in vs))
    clauses = _shuffle_clauses(clauses, rng)
    return EvalInstance(
        f"{split}:mixed_parity_or:n={n}:seed={seed}",
        to_dimacs(n, clauses),
        "mixed_parity_or",
        split,
        seed,
    )


def pigeonhole(pigeons: int, holes: int) -> EvalInstance:
    # var (i,j) -> i*holes + j + 1, i in 0..p-1, j in 0..h-1
    n = pigeons * holes
    clauses: list[tuple[int, ...]] = []

    def var(i: int, j: int) -> int:
        return i * holes + j + 1

    for i in range(pigeons):
        clauses.append(tuple(var(i, j) for j in range(holes)))
    for j in range(holes):
        for i in range(pigeons):
            for k in range(i + 1, pigeons):
                clauses.append((-var(i, j), -var(k, j)))
    return EvalInstance(
        f"cal:php:p={pigeons}:h={holes}",
        to_dimacs(n, clauses),
        "pigeonhole",
        "calibration",
        None,
    )


def graph_coloring_cycle(n: int, colors: int) -> EvalInstance:
    n_vars = n * colors
    clauses: list[tuple[int, ...]] = []

    def var(v: int, c: int) -> int:
        return (v - 1) * colors + c + 1

    for v in range(1, n + 1):
        clauses.append(tuple(var(v, c) for c in range(colors)))
        for c1 in range(colors):
            for c2 in range(c1 + 1, colors):
                clauses.append((-var(v, c1), -var(v, c2)))
    for v in range(1, n + 1):
        w = v + 1 if v < n else 1
        for c in range(colors):
            clauses.append((-var(v, c), -var(w, c)))
    return EvalInstance(
        f"cal:color_cn:n={n}:k={colors}",
        to_dimacs(n_vars, clauses),
        "graph_coloring",
        "calibration",
        None,
        f"C{n} with {colors} colors",
    )


def empty_formula(n: int = 2) -> EvalInstance:
    return EvalInstance("cal:empty", to_dimacs(n, []), "empty", "calibration", None)


def empty_clause() -> EvalInstance:
    return EvalInstance("cal:empty_clause", "p cnf 1 1\n0\n", "empty_clause", "calibration", None)


def tautology_only() -> EvalInstance:
    return EvalInstance("cal:tautology", "p cnf 1 1\n1 -1 0\n", "tautology", "calibration", None)


def unused_vars() -> EvalInstance:
    return EvalInstance("cal:unused", "p cnf 3 1\n1 0\n", "unused_vars", "calibration", None)


def duplicate_lits() -> EvalInstance:
    return EvalInstance("cal:dup_lits", "p cnf 1 1\n1 1 0\n", "dup_lits", "calibration", None)


def contraction_seed() -> EvalInstance:
    """a!=b, b!=c, plus (a ∨ c). Boundary {a,c} if grouped first."""
    dimacs = "p cnf 3 5\n1 2 0\n-1 -2 0\n2 3 0\n-2 -3 0\n1 3 0\n"
    return EvalInstance("cal:contraction_path", dimacs, "contraction", "calibration", None)


def unsafe_counterexample_cnf() -> EvalInstance:
    """Triangle: two DIFF as block, third DIFF outside. Original UNSAT."""
    return triangle_fixture()


def xor_clauses(vars_: tuple[int, int, int], parity: int) -> list[tuple[int, ...]]:
    a, b, c = vars_
    # Forbid assignments whose XOR differs from the target parity.
    clauses: list[tuple[int, ...]] = []
    for mask in range(8):
        bits = [(mask >> i) & 1 for i in range(3)]
        if (bits[0] ^ bits[1] ^ bits[2]) == parity:
            continue
        clause = tuple(v if bit == 0 else -v for v, bit in zip((a, b, c), bits, strict=True))
        clauses.append(clause)
    return clauses


def xor3_instance(
    parity: int,
    split: str = "calibration",
    seed: int | None = None,
    vars_: tuple[int, int, int] = (1, 2, 3),
    n_vars: int | None = None,
) -> EvalInstance:
    clauses = xor_clauses(vars_, parity)
    n = n_vars or max(vars_)
    return EvalInstance(
        f"{split}:xor3:p={parity}:vars={vars_[0]},{vars_[1]},{vars_[2]}",
        to_dimacs(n, clauses),
        "xor3",
        split,
        seed,
        f"parity={parity}",
    )


def xor3_even() -> EvalInstance:
    return xor3_instance(0)


def xor3_odd() -> EvalInstance:
    return xor3_instance(1)


def xor3_renamed(seed: int, split: str) -> EvalInstance:
    rng = random.Random(seed)
    names = [1, 2, 3]
    rng.shuffle(names)
    inst = xor3_instance(1, split, seed, (names[0], names[1], names[2]))
    inst.instance_id = f"{split}:xor3_renamed:seed={seed}"
    return inst


def xor3_complemented(flipped: tuple[int, ...], split: str) -> EvalInstance:
    from .controls import complement_cnf

    base = xor3_odd()
    text = complement_cnf(base.dimacs, set(flipped))
    return EvalInstance(
        f"{split}:xor3_comp:{','.join(str(v) for v in flipped)}",
        text,
        "xor3",
        split,
        None,
        "complemented variables; parity may flip with an odd number of flips",
    )


def xor3_with_dups_taut(seed: int, split: str) -> EvalInstance:
    from .controls import add_tautologies, duplicate_some_clauses, reorder_cnf

    text = xor3_odd().dimacs
    text = duplicate_some_clauses(text, seed)
    text = add_tautologies(text, seed)
    text = reorder_cnf(text, seed)
    return EvalInstance(f"{split}:xor3_dups_taut:seed={seed}", text, "xor3", split, seed)


def xor3_near_miss_delete(index: int, split: str) -> EvalInstance:
    clauses = xor_clauses((1, 2, 3), 1)
    del clauses[index]
    return EvalInstance(
        f"{split}:xor3_near_miss_delete:{index}",
        to_dimacs(3, clauses),
        "xor3_near_miss",
        split,
        None,
        "deleted one XOR clause; relation is strictly weaker than parity",
    )


def xor3_near_miss_flip(index: int, split: str) -> EvalInstance:
    clauses = xor_clauses((1, 2, 3), 1)
    first = list(clauses[index])
    first[0] = -first[0]
    clauses[index] = tuple(first)
    return EvalInstance(
        f"{split}:xor3_near_miss_flip:{index}",
        to_dimacs(3, clauses),
        "xor3_near_miss",
        split,
        None,
        "flipped one literal; must not become XOR=1",
    )


def xor3_embedded(n: int, seed: int, split: str) -> EvalInstance:
    """XOR block on 1,2,3 plus live outside connections. No block labels in DIMACS."""
    rng = random.Random(seed)
    clauses = xor_clauses((1, 2, 3), 1)
    extra_n = max(n, 6)
    # Outside connections: each of 1,2,3 appears with a fresh variable.
    clauses.append((1, 4))
    clauses.append((2, 5))
    clauses.append((-3, 6))
    for _ in range(max(1, extra_n - 6)):
        vs = rng.sample(range(4, extra_n + 1), min(2, extra_n - 3))
        clauses.append(tuple(v if rng.randrange(2) else -v for v in vs))
    clauses = _shuffle_clauses(clauses, rng)
    return EvalInstance(
        f"{split}:xor3_embedded:n={extra_n}:seed={seed}",
        to_dimacs(extra_n, clauses),
        "xor3_embedded",
        split,
        seed,
    )


def xor_network(n_blocks: int, seed: int, split: str) -> EvalInstance:
    rng = random.Random(seed)
    clauses: list[tuple[int, ...]] = []
    n_vars = n_blocks + 2
    for i in range(n_blocks):
        a, b, c = i + 1, i + 2, i + 3
        clauses.extend(xor_clauses((a, b, c), 1))
    clauses = _shuffle_clauses(clauses, rng)
    return EvalInstance(
        f"{split}:xor_network:blocks={n_blocks}:seed={seed}",
        to_dimacs(n_vars, clauses),
        "xor_network",
        split,
        seed,
    )


def mixed_xor_or_v2(n: int, seed: int, split: str) -> EvalInstance:
    rng = random.Random(seed)
    clauses = xor_clauses((1, 2, 3), 1)
    for _ in range(max(1, n // 2)):
        vs = rng.sample(range(1, n + 1), min(3, n))
        clauses.append(tuple(v if rng.randrange(2) else -v for v in vs))
    clauses = _shuffle_clauses(clauses, rng)
    return EvalInstance(
        f"{split}:mixed_xor_or:n={n}:seed={seed}",
        to_dimacs(n, clauses),
        "mixed_xor_or",
        split,
        seed,
    )


def hidden_xor_among_binaries(n_pairs: int, seed: int, split: str) -> EvalInstance:
    rng = random.Random(seed)
    clauses: list[tuple[int, ...]] = []
    # disjoint binaries occupying 1..2n
    for i in range(n_pairs):
        a = 2 * i + 1
        b = 2 * i + 2
        clauses.append((a, b) if rng.randrange(2) else (a, -b))
    base = 2 * n_pairs
    xor_vars = (base + 1, base + 2, base + 3)
    clauses.extend(xor_clauses(xor_vars, 1))
    clauses = _shuffle_clauses(clauses, rng)
    return EvalInstance(
        f"{split}:hidden_xor:pairs={n_pairs}:seed={seed}",
        to_dimacs(base + 3, clauses),
        "xor3_hidden",
        split,
        seed,
    )


def disjoint_binaries(m: int) -> EvalInstance:
    clauses = [(2 * i + 1, 2 * i + 2) for i in range(m)]
    return EvalInstance(
        f"cal:disjoint_binaries:m={m}",
        to_dimacs(2 * m, clauses),
        "disjoint_binaries",
        "calibration",
        None,
    )
