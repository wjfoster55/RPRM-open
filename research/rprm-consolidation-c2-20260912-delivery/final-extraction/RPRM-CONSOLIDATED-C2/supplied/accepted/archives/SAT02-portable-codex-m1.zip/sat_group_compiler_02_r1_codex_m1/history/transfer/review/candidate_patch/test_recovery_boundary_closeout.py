"""Six narrow review regressions; neither panels nor a whole-solver proof."""
from __future__ import annotations
import copy
import unittest
from sat_group_compiler.compiler import compile_cnf
from sat_group_compiler.protocol import load_protocol, stage_limits
from sat_group_compiler.receipts import check_rewrite_receipt, receipt_payload

class RecoveryBoundaryCloseout(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        limits=dict(stage_limits(load_protocol(), 'smoke', 'W3'))
        limits['max_seconds']=10
        result=compile_cnf('p cnf 2 2\n1 2 0\n-1 -2 0\n', mode='C', limits=limits, variant='W3', retain=[1], use_affine=False)
        cls.base=receipt_payload(result.receipts[0])

    def test_valid_recovery_remains_accepted(self):
        result=check_rewrite_receipt(copy.deepcopy(self.base))
        self.assertTrue(result['ok'])
        self.assertFalse(result['whole_solver_derivation_replayed'])
        self.assertFalse(result['binds_original_factor_ids'])

    def test_closed_form_cannot_overwrite_boundary(self):
        p=copy.deepcopy(self.base)
        p['recovery']={'type':'closed_form','map':{'1':['lit',-1], '2':['lit',-1]}}
        self.assertFalse(check_rewrite_receipt(p)['ok'])

    def test_table_cannot_overwrite_boundary(self):
        p=copy.deepcopy(self.base)
        p['recovery']={'type':'lex_table','rows':[
            {'boundary':{'1':0}, 'internal':{'1':1,'2':0}},
            {'boundary':{'1':1}, 'internal':{'1':0,'2':1}},
        ]}
        self.assertFalse(check_rewrite_receipt(p)['ok'])

    def test_empty_relation_does_not_need_recovery(self):
        p=copy.deepcopy(self.base)
        p.update(input_identities=['U:1','U:-1'], scope=[1], boundary=[], eliminated=[1], group_sat_mask=0, replacement=['F'], recovery={})
        self.assertTrue(check_rewrite_receipt(p)['ok'])

    def test_false_zero_mask_does_not_bypass_recovery(self):
        p=copy.deepcopy(self.base)
        p.update(group_sat_mask=0, recovery={})
        result=check_rewrite_receipt(p)
        self.assertFalse(result['ok'])
        self.assertIn('stored_group_sat_mask_mismatch',result['reasons'])
        self.assertIn('recovery_missing',result['reasons'])

    def test_empty_input_does_not_justify_true_replacement(self):
        p=copy.deepcopy(self.base)
        p.update(input_identities=['U:1','U:-1'], scope=[1], boundary=[], eliminated=[1], group_sat_mask=0, replacement=['T'], recovery={})
        result=check_rewrite_receipt(p)
        self.assertFalse(result['ok'])
        self.assertIn('empty_boundary_false_mismatch',result['reasons'])

if __name__=='__main__':unittest.main()
