"""DIMACS CNF parsing and serialization."""

from __future__ import annotations

from dataclasses import dataclass, field


class DimacsError(ValueError):
    """Malformed DIMACS input."""


@dataclass
class ParsedCNF:
    n_vars: int
    clauses: tuple[tuple[int, ...], ...]
    comments: tuple[str, ...]
    header_clause_count: int | None
    warnings: tuple[str, ...]
    raw_bytes: bytes
    source_name: str = ""


def parse_dimacs(text: str | bytes, source_name: str = "") -> ParsedCNF:
    if isinstance(text, bytes):
        raw = text
        try:
            body = text.decode("utf-8")
        except UnicodeDecodeError as error:
            raise DimacsError("DIMACS is not valid UTF-8") from error
    else:
        body = text
        raw = text.encode("utf-8")

    n_vars: int | None = None
    declared_m: int | None = None
    clauses: list[tuple[int, ...]] = []
    comments: list[str] = []
    warnings: list[str] = []
    current: list[int] = []
    seen_header = False

    lines = body.splitlines()
    for line_no, raw_line in enumerate(lines, start=1):
        line = raw_line.strip()
        if not line:
            continue
        if line.startswith("c") and (len(line) == 1 or line[1].isspace() or line[1] == "\t"):
            comments.append(line)
            continue
        if line[0] in "%":
            break
        if line.startswith("p"):
            parts = line.split()
            if len(parts) < 4 or parts[1].lower() != "cnf":
                raise DimacsError(f"line {line_no}: expected 'p cnf n m'")
            try:
                n_vars = int(parts[2])
                declared_m = int(parts[3])
            except ValueError as error:
                raise DimacsError(f"line {line_no}: non-integer p-line") from error
            if n_vars < 0 or declared_m < 0:
                raise DimacsError(f"line {line_no}: negative header count")
            if seen_header:
                raise DimacsError(f"line {line_no}: duplicate problem line")
            seen_header = True
            continue
        if not seen_header:
            raise DimacsError("clause before p cnf header")
        try:
            tokens = [int(tok) for tok in line.split()]
        except ValueError as error:
            raise DimacsError(f"line {line_no}: non-integer token") from error
        for token in tokens:
            if token == 0:
                clauses.append(tuple(current))
                current = []
            else:
                if n_vars is None:
                    raise DimacsError("literal before header")
                if abs(token) > n_vars:
                    raise DimacsError(
                        f"line {line_no}: literal {token} outside 1..{n_vars}"
                    )
                current.append(token)

    if current:
        raise DimacsError("unterminated last clause (missing 0)")
    if not seen_header:
        raise DimacsError("missing p cnf header")
    assert n_vars is not None
    if declared_m is not None and declared_m != len(clauses):
        warnings.append(
            f"header clause count {declared_m} != actual {len(clauses)}"
        )
    return ParsedCNF(
        n_vars=n_vars,
        clauses=tuple(clauses),
        comments=tuple(comments),
        header_clause_count=declared_m,
        warnings=tuple(warnings),
        raw_bytes=raw,
        source_name=source_name,
    )


def to_dimacs(n_vars: int, clauses: list[tuple[int, ...]] | tuple[tuple[int, ...], ...]) -> str:
    lines = [f"p cnf {n_vars} {len(clauses)}"]
    for clause in clauses:
        lines.append(" ".join(str(lit) for lit in clause) + " 0")
    return "\n".join(lines) + "\n"


def assignment_from_bits(n_vars: int, mask: int) -> dict[int, int]:
    return {var: (mask >> (var - 1)) & 1 for var in range(1, n_vars + 1)}
