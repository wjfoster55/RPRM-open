"""Lazy incidence-driven connected-group generation."""

from __future__ import annotations

from collections import defaultdict
from itertools import combinations
from typing import Callable, Iterator

from .ir import Factor, Kind


def live_factors(factors: list[Factor]) -> list[Factor]:
    return [f for f in factors if f.kind is not Kind.TRUE]


def factor_vars(factor: Factor) -> set[int]:
    return set(factor.vars())


def connected(group: list[Factor]) -> bool:
    n = len(group)
    if n <= 1:
        return True
    adj = {i: set() for i in range(n)}
    for i in range(n):
        for j in range(i + 1, n):
            if factor_vars(group[i]) & factor_vars(group[j]):
                adj[i].add(j)
                adj[j].add(i)
    seen = {0}
    stack = [0]
    while stack:
        u = stack.pop()
        for v in adj[u]:
            if v not in seen:
                seen.add(v)
                stack.append(v)
    return len(seen) == n


def incidence_index(factors: list[Factor]) -> dict[int, list[Factor]]:
    index: dict[int, list[Factor]] = defaultdict(list)
    for factor in live_factors(factors):
        for var in factor.vars():
            index[var].append(factor)
    return index


def support_buckets(factors: list[Factor], max_scope: int) -> dict[frozenset[int], list[Factor]]:
    buckets: dict[frozenset[int], list[Factor]] = defaultdict(list)
    for factor in live_factors(factors):
        vs = frozenset(factor.vars())
        if 1 <= len(vs) <= max_scope:
            buckets[vs].append(factor)
    return buckets


def neighbor_map(
    factors: list[Factor],
    budget: GroupBudget | None = None,
) -> dict[int, set[int]]:
    """Build undirected incidence adjacency.

    Pair construction is charged to ``budget.meter['adjacency_pairs']`` when a
    budget is supplied. If the budget is already exhausted, this returns an
    empty map and does not scan pairs. When generation is allowed to start, the
    full live adjacency is still built; that remaining preprocessing is not a
    complete-work claim.
    """
    if budget is not None and not budget.ok():
        return {}
    index = incidence_index(factors)
    by_id = {f.id: f for f in live_factors(factors)}
    neigh: dict[int, set[int]] = {fid: set() for fid in by_id}
    for _var, incident in index.items():
        if budget is not None and not budget.ok():
            return neigh
        ids = [f.id for f in incident]
        for i, a in enumerate(ids):
            for b in ids[i + 1 :]:
                if budget is not None:
                    if not budget.ok():
                        return neigh
                    budget.meter["adjacency_pairs"] = budget.meter.get("adjacency_pairs", 0) + 1
                neigh[a].add(b)
                neigh[b].add(a)
    return neigh


class GroupBudget:
    def __init__(self, check: Callable[[], bool], meter: dict[str, int]):
        self.check = check
        self.meter = meter
        self.exhausted = False

    def ok(self) -> bool:
        if self.exhausted:
            return False
        if not self.check():
            self.exhausted = True
            return False
        return True


def connected_subsets_oracle(
    factors: list[Factor],
    max_factors: int,
    max_scope: int,
    min_factors: int = 2,
) -> set[frozenset[int]]:
    """Exhaustive connected-subset enumerator for small graphs. Not the production generator."""
    live = live_factors(factors)
    found: set[frozenset[int]] = set()
    if max_factors < min_factors or not live:
        return found
    by_id = sorted(live, key=lambda f: f.id)
    for k in range(min_factors, max_factors + 1):
        for combo in combinations(by_id, k):
            group = list(combo)
            if not connected(group):
                continue
            scope: set[int] = set()
            for factor in group:
                scope.update(factor.vars())
            if len(scope) > max_scope:
                continue
            found.add(frozenset(f.id for f in group))
    return found


def iter_connected_groups(
    factors: list[Factor],
    max_factors: int,
    max_scope: int,
    budget: GroupBudget,
    min_factors: int = 2,
) -> Iterator[tuple[Factor, ...]]:
    """Yield each connected factor subset of size in [min_factors, max_factors] at most once.

    Growth uses the variable-incidence graph. Each connected set is generated
    from its minimum-id member by adding unused neighbors whose ids are strictly
    larger than that start id (not larger than the last appended id). That
    distinction is required: the path 1—3—2 is connected, but adding only
    ``nid > current[-1]`` silently omits the triple when the middle factor has
    the largest id. Disconnected tuples are never materialised. Duplicate
    addition orders are collapsed by factor-id set. Resource checks run during
    generation, including before adjacency construction.
    """
    live = live_factors(factors)
    if max_factors < min_factors or not live:
        return
    if not budget.ok():
        return
    live_sorted = sorted(live, key=lambda f: f.id)
    id_to_factor = {f.id: f for f in live_sorted}
    neigh = neighbor_map(live_sorted, budget=budget)
    if not budget.ok():
        return

    def scope_of(ids: tuple[int, ...]) -> set[int]:
        out: set[int] = set()
        for fid in ids:
            out.update(id_to_factor[fid].vars())
        return out

    emitted: set[frozenset[int]] = set()
    for start in live_sorted:
        if not budget.ok():
            return
        budget.meter["starts_considered"] = budget.meter.get("starts_considered", 0) + 1
        start_id = start.id
        stack: list[tuple[int, ...]] = [(start_id,)]
        while stack:
            if not budget.ok():
                return
            current = stack.pop()
            budget.meter["tuples_proposed"] = budget.meter.get("tuples_proposed", 0) + 1
            cur_scope = scope_of(current)
            if len(cur_scope) > max_scope:
                budget.meter["discarded_scope"] = budget.meter.get("discarded_scope", 0) + 1
                continue
            if len(current) >= min_factors:
                ids = frozenset(current)
                if ids not in emitted:
                    emitted.add(ids)
                    budget.meter["groups_emitted"] = budget.meter.get("groups_emitted", 0) + 1
                    yield tuple(id_to_factor[fid] for fid in sorted(current))
            if len(current) >= max_factors:
                continue
            adjacent: set[int] = set()
            for fid in current:
                adjacent |= neigh.get(fid, set())
            used = set(current)
            for nid in sorted(adjacent):
                if not budget.ok():
                    return
                if nid <= start_id or nid in used:
                    continue
                grown = current + (nid,)
                grown_scope = scope_of(grown)
                if len(grown_scope) > max_scope:
                    budget.meter["discarded_scope"] = budget.meter.get("discarded_scope", 0) + 1
                    continue
                stack.append(grown)


def iter_same_support_groups(
    factors: list[Factor],
    max_factors: int,
    max_scope: int,
    budget: GroupBudget,
    min_factors: int = 2,
) -> Iterator[tuple[Factor, ...]]:
    """Public support index: complete small same-scope factor sets, before generic search."""
    buckets = support_buckets(factors, max_scope)
    # Exact-support groups, then factors whose support is contained in a small union of incident vars.
    emitted: set[frozenset[int]] = set()
    for support, group in sorted(buckets.items(), key=lambda kv: (len(kv[0]), tuple(sorted(kv[0])))):
        if not budget.ok():
            return
        budget.meter["index_buckets"] = budget.meter.get("index_buckets", 0) + 1
        if min_factors <= len(group) <= max_factors and 1 <= len(support) <= max_scope:
            ids = frozenset(f.id for f in group)
            if ids not in emitted and connected(group):
                emitted.add(ids)
                budget.meter["index_hits"] = budget.meter.get("index_hits", 0) + 1
                budget.meter["groups_emitted"] = budget.meter.get("groups_emitted", 0) + 1
                yield tuple(sorted(group, key=lambda f: f.id))

    # Incident-closure: for each variable, take all incident factors whose combined support is small.
    index = incidence_index(factors)
    for var in sorted(index):
        if not budget.ok():
            return
        incident = index[var]
        support: set[int] = set()
        for factor in incident:
            support |= factor_vars(factor)
        if not (1 <= len(support) <= max_scope):
            continue
        on_scope = [
            f
            for f in live_factors(factors)
            if factor_vars(f) and factor_vars(f) <= support
        ]
        if not (min_factors <= len(on_scope) <= max_factors):
            continue
        ids = frozenset(f.id for f in on_scope)
        if ids in emitted:
            continue
        if not connected(on_scope):
            continue
        emitted.add(ids)
        budget.meter["index_hits"] = budget.meter.get("index_hits", 0) + 1
        budget.meter["groups_emitted"] = budget.meter.get("groups_emitted", 0) + 1
        yield tuple(sorted(on_scope, key=lambda f: f.id))
