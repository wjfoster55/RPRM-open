"""Summarize executed v2 panels for REPORT.md. Evaluator-only."""
from __future__ import annotations

import json
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RES = ROOT / "results"


def load(name: str):
    return json.loads((RES / name).read_text(encoding="utf-8"))


def has_p(row) -> bool:
    blob = list(row.get("residual") or []) + list(row.get("recognized") or [])
    return any(str(s).startswith("P:") for s in blob)


def main() -> None:
    s1 = load("stage1.json")
    print("STAGE1 XOR / mixed")
    for r in s1:
        fam = r["family"]
        if fam in {"xor3", "xor3_near_miss", "xor3_embedded", "xor3_hidden", "xor_network", "mixed_xor_or"} or "xor" in r["instance_id"]:
            print(
                f"{r['variant']:5} {r['instance_id'][:58]:58} {r['candidate_status']:15} "
                f"P={has_p(r)} rec={r['n_receipts']} cand={r['meter']['candidates_examined']} "
                f"idx={r['meter']['index_hits']} T={r['meter']['temp_tables_created']} "
                f"wall={r['meter']['wall_s']:.4f} skipped={r['meter']['skipped']}"
            )
    print("\nSTAGE1 cards of interest")
    for iid in [
        "calibration:xor3:p=1:vars=1,2,3",
        "stage1:xor3_embedded:n=7:seed=23",
        "stage1:xor_network:blocks=2:seed=23",
        "stage1:hidden_xor:pairs=8:seed=23",
        "stage1:mixed_xor_or:n=6:seed=23",
        "stage1:xor3_near_miss_delete:0",
        "stage1:signed_graph:n=8:m=10:seed=23:u=0",
        "stage1:rand3:n=7:m=14:seed=23",
    ]:
        print("---", iid)
        for r in s1:
            if r["instance_id"] == iid:
                rec0 = r["receipts"][0] if r["receipts"] else {}
                print(
                    " ",
                    r["variant"],
                    r["candidate_status"],
                    "residual",
                    r["residual"][:4],
                    "repl",
                    rec0.get("replacement"),
                    "promise",
                    rec0.get("promise"),
                    "spec",
                    rec0.get("speculative"),
                    "proof_bytes",
                    r["meter"]["proof_bytes"],
                    "init",
                    r["meter"]["initial_ir_bytes"],
                    "peak",
                    r["meter"]["peak_ir_bytes"],
                )

    for split in ("smoke", "stress", "development", "evaluation"):
        rows = load(f"{split}.json")
        print("\n", split, "n", len(rows), "unsound", sum(r.get("sound") is False for r in rows))
        by = {}
        for r in rows:
            k = r.get("variant") or r["mode"]
            by.setdefault(k, Counter())[r["candidate_status"]] += 1
        print(by)


if __name__ == "__main__":
    main()
