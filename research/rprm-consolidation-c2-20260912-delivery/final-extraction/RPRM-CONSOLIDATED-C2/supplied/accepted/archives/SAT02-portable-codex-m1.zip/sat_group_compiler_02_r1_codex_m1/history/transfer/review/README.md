# SAT02-R1 closeout review

Read `REVIEW.md`, then `CLOSEOUT_MESSAGE.md`. The uploaded R1 implementation was not changed. `candidate_patch/` is an optional, narrowly tested local-verifier correction, not an integrated owner release.

## Evidence

`results/test_replays.json` and the associated logs: actual original 57-case and R1 73-case runs.

`results/independent/`: submitted-R1 graph, XOR, native, timing, fingerprint and receipt diagnostics. The initial harness's final zero-rejection assertion failed because of the 50 empty-relation false rejects; all preceding results remain valid and preserved.

`results/candidate/`: an unpatched duplicate diagnostic after a patch-preparation precondition failure. This is **not** evidence for the patch.

`results/candidate_02/`: actual patched candidate diagnostics. `results/patch_replays.json`: the 73 existing tests and six focused before/after regressions. `results/REVIEWER_RUN_NOTE.md` explains the history.

`results/integrity.json`: archive identities, the selective owner-hash checks and full reviewer inventory of the 52 delivered R1 payload files. `source_snapshots/` contains the reviewed owner prose and relevant unchanged source files. The complete original and successor archives are separate user attachments, not duplicated inside this review.

## Reproduce the review

Extract the original `sat_group_compiler_02.zip`, successor `sat_group_compiler_02_r1.zip`, and prior `SAT02-REVIEW-01.zip` into separate directories. Use absolute paths for placeholders below:

```text
python -B tools/review_successor.py --experiment PATH_TO_R1_ROOT --original PATH_TO_ORIGINAL_ROOT --prior-review PATH_TO_PRIOR_REVIEW_ROOT --output NEW_OUTPUT_DIRECTORY
```

The review reuses the prior review's semantic interpreter and adds a boundary-output-scope check. It does not rerun benchmark panels. Its graph and native-relation oracles use direct separate calculations. No package installation is needed for these checks.

Run the owner's suite from the extracted R1 root:

```text
python -B run.py test
```

For the optional patch, use `candidate_patch/apply_to_fresh_copy.py --source PATH_TO_R1_ROOT --destination NEW_PATH`. This rejects a wrong source hash or an existing destination. It does not run tests or update the owner's release manifest. To run the six new tests without installing anything, point PYTHONPATH only to that fresh candidate and run `candidate_patch/test_recovery_boundary_closeout.py`. Also run the unchanged 73-case suite from the candidate root. Any official integration must record a new candidate/build identity and preserve historical evidence.

## Scope

No original panels or missing seeds scored. No speed ranking, whole-solver proof, broad parser-hardening claim, project restart or new experiment. `MANIFEST.json` inventories this review package only and excludes itself.
