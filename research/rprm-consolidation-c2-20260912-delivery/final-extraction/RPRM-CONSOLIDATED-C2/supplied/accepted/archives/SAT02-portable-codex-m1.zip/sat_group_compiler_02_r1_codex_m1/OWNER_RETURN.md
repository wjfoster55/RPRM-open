# SAT02-R1 owner return

**12 September 2026. One owner closeout. Not Task03. No commit/push. No other-lane dispatch.**

## 1. Review package

Copied from `c:\Users\bkbee\Downloads\SAT02-REVIEW-01.zip` (SHA-256 `d37a6080f5bcabe2b43f78f48408969b89bbee12462b167f8c054a72cc27a67e`) to `C:\github\rprm-pnp\experiments\sat02_review_01_package\`. The submitted zip was not modified.

Owner/coordinator card: `SAT02_OWNER_REVIEW_RETURN.md` (`16dd0dc9d9ce9b3a27ccea9bad46481e71973ff54208ed6bebba3fdf722c4ea1`).

Also present: `README.md` (start here), `REVIEW.md`, `LANE_STATUS_UPDATE.md`, `RESULT_STATUS.json`, `MANIFEST.json`, `inputs/sat_group_compiler_02.zip`, `scripts/review_sat02.py`, `scripts/review_budget_and_fingerprint.py`, `results/independent/*`, `source_snapshots/`.

Inner SAT02 archive SHA-256 `a32587d9657ce87366632c8bd93c25bff757b5ac575bda8dfde76602bd26b9ea` (matches the review).

Verified live locators (do not assume):
- Assignment `CURSOR_TASK_02.md` SHA-256 `6885f57c66f94eb100e939b23ce1f280f517b036c674c642ec938e0d52bbd448`
- Original `REPORT.md` SHA-256 `9df00f88d147ec93ea4fa189695891bb61e63360e0573d3c4609fd842995a936`
- Protocol id `sat_group_compiler_02`; protocol SHA-256 `2d94c1895d2c5a61b82c2d3e7eb7a45e1f5acc42be633a7f83a1d88b1ea29bb9`

## 2. Changed versus recorded as limits

**Changed in successor** `experiments/sat_group_compiler_02_r1/` (not the original completed result):

- Connected-group generator: complete deduplicated connected subsets under declared caps; grow by unused neighbors with id > start id, not `nid > current[-1]`. Compared to a small exhaustive oracle. Exhausted budgets no longer build adjacency.
- Receipt checker: partition, closed-form recovery, complete lex-table coverage. Failed checks gate certification. Grade is `local_relation_checked`, not whole-solver derivation.
- `wall_s` includes receipt checks. UNSAT `checked_derivation` is downgraded to `unsat_local_or_algebra_not_whole_chain_replay`.
- Source fingerprint excludes `versions.json`.
- Native overlap wording and 147/93 counts. Seed coverage recorded as 6 run / 4 NOT_RUN.

**Recorded as limits, not enforced as a new complete budget:**

- `max_table_rows` still charges primary table rows only; template/projection work is counted and excluded from that cap.
- Live adjacency may still be built if generation is allowed to start.
- W3-T follows selected top path `kept[0]`; not a demonstrated beam search.
- Local checker does not bind original live factor IDs.
- No pre-run 47-file inventory exists for the original freeze.

**Unchanged:** original SAT02 source (except overlay `REVIEW_R1_STATUS.md`), original `results/*`, submitted zip, protocol bytes/hash. Missing seeds were not run.

## 3. Specimens preserved

- Protected XOR: W3 misses complete parity in one 2–3 group; W4 recovers `P:1,2,3=1` by enlarging the window; W3-T succeeds without enlarging via temporary `TBL:1,2,3:97` (structural cost 15→18) then 23→6. Not a universal SAT shortcut.
- Three-color: 21/27 joint boundary; pair projections all 9; two-factor conjunction 147/243 vs union atom 93/243; separator `(0,0,1,1,2)`.

Reviewer’s independent checks are preserved as review evidence and were not overwritten: 57/57 original suite; 466 rows; 239/239 SAT witnesses; 323/323 decisive vs exhaustive; 982/982 local receipts; 72/72 protected-XOR; three-color joint-boundary + pairwise counterexample.

Descriptive panel tallies remain descriptive, not a ranking: W3 15/22 & 15/22; W4 17/22 & 16/22; W3-T 18/22 & 18/22; W4-I 17/22 & 16/22.

## 4. Claim ledger

See `CLAIM_LEDGER.md`.

**Accepted:** exact local transformation specimens; saved SAT/UNSAT and SAT witnesses within the reconstructed-generator review scope; local saved recoveries as mathematics (not as a fully replayed solver proof).

**Partial:** protocol coverage (6 of 10 declared seeds).

**Narrowed/rejected:** completed ten-seed benchmark; independently certified end-to-end compiler; complete total-work / end-to-end-time / freeze-digest claims as advertised; “cannot combine overlapping at-most-two-color factors compactly”; P=NP.

## 5. Seed status

6 run / 4 NOT_RUN:

- Run: development 23, 29, 31; evaluation 20011, 20021, 20047
- NOT_RUN: development 37, 41; evaluation 20063, 20089

Ten-seed declaration preserved. File: `SEED_STATUS.json`.

## 6. Named defects

| Defect | Disposition |
| --- | --- |
| Group-ID miss of connected triple 1—3—2 | **Repaired** in successor; 6/6 ID orders vs oracle |
| Receipt checker false accepts | **Repaired** as local checker; certification gated; not a whole-chain proof |
| Table-row cap / timer / fingerprint | Cap **explicitly bounded**; timer **repaired**; fingerprint self-write **repaired** in successor. Original freeze digest still cannot certify the stronger reproducibility claim. |

## 7. Tests

- Original SAT02 tree: `python run.py test` → **57/57 OK** (0.572s). Source other than the overlay was not edited.
- Successor: `python run.py test` → **73/73 OK** (0.741s), including 16 SAT02-R1 regressions.

No panels, freeze, or omitted-seed scoring.

## 8. OPEN, then stop

OPEN: omitted seeds remain NOT_RUN; original dispatch bytes unauthenticated; original Windows/PySAT/NariZoo panels not reproduced; no pre-run 47-file inventory; whole-chain UNSAT proof not independently replayed; complete work budget not claimed; next affordable operation on the retained two-color pair is unnamed; no Task03.

**Stop.** SAT02-R1 reconciliation is complete. C1, Lind–Reichardt, AD 14/16 stay closed. Fluid / Yang–Mills / C1 were not dispatched.

## 9. Paths

| Path | Role |
| --- | --- |
| `C:\github\rprm-pnp\experiments\sat_group_compiler_02\` | Frozen original completed return |
| `C:\github\rprm-pnp\experiments\sat_group_compiler_02\REVIEW_R1_STATUS.md` | Status overlay only |
| `C:\github\rprm-pnp\experiments\sat_group_compiler_02_r1\` | Successor repair + regressions |
| `C:\github\rprm-pnp\experiments\sat02_review_01_package\SAT02-REVIEW-01\` | Unchanged review copy |

Hashes: `HASHES.json`.
