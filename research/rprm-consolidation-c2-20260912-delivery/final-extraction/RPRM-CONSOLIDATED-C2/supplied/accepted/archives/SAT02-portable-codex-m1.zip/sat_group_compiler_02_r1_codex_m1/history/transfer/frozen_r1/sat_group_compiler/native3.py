"""Declared native {0,1,2} carrier. Distinct from Boolean CNF discovery."""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from itertools import combinations, permutations, product
from typing import Any

COLORS = (0, 1, 2)


def uses_at_most_2_colors(values: tuple[int, ...]) -> bool:
    return len(set(values)) <= 2


def missing_color(values: tuple[int, ...]) -> int | None:
    used = set(values)
    for color in COLORS:
        if color not in used:
            return color
    return None


def recover_center(boundary: tuple[int, ...]) -> int | None:
    return missing_color(boundary)


def eval_at_most_2(assignment: dict[str, int], nodes: tuple[str, ...]) -> bool:
    return uses_at_most_2_colors(tuple(assignment[n] for n in nodes))


def verify_k3_rule() -> dict[str, Any]:
    accepted = []
    for triple in product(COLORS, repeat=3):
        extendable = any(all(x != y for y in triple) for x in COLORS)
        if extendable:
            accepted.append(triple)
    pair_sizes = [len({(b[i], b[j]) for b in accepted}) for i, j in combinations(range(3), 2)]
    relation_matches = all((b in accepted) == (len(set(b)) <= 2) for b in product(COLORS, repeat=3))
    unsafe_012 = all(
        (0, 1, 2)[i : i + 1] and ((0, 1, 2)[i], (0, 1, 2)[j]) in {(r[i], r[j]) for r in accepted}
        for i, j in combinations(range(3), 2)
    )
    # clearer:
    abc = (0, 1, 2)
    unsafe_pair_closure_accepts_012 = all(
        (abc[i], abc[j]) in {(r[i], r[j]) for r in accepted} for i, j in combinations(range(3), 2)
    )
    return {
        "all_triples": 27,
        "extendable_triples": len(accepted),
        "pair_projection_sizes": pair_sizes,
        "relation_matches": relation_matches,
        "unsafe_pair_closure_accepts_012": unsafe_pair_closure_accepts_012,
        "pair_replacement_unsound": True,
        "construction": "symbolic_exists_missing_color",
        "enumerated_only_as_verification_of_k3": True,
    }


def compose_with_triangle() -> dict[str, Any]:
    """USES_AT_MOST_2(A,B,C) plus A!=B, B!=C, C!=A is UNSAT; pair-only ablation is SAT."""
    exact_sat = []
    unsafe_sat = []
    for a, b, c in product(COLORS, repeat=3):
        triangle = a != b and b != c and c != a
        if not triangle:
            continue
        if uses_at_most_2_colors((a, b, c)):
            exact_sat.append((a, b, c))
        # unsafe: each pair projection of the star is full, so triangle alone remains
        unsafe_sat.append((a, b, c))
    return {
        "exact_plus_triangle_sat_count": len(exact_sat),
        "exact_plus_triangle_unsat": len(exact_sat) == 0,
        "unsafe_pair_plus_triangle_sat_count": len(unsafe_sat),
        "unsafe_admits_all_distinct": (0, 1, 2) in unsafe_sat,
        "ablation_kept_out_of_engine": True,
    }


def side_condition_center_not_internal(extra_edge: bool) -> dict[str, Any]:
    """If X has an outside incidence it cannot be dropped under this contract.

    This is a flag helper, not a production elimination test on an altered graph.
    """
    return {
        "center_has_outside_incidence": extra_edge,
        "may_eliminate_center": not extra_edge,
        "reason": "outside incidence means X is not strictly internal",
        "scope": "flag_helper_not_production_elimination_with_altered_graph",
    }


def onehot_var(node_index: int, color: int) -> int:
    return 3 * node_index + color + 1


def encode_star_onehot(nodes: tuple[str, ...], edges: list[tuple[str, str]]) -> tuple[int, list[tuple[int, ...]]]:
    index = {name: i for i, name in enumerate(nodes)}
    clauses: list[tuple[int, ...]] = []
    for node in nodes:
        i = index[node]
        clauses.append(tuple(onehot_var(i, c) for c in COLORS))
        for c1, c2 in combinations(COLORS, 2):
            clauses.append((-onehot_var(i, c1), -onehot_var(i, c2)))
    for u, v in edges:
        iu, iv = index[u], index[v]
        for color in COLORS:
            clauses.append((-onehot_var(iu, color), -onehot_var(iv, color)))
    return 3 * len(nodes), clauses


def decode_onehot(nodes: tuple[str, ...], assignment: dict[int, int]) -> dict[str, int] | None:
    coloring: dict[str, int] = {}
    for i, node in enumerate(nodes):
        chosen = [c for c in COLORS if assignment.get(onehot_var(i, c), 0) == 1]
        if len(chosen) != 1:
            return None
        coloring[node] = chosen[0]
    return coloring


def encode_coloring(nodes: tuple[str, ...], coloring: dict[str, int]) -> dict[int, int]:
    asg: dict[int, int] = {}
    for i, node in enumerate(nodes):
        for c in COLORS:
            asg[onehot_var(i, c)] = 1 if coloring[node] == c else 0
    return asg


def dimacs_of(n_vars: int, clauses: list[tuple[int, ...]]) -> str:
    from .dimacs import to_dimacs

    return to_dimacs(n_vars, clauses)


def compare_to_fixture(path_text: str, nodes: tuple[str, ...], edges: list[tuple[str, str]]) -> dict[str, Any]:
    from .dimacs import parse_dimacs

    n, clauses = encode_star_onehot(nodes, edges)
    generated = set(tuple(sorted(cl)) for cl in clauses)
    parsed = parse_dimacs(path_text)
    fixture = set(tuple(sorted(cl)) for cl in parsed.clauses)
    return {
        "n_vars": n,
        "generated_clauses": len(clauses),
        "fixture_clauses": len(parsed.clauses),
        "clause_set_equal": generated == fixture,
        "boolean_vars": n,
        "outside_old_six_var_recognizer": n > 6,
        "label": "cnf_encoder_decoder_equivalence",
    }


@dataclass
class NativeFactor:
    kind: str
    nodes: tuple[str, ...]
    note: str = ""

    def arity(self) -> int:
        return len(self.nodes)

    def serialized(self) -> str:
        return f"{self.kind}:{','.join(self.nodes)}"

    def serialized_bytes(self) -> int:
        return len(self.serialized().encode("utf-8"))

    def holds(self, asg: dict[str, int]) -> bool:
        if self.kind == "DIFF":
            a, b = self.nodes
            return asg[a] != asg[b]
        if self.kind == "USES_AT_MOST_2_COLORS":
            return uses_at_most_2_colors(tuple(asg[n] for n in self.nodes))
        if self.kind == "FALSE":
            return False
        if self.kind == "TRUE":
            return True
        raise AssertionError(self.kind)


def project_star_center(neighbors: tuple[str, ...]) -> dict[str, Any]:
    """Symbolic rule: do not enumerate 3^k to construct it."""
    return {
        "relation": "USES_AT_MOST_2_COLORS",
        "neighbors": list(neighbors),
        "arity": len(neighbors),
        "enumerated_assignments_to_construct": 0,
        "eval_work": {"distinct_color_scan": len(neighbors), "domain": 3},
        "recovery": "choose_smallest_missing_color",
        "original_star_factors": len(neighbors),
        "table_rows_if_materialized": 3 ** len(neighbors),
        "beats_table_not_automatically_beats_star": True,
    }


def sizes_for_k(k: int) -> dict[str, Any]:
    names = tuple(f"N{i}" for i in range(k))
    star = [NativeFactor("DIFF", ("X", n)) for n in names]
    projected = NativeFactor("USES_AT_MOST_2_COLORS", names)
    table_bytes = (3 ** k) * k
    return {
        "k": k,
        "original_star_serialized": sum(f.serialized_bytes() for f in star),
        "projected_serialized": projected.serialized_bytes(),
        "naive_table_bytes_estimate": table_bytes,
        "projected_arity": k,
        "constructed_without_3k_enum": True,
    }


def overlapping_conjunction_versus_union_atom() -> dict[str, Any]:
    """Two overlapping at-most-two-color factors are already an exact compact conjunction.

    Forcing a single union atom `USES_AT_MOST_2_COLORS(A,B,C,D,E)` is the wrong
    relation: it rejects assignments the pair still admits, e.g. (0,0,1,1,2).
    """
    names = ("A", "B", "C", "D", "E")
    conjunction = 0
    union_atom = 0
    separating: tuple[int, ...] | None = None
    for asg in product(COLORS, repeat=5):
        abc = (asg[0], asg[1], asg[2])
        cde = (asg[2], asg[3], asg[4])
        two = uses_at_most_2_colors(abc) and uses_at_most_2_colors(cde)
        one = uses_at_most_2_colors(asg)
        if two:
            conjunction += 1
        if one:
            union_atom += 1
        if two and not one and separating is None:
            separating = asg
    return {
        "boundary_assignments": 3 ** 5,
        "two_factor_conjunction_accepted": conjunction,
        "single_union_atom_accepted": union_atom,
        "separating_example": list(separating) if separating else None,
        "note": (
            "No supported compact named join is true in single-atom vocabulary. "
            "It is not a general compact-composition impossibility. The retained pair "
            "is already an exact compact description."
        ),
    }


def overlapping_stars() -> dict[str, Any]:
    nodes = ("A", "B", "C", "D", "E", "X", "Y")
    edges = [("X", "A"), ("X", "B"), ("X", "C"), ("Y", "C"), ("Y", "D"), ("Y", "E")]
    retain = {"A", "B", "C", "D", "E"}

    def degree(node: str) -> int:
        return sum(1 for u, v in edges if node in (u, v))

    legal_centers = ["X", "Y"]
    orders = {
        "fixed_id": sorted(legal_centers),
        "min_degree": sorted(legal_centers, key=lambda n: (degree(n), n)),
        "representation_aware": sorted(legal_centers, key=lambda n: (0, n)),
    }
    order_work = {
        "fixed_id": {"comparisons": 1, "note": "lexicographic node names"},
        "min_degree": {"degree_scans": len(nodes), "note": "computed from edge list"},
        "representation_aware": {
            "note": "prefer a center whose projection is the supported USES_AT_MOST_2_COLORS atom, then name",
            "supported_projection": "USES_AT_MOST_2_COLORS",
        },
    }
    results = {}
    for name, order in orders.items():
        factors: list[NativeFactor] = [NativeFactor("DIFF", e) for e in edges]
        steps = []
        for center in order:
            neighbors = tuple(sorted({u if v == center else v for u, v in edges if center in (u, v)}))
            if any(n == center for n in retain):
                steps.append({"center": center, "skipped": "retained"})
                continue
            # drop star edges of center, add joint relation
            factors = [f for f in factors if center not in f.nodes]
            factors.append(NativeFactor("USES_AT_MOST_2_COLORS", neighbors))
            steps.append(
                {
                    "eliminated": center,
                    "retained": list(neighbors),
                    "replacement": factors[-1].serialized(),
                    "recovery": "missing_color",
                }
            )
        kinds = [f.kind for f in factors]
        compact_merge = None
        atmost = [f for f in factors if f.kind == "USES_AT_MOST_2_COLORS"]
        if len(atmost) >= 2:
            union = tuple(sorted(set().union(*(f.nodes for f in atmost))))
            compact_merge = {
                "attempted": True,
                "union_arity": len(union),
                "supported_named_relation_on_union": False,
                "reason": (
                    "no supported single named atom on the union; "
                    "the two-factor conjunction is already an exact compact description"
                ),
                "kept_as": [f.serialized() for f in atmost],
                "stopped": "no_supported_single_named_atom",
                "next_question": (
                    "which operation the retained pair cannot support affordably "
                    "(further elimination, nonemptiness, constraint update, witness reconstruction)"
                ),
            }
        results[name] = {
            "order": order,
            "steps": steps,
            "residual": [f.serialized() for f in factors],
            "kinds": kinds,
            "compact_merge": compact_merge,
            "same_final_question": "satisfying colorings of retained A,B,C,D,E under the projected factors",
        }
    # Independent color rename inside blocks without a mapping is illegal at the join.
    global_perm = {0: 1, 1: 2, 2: 0}
    independent_rename_without_map = {
        "global_permutation_valid_control": True,
        "independent_block_rename_requires_compatible_mapping": True,
        "example": "permuting X-star colors independently of Y-star colors breaks equality of shared C",
    }
    return {
        "nodes": list(nodes),
        "edges": edges,
        "retain": sorted(retain),
        "orders": results,
        "order_work": order_work,
        "orders_all_chose": [results[name]["order"] for name in orders],
        "orders_establish_policy_superiority": False,
        "conjunction_versus_union": overlapping_conjunction_versus_union_atom(),
        "global_perm_example": global_perm,
        "rename_policy": independent_rename_without_map,
    }


def run_stage2(star_cnf: str, star_plus_triangle_cnf: str) -> dict[str, Any]:
    nodes = ("A", "B", "C", "X")
    edges = [("X", "A"), ("X", "B"), ("X", "C")]
    k3 = verify_k3_rule()
    triangle = compose_with_triangle()
    fixture = compare_to_fixture(star_cnf, nodes, edges)
    n, clauses = encode_star_onehot(nodes, edges)
    # decoder round-trip on all 21 extendable colorings
    recovered = 0
    failed = 0
    for a, b, c in product(COLORS, repeat=3):
        if not uses_at_most_2_colors((a, b, c)):
            continue
        x = recover_center((a, b, c))
        coloring = {"A": a, "B": b, "C": c, "X": x}
        asg = encode_coloring(nodes, coloring)
        from .ir import cnf_holds

        if not cnf_holds(tuple(clauses), asg):
            failed += 1
            continue
        decoded = decode_onehot(nodes, asg)
        if decoded != coloring:
            failed += 1
            continue
        recovered += 1
    k_scale = [sizes_for_k(k) for k in (3, 4, 5, 6)]
    overlap = overlapping_stars()
    plus_tri = compare_to_fixture(star_plus_triangle_cnf, nodes, edges + [("A", "B"), ("B", "C"), ("C", "A")])
    return {
        "label_native_typed_relation": "executed",
        "label_cnf_encoder_decoder": "executed",
        "label_raw_cnf_discovery": "SKIPPED_not_implemented",
        "k3": k3,
        "triangle_composition": triangle,
        "encoder_vs_star_fixture": fixture,
        "encoder_vs_star_plus_triangle_fixture": plus_tri,
        "decoder_round_trip_extendable": {"ok": recovered, "failed": failed, "expected": 21},
        "side_condition_internal": side_condition_center_not_internal(False),
        "side_condition_outside": side_condition_center_not_internal(True),
        "k_scale": k_scale,
        "overlapping_stars": overlap,
        "claim_grade": {
            "k3_rule_on_27": "tested",
            "symbolic_k_star_construction": "tested",
            "general_coloring_algorithm": "not_claimed",
            "overlapping_pair_is_exact_compact_conjunction": "tested",
            "single_union_atom_is_wrong_relation": "tested",
        },
    }
