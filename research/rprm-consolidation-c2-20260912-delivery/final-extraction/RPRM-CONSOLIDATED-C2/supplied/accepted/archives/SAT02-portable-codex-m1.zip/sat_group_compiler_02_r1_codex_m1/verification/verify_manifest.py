"""Verify M1 payload bytes, permitted changes, and frozen source identities."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def main():
    manifest = json.loads((ROOT / 'M1_MANIFEST.json').read_text(encoding='utf-8'))
    names = [r['path'] for r in manifest['files']]
    assert len(names) == len(set(names)), 'Duplicate manifest entry'
    actual = {p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*') if p.is_file()}
    assert actual == set(names) | {'M1_MANIFEST.json'}, 'Payload file set differs'
    for row in manifest['files']:
        p = (ROOT / row['path']).resolve()
        assert p.is_relative_to(ROOT) and not p.is_symlink()
        assert p.stat().st_size == row['bytes'] and sha(p) == row['sha256'], row['path']
    original = ROOT / 'history/transfer/frozen_r1'
    changed = []
    unchanged = []
    for p in sorted(original.rglob('*')):
        if not p.is_file():
            continue
        rel = p.relative_to(original).as_posix()
        q = ROOT / rel
        assert q.is_file(), 'Original R1 file missing: ' + rel
        (changed if p.read_bytes() != q.read_bytes() else unchanged).append(rel)
    assert set(changed) == {'sat_group_compiler/receipts.py', 'README.md', 'CLAIM_LEDGER.md'}, changed
    for name in ['PROTOCOL.md', 'PROTOCOL_V2.md', 'protocol_v2.json', 'SEED_STATUS.json', 'HASHES.json', 'OWNER_RETURN.md']:
        assert name in unchanged, name
    assert (ROOT / 'tests/test_recovery_boundary_closeout.py').read_bytes() == (ROOT / 'history/transfer/review/candidate_patch/test_recovery_boundary_closeout.py').read_bytes()
    integration = json.loads((ROOT / 'M1_INTEGRATION.json').read_text(encoding='utf-8'))
    assert sha(ROOT / 'sat_group_compiler/receipts.py') == integration['integrated_checker_sha256']
    print(json.dumps({'status': 'PASS', 'scope': 'byte_integrity_and_change_boundary_only',
        'payload_files': len(names), 'original_files_unchanged': len(unchanged),
        'changed_original_files': changed, 'deleted_original_files': [],
        'integrated_checker_sha256': integration['integrated_checker_sha256']}, indent=2))

if __name__ == '__main__':
    main()
