# Transform cards v2 (from executed receipts and Stage 2 checks)

These cards are copied from `results/stage1.json`, `results/stage2.json`, `results/unsafe_ablation.json`, and `results/xor_stall_minimality.json`. They are not fabricated. `verify_seed.py` is calibration only.

## Card 1 — four-factor window recovers retained XOR (contract B)

**Instance:** `calibration:xor3:p=1:vars=1,2,3` with retained variables `{1,2,3}`.

```text
p cnf 3 4
1 2 3 0
1 -2 -3 0
-1 2 -3 0
-1 -2 3 0
```

**W3:** 10 groups, 0 rewrites, residual = four clauses, status `UNRESOLVED`. Not a PARITY atom. Proof bytes 2 (empty receipt list).

**W4:** one group of four clauses, scope `{1,2,3}`, promise **B**, replacement `P:1,2,3=1`. Independent checker accepted the receipt (`did_not_invoke_compiler`, `did_not_trust_validation_string`). Affine then closed (`stdlib_gf2_gaussian`) to a SAT witness on the original CNF. Candidates 11, wall ≈ 0.002s, initial/peak IR 37 bytes, proof bytes 316.

Empty-boundary projection to `TRUE` on the **unprotected** copy is a different fact and is **not** counted as parity recognition.

## Card 2 — temporary TABLE route (W3-T)

Same instance, variant W3-T (window still 2–3).

1. Speculative (cost-increasing): `{C:-1,-2,3, C:-1,2,-3, C:1,-2,-3}` → `TBL:1,2,3:97` (promise B, `speculative=true`).
2. Ordinary: `{TBL:1,2,3:97, C:1,2,3}` → `P:1,2,3=1`.

`temp_tables_created=1`. A table is not claimed as compression. Residual PARITY, then labeled GF(2) close. Near-miss deletion of one XOR clause produced a leftover TABLE, **not** PARITY.

## Card 3 — indexing, not a stronger grammar (W4-I)

Same XOR, W4-I: replacement `P:1,2,3=1`, `index_hits=1`, grammar unchanged. On random 3-CNF, W4-I still hit `RESOURCE_LIMIT` where W3 returned SAT — indexing did not cancel four-factor enumeration cost.

## Card 4 — invalid pairwise contraction (native three-color star)

**Carrier:** `{0,1,2}`, declared. Block `X≠A, X≠B, X≠C`, X internal.

Retained: `USES_AT_MOST_2_COLORS(A,B,C)`. Verification (not construction of the k-rule): 21/27 extendable; each pair projection size 9. Conjunction of pair projections admits `(0,1,2)`; the true relation rejects it.

Plus `A≠B, B≠C, C≠A`: exact system UNSAT; pair-only ablation SAT on all-distinct. Kept out of the engine.

One-hot CNF: 12 Boolean variables, 25 clauses, clause-set equal to `fixtures/three_color_star.cnf`. Raw-CNF discovery of the native carrier: SKIPPED.

## Card 5 — overlapping compact relations (unsupported join)

Overlapping stars `X—{A,B,C}` and `Y—{C,D,E}`. After eliminating X and Y (same final retained outputs for fixed-id, min-degree, and representation-aware orders):

`USES_AT_MOST_2_COLORS(A,B,C)` and `USES_AT_MOST_2_COLORS(C,D,E)`.

Union arity 5 is **not** `USES_AT_MOST_2_COLORS` on `{A,B,C,D,E}` (147 vs 93 of 243 retained assignments; example `(A,B,C,D,E)=(0,0,1,1,2)` satisfies both triples and uses all three colors overall). The two-factor conjunction is already an exact compact description. There is no supported *single named atom* on the union; that is not a general compact-composition impossibility. Stopped without manufacturing a new atom. Next question: which further operation the retained pair cannot support affordably. Original stars are already O(k) to store; a 3^k table is larger and is not the comparison that matters. All three displayed order policies choose X then Y on this specimen; that is not comparative evidence of ordering superiority.

## Card 6 — expensive window regression

`stage1:signed_graph:n=8:m=10:seed=23:u=0`: W3 `UNSAT` (checked derivation to `F`); W4 and W4-I `RESOURCE_LIMIT` under the same frozen budget. A larger grouping window is not monotonically better.

## Notes

- Card 1 is promise B (same named variables). Card 2’s first step is a temporary object under an explicit W3-T exception to immediate compression.
- Card 4 is why pairwise marginals are unsound on this native specimen.
- XOR stall minimality: W3 still has no PARITY after each single clause deletion; deleting a clause changes the relation and does **not** prove the stall is 1-minimal as a selector property (`results/xor_stall_minimality.json`).
