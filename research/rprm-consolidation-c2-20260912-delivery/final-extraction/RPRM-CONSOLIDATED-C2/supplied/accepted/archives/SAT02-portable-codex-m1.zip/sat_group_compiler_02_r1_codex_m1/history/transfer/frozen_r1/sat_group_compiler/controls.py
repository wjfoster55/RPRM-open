"""Presentation controls: rename, complement, reorder, duplicates, tautologies."""

from __future__ import annotations

import random

from .dimacs import parse_dimacs, to_dimacs
from .ir import cnf_holds


def rename_cnf(dimacs: str, perm: dict[int, int]) -> str:
    parsed = parse_dimacs(dimacs)
    clauses = []
    for clause in parsed.clauses:
        clauses.append(tuple((1 if lit > 0 else -1) * perm[abs(lit)] for lit in clause))
    n = parsed.n_vars
    return to_dimacs(n, clauses)


def complement_cnf(dimacs: str, flipped: set[int]) -> str:
    parsed = parse_dimacs(dimacs)
    clauses = []
    for clause in parsed.clauses:
        new = []
        for lit in clause:
            var = abs(lit)
            if var in flipped:
                new.append(-lit)
            else:
                new.append(lit)
        clauses.append(tuple(new))
    return to_dimacs(parsed.n_vars, clauses)


def reorder_cnf(dimacs: str, seed: int) -> str:
    parsed = parse_dimacs(dimacs)
    rng = random.Random(seed)
    clauses = []
    for clause in parsed.clauses:
        lits = list(clause)
        rng.shuffle(lits)
        clauses.append(tuple(lits))
    rng.shuffle(clauses)
    return to_dimacs(parsed.n_vars, clauses)


def duplicate_some_clauses(dimacs: str, seed: int) -> str:
    parsed = parse_dimacs(dimacs)
    rng = random.Random(seed)
    clauses = list(parsed.clauses)
    if clauses:
        extra = clauses[rng.randrange(len(clauses))]
        clauses.append(extra)
    return to_dimacs(parsed.n_vars, clauses)


def add_tautologies(dimacs: str, seed: int) -> str:
    parsed = parse_dimacs(dimacs)
    n = max(parsed.n_vars, 1)
    rng = random.Random(seed)
    var = rng.randint(1, n)
    clauses = list(parsed.clauses) + [(var, -var)]
    return to_dimacs(n, clauses)


def map_witness_after_complement(assignment: dict[int, int], flipped: set[int]) -> dict[int, int]:
    out = dict(assignment)
    for var in flipped:
        if var in out:
            out[var] = 1 - out[var]
    return out


def map_witness_after_rename(assignment: dict[int, int], perm: dict[int, int]) -> dict[int, int]:
    inv = {new: old for old, new in perm.items()}
    return {new: assignment[old] for old, new in perm.items() if old in assignment}


def original_holds_after_rename(
    original_dimacs: str, renamed_assignment: dict[int, int], perm: dict[int, int]
) -> bool:
    parsed = parse_dimacs(original_dimacs)
    inv = {new: old for old, new in perm.items()}
    original_asg = {inv[v]: bit for v, bit in renamed_assignment.items() if v in inv}
    return cnf_holds(parsed.clauses, original_asg)
