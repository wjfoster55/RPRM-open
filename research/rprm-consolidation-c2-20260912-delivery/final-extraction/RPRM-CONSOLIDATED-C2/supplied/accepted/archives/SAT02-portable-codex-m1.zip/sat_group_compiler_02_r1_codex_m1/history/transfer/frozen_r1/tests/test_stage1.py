from __future__ import annotations

import unittest

from sat_group_compiler.compiler import compile_cnf
from sat_group_compiler.controls import complement_cnf, reorder_cnf
from sat_group_compiler.ir import Kind, factor_holds, parse_canon
from sat_group_compiler.protocol import load_protocol, stage_limits


XOR = "p cnf 3 4\n1 2 3 0\n1 -2 -3 0\n-1 2 -3 0\n-1 -2 3 0\n"
XOR0 = "p cnf 3 4\n-1 -2 -3 0\n-1 2 3 0\n1 -2 3 0\n1 2 -3 0\n"


def limits(variant):
    return stage_limits(load_protocol(), "smoke", variant)


def has_parity(result) -> bool:
    return any(s.startswith("P:") for s in result.residual + result.recognized)


def parity_contract_b(result, parity: int) -> bool:
    atoms = [s for s in result.residual if s.startswith("P:")] or [s for s in result.recognized if s.startswith("P:")]
    if not atoms:
        return False
    factor = parse_canon(atoms[0])
    if factor.kind is not Kind.PARITY:
        return False
    for mask in range(8):
        asg = {1: mask & 1, 2: (mask >> 1) & 1, 3: (mask >> 2) & 1}
        got = factor_holds(factor, asg)
        want = (asg[1] ^ asg[2] ^ asg[3]) == int(factor.parity)
        if got != want:
            return False
    return True


class WindowVersusTempTests(unittest.TestCase):
    def test_protected_xor_w3_does_not_count_true_as_parity(self):
        r = compile_cnf(XOR, mode="C", limits=limits("W3"), variant="W3", retain=[1, 2, 3], use_affine=False)
        self.assertFalse(has_parity(r))
        self.assertFalse(any(s == "T" and not r.receipts for s in r.residual))
        self.assertEqual(r.status, "UNRESOLVED")

    def test_protected_xor_w4_recovers_parity(self):
        r = compile_cnf(XOR, mode="C", limits=limits("W4"), variant="W4", retain=[1, 2, 3], use_affine=False)
        self.assertTrue(has_parity(r), msg=r.residual)
        self.assertTrue(parity_contract_b(r, 1))
        self.assertTrue(all(c["ok"] for c in r.receipt_checks))

    def test_protected_xor_even_parity_w4(self):
        r = compile_cnf(XOR0, mode="C", limits=limits("W4"), variant="W4", retain=[1, 2, 3], use_affine=False)
        self.assertTrue(has_parity(r), msg=r.residual)
        self.assertTrue(parity_contract_b(r, 0))

    def test_w3t_temporary_table_reaches_parity(self):
        r = compile_cnf(XOR, mode="C", limits=limits("W3-T"), variant="W3-T", retain=[1, 2, 3], use_affine=False)
        self.assertTrue(has_parity(r), msg=(r.residual, r.derivation, r.meter.temp_tables_created))
        self.assertGreaterEqual(r.meter.temp_tables_created, 1)
        self.assertTrue(parity_contract_b(r, 1))

    def test_w4i_index_hits_same_scope(self):
        r = compile_cnf(XOR, mode="C", limits=limits("W4-I"), variant="W4-I", retain=[1, 2, 3], use_affine=False)
        self.assertTrue(has_parity(r))
        self.assertGreaterEqual(r.meter.index_hits, 1)

    def test_unprotected_xor_true_is_not_parity_success(self):
        r = compile_cnf(XOR, mode="C", limits=limits("W4"), variant="W4", retain=None, use_affine=False)
        # empty-boundary projection to TRUE may decide SAT; that is not parity recognition
        recognized_parity = has_parity(r)
        if r.status == "SAT" and any(rec.replacement == ["T"] for rec in r.receipts):
            self.assertTrue(True)  # documented non-success for the recognition question
        self.assertTrue(recognized_parity or r.status in {"SAT", "UNRESOLVED"})

    def test_near_miss_delete_is_not_parity(self):
        text = "p cnf 3 3\n1 2 3 0\n1 -2 -3 0\n-1 2 -3 0\n"
        for variant in ("W3", "W4", "W3-T", "W4-I"):
            r = compile_cnf(text, mode="C", limits=limits(variant), variant=variant, retain=[1, 2, 3], use_affine=False)
            self.assertFalse(has_parity(r), msg=(variant, r.residual, r.recognized))

    def test_reorder_still_parity_w4(self):
        text = reorder_cnf(XOR, 23)
        r = compile_cnf(text, mode="C", limits=limits("W4"), variant="W4", retain=[1, 2, 3], use_affine=False)
        self.assertTrue(has_parity(r))

    def test_complement_one_var_w4(self):
        text = complement_cnf(XOR, {1})
        r = compile_cnf(text, mode="C", limits=limits("W4"), variant="W4", retain=[1, 2, 3], use_affine=False)
        self.assertTrue(has_parity(r), msg=r.residual)


if __name__ == "__main__":
    unittest.main()
