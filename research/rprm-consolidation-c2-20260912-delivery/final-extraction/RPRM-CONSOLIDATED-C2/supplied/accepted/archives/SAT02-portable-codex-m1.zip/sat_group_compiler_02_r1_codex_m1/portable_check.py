"""Confine the existing SAT02 test/review entrypoints to delivered code + stdlib.

Run with python -I -S -B portable_check.py {tests,regressions,review,rows,manifest}.
No solver code is changed by this launcher. No panels are executed.
"""
from __future__ import annotations
import argparse
import importlib.machinery
import json
from pathlib import Path
import runpy
import sys
import sysconfig

ROOT = Path(__file__).resolve().parent
STDLIB = Path(sysconfig.get_path('stdlib')).resolve()
DLLS = Path(sys.base_prefix).resolve() / 'DLLs'
blocked = []

def allowed(origin):
    if origin in (None, 'built-in', 'frozen'):
        return True
    p = Path(origin).resolve()
    return p.is_relative_to(ROOT) or (
        (p.is_relative_to(STDLIB) or p.is_relative_to(DLLS))
        and 'site-packages' not in p.parts
    )

class DeliveredImports:
    @classmethod
    def find_spec(cls, fullname, path=None, target=None):
        spec = importlib.machinery.PathFinder.find_spec(fullname, path, target)
        if spec is not None:
            origins = [spec.origin] if spec.origin else list(spec.submodule_search_locations or [])
            if not all(allowed(o) for o in origins):
                blocked.append({'module': fullname, 'origins': origins})
                raise ModuleNotFoundError('External optional dependency disabled for delivered-only verification: ' + fullname)
        return spec

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('check', choices=['tests', 'regressions', 'review', 'rows', 'manifest'])
    ap.add_argument('--output', type=Path)
    ap.add_argument('--environment', type=Path, required=True)
    a = ap.parse_args()
    assert not sys.flags.optimize and sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
    sys.path.insert(0, str(ROOT))
    sys.meta_path[:] = [DeliveredImports if f is importlib.machinery.PathFinder else f for f in sys.meta_path]
    try:
        if a.check == 'tests':
            sys.argv = [str(ROOT / 'run.py'), 'test']
            runpy.run_path(sys.argv[0], run_name='__main__')
        elif a.check == 'regressions':
            sys.argv = ['unittest', 'discover', '-s', str(ROOT / 'tests'), '-p', 'test_recovery_boundary_closeout.py', '-v']
            runpy.run_module('unittest', run_name='__main__')
        elif a.check == 'review':
            assert a.output is not None
            sys.argv = [str(ROOT / 'verification/review_successor.py'), '--experiment', str(ROOT),
                        '--original', str(ROOT / 'saved'), '--prior-review', str(ROOT / 'verification/prior'),
                        '--output', str(a.output.resolve())]
            runpy.run_path(sys.argv[0], run_name='__main__')
        elif a.check == 'rows':
            assert a.output is not None
            sys.argv = [str(ROOT / 'verification/check_saved_rows.py'), '--output', str(a.output.resolve())]
            runpy.run_path(sys.argv[0], run_name='__main__')
        else:
            sys.argv = [str(ROOT / 'verification/verify_manifest.py')]
            runpy.run_path(sys.argv[0], run_name='__main__')
    finally:
        modules = {name: getattr(mod, '__file__', None) for name, mod in sorted(sys.modules.items())}
        unexpected = {name: origin for name, origin in modules.items() if not allowed(origin)}
        a.environment.write_text(json.dumps({'python': sys.version, 'executable': sys.executable,
            'flags': str(sys.flags), 'root': str(ROOT), 'stdlib': str(STDLIB),
            'blocked_external_imports': blocked, 'unexpected_modules': unexpected,
            'module_origins': modules}, indent=2) + '\n', encoding='utf-8')
        assert not unexpected, unexpected

if __name__ == '__main__':
    main()
