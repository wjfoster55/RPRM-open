# Existing command shapes for Codex M1

These entrypoint shapes were checked against the supplied code while preparing the
handoff. The handoff preparation itself did not rerun solver tests, apply the patch,
or create a successor. Follow `CODEX_START_HERE.md`; these commands are not a
separate assignment.

Use the available Python executable; do not install packages or change global
configuration. Resolve every placeholder to an actual path. Work and output
directories must be fresh and OUTSIDE the handoff and existing source trees.

## 1. Transfer verification

From the extracted handoff root:

```text
python -B verify_handoff.py
```

This checks the delivered files and source mirrors, not mathematical correctness.

## 2. Baseline

Copy `frozen_r1/` to a fresh baseline directory, preserving all files. From that
copy, with only its own package on the import path:

```text
python -B run.py test
```

The existing code's `test` subcommand uses unittest discovery. The prior baseline
was 73 cases. Do not invoke the similarly named `panels`, `freeze`, `smoke`, or
`stress` generation commands.

To exercise the six additional regressions against the baseline, copy
`review/candidate_patch/test_recovery_boundary_closeout.py` into the disposable
baseline's `tests/`, after recording the original 73-test run. Then:

```text
python -B -m unittest discover -s tests -p test_recovery_boundary_closeout.py -v
```

The prior expected result on unpatched R1 is three failures among six, specifically
boundary overwrite in both recovery forms and legitimate emptiness. Wrong-reason
exceptions are not accepted reproduction.

## 3. Candidate application, only after inspection

```text
python -B <HANDOFF>/review/candidate_patch/apply_to_fresh_copy.py --source <HANDOFF>/frozen_r1 --destination <NEW_SUCCESSOR>
```

This helper only copies and replaces the checker. It validates its exact source
and replacement hashes, refuses an existing destination or one under the source,
and does not integrate into the live original. Its generated
`PATCH_APPLICATION.json` is an intermediate reviewer-candidate record. Create a
separate M1 integration identity after verifying; keep the old record historical.

From the fresh successor, run the original 73 tests. Copy the six-review-test file
into the successor tests without replacing old files, run the focused six, and
retain both outputs. A later complete discovery should contain 79=73+6 tests,
unless a justified and documented change is required.

## 4. Existing saved-receipt and local-specimen replay

The review helper expects an original `results/` folder and a prior interpreter
under `scripts/review_sat02.py`. Both are already arranged in this handoff:

```text
python -B <HANDOFF>/review/tools/review_successor.py --experiment <NEW_SUCCESSOR> --original <HANDOFF>/historical_sat02 --prior-review <HANDOFF>/reference_interpreter --output <FRESH_EXTERNAL_EVIDENCE>
```

It imports the successor explicitly and consumes only five existing saved panel
files. It does not execute the original panel generator. The interpreter is the
same earlier reviewer implementation, not a newly independent method.

Inspect at least:

- `saved_receipts_recheck.json`: expected integrated count 982, empty `rejected`,
  and empty `independent_errors`;
- `receipt_controls.json`: correct closed/table recovery accepted, bad recovery
  and retained-boundary overwrite rejected. Its unbound-ID example deliberately
  remains only a local check, with no original-factor binding guarantee;
- `xor_checks.json`: protected parity correctness and the retained cost route;
- `group_oracle.json`, `native_check.json`, `timer_and_grade.json`, and
  `fingerprint_check.json`: inherited bounded-regression results.

The helper's successful exit alone does NOT require its saved receipts to have
zero rejections; the baseline is intentionally allowed to record that finding.
The M1 acceptance decision must inspect the actual rows and conditions.

## 5. Final-ZIP replay

Package the tested source and its declared replay dependencies with an active
README. Preserve original input archives and history, but don't confuse them with
active builds. Extract the final build, set the replay to that extraction, and
run the same test and saved-receipt commands using delivered paths. No dependency
on the handoff's old absolute location or original live workspace may be hidden.

Record hashes and actual command results. Put final replay evidence outside the
hashed build; return its own archive and digest. Source integrity, unit checks,
local receipt verification, and a new benchmark are distinct. No new benchmark is
part of M1.
