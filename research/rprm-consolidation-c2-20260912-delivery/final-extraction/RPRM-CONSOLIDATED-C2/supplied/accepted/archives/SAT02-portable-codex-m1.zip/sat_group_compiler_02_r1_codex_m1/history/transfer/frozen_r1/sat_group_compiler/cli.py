"""CLI: hash/freeze, tests, smoke, stress, stage1/stage2, panels."""

from __future__ import annotations

import csv
import json
import sys
import time
import unittest
from pathlib import Path
from typing import Any

from .backends import (
    OracleResult,
    baseline_d_bucket,
    classify_cnf,
    get_probe,
    independent_label,
    pysat_sat,
    signed_graph_baseline,
    slow_stub,
)
from .compiler import CompileResult, compile_cnf
from .controls import (
    add_tautologies,
    complement_cnf,
    duplicate_some_clauses,
    rename_cnf,
    reorder_cnf,
)
from .dimacs import parse_dimacs
from .fingerprints import freeze_record, write_json
from .generators import (
    EvalInstance,
    amo3,
    contraction_seed,
    different_cycle,
    different_tree,
    disjoint_binaries,
    duplicate_lits,
    empty_clause,
    empty_formula,
    exactly_one_system,
    graph_coloring_cycle,
    hidden_xor_among_binaries,
    mixed_xor_or_v2,
    pigeonhole,
    random_3cnf,
    same_path,
    signed_graph,
    tautology_only,
    triangle_fixture,
    unused_vars,
    xor3_complemented,
    xor3_embedded,
    xor3_even,
    xor3_four_clauses,
    xor3_instance,
    xor3_near_miss_delete,
    xor3_near_miss_flip,
    xor3_odd,
    xor3_renamed,
    xor3_with_dups_taut,
    xor_network,
)
from .ir import cnf_holds, parse_canon, Kind
from .native3 import run_stage2
from .protocol import PROTOCOL_PATH, load_protocol, protocol_sha256, stage_limits
from .unsafe import triangle_unsafe_counterexample

ROOT = Path(__file__).resolve().parent.parent
RESULTS = ROOT / "results"
FIXTURES = ROOT / "fixtures"
VARIANTS = ("W3", "W4", "W3-T", "W4-I")

# Protocol declaration versus effective SAT02 panel execution.
# Do not score the omitted seeds into the original completed result.
DECLARED_DEVELOPMENT_SEEDS = (23, 29, 31, 37, 41)
DECLARED_EVALUATION_SEEDS = (20011, 20021, 20047, 20063, 20089)
EFFECTIVE_DEVELOPMENT_SEEDS = (23, 29, 31)
EFFECTIVE_EVALUATION_SEEDS = (20011, 20021, 20047)
NOT_RUN_SEEDS = (37, 41, 20063, 20089)


def seed_coverage() -> dict[str, Any]:
    protocol = load_protocol()
    declared_dev = tuple(protocol["development_seeds"])
    declared_eval = tuple(protocol["evaluation_seeds"])
    return {
        "declared_development": list(declared_dev),
        "declared_evaluation": list(declared_eval),
        "effective_development": list(EFFECTIVE_DEVELOPMENT_SEEDS),
        "effective_evaluation": list(EFFECTIVE_EVALUATION_SEEDS),
        "not_run": [
            {"split": "development", "seed": 37, "status": "NOT_RUN"},
            {"split": "development", "seed": 41, "status": "NOT_RUN"},
            {"split": "evaluation", "seed": 20063, "status": "NOT_RUN"},
            {"split": "evaluation", "seed": 20089, "status": "NOT_RUN"},
        ],
        "run_count": 6,
        "not_run_count": 4,
        "declared_count": 10,
        "execution": "partial",
        "backfill_into_original_result": False,
        "panel_instance_rule": "seeds[0] plus seeds[1:3] only",
        "note": "Ten-seed declaration preserved. Four omitted seeds are NOT_RUN, not a missing-results-file.",
    }


def result_record(
    inst: EvalInstance,
    mode: str,
    compiled: CompileResult,
    oracle: OracleResult,
    extra: dict[str, Any] | None = None,
) -> dict[str, Any]:
    sound = None
    if compiled.status == "SAT":
        sound = compiled.assignment is not None and cnf_holds(
            compiled.original_clauses, compiled.assignment
        )
        if oracle.status == "UNSAT":
            sound = False
    elif compiled.status == "UNSAT":
        if oracle.status == "SAT":
            sound = False
        elif oracle.status == "UNSAT":
            sound = True
        else:
            sound = None
    agreement = None
    if compiled.status in {"SAT", "UNSAT"} and oracle.status in {"SAT", "UNSAT"}:
        agreement = compiled.status == oracle.status
    parity_atoms = [s for s in compiled.residual + compiled.recognized if s.startswith("P:")]
    rec = {
        "instance_id": inst.instance_id,
        "family": inst.family,
        "split": inst.split,
        "seed": inst.seed,
        "mode": mode,
        "variant": compiled.variant,
        "candidate_status": compiled.status,
        "oracle_status": oracle.status,
        "oracle_method": oracle.method,
        "oracle_proof_checked": oracle.proof_checked,
        "agreement": agreement,
        "sound": sound,
        "claim_grade": compiled.claim_grade,
        "n_vars": compiled.n_vars,
        "n_clauses": len(compiled.original_clauses),
        "residual": compiled.residual,
        "recognized": compiled.recognized,
        "parity_atoms": parity_atoms,
        "n_receipts": len(compiled.receipts),
        "derivation": compiled.derivation,
        "affine_label": compiled.affine_label,
        "error": compiled.error,
        "meter": compiled.meter.as_dict(),
        "oracle_seconds": oracle.seconds,
        "assignment": compiled.assignment,
        "receipt_checks": compiled.receipt_checks,
        "receipts": [
            {
                "input_factor_ids": r.input_factor_ids,
                "input_identities": r.input_identities,
                "boundary": r.boundary,
                "eliminated": r.eliminated,
                "replacement": r.replacement,
                "promise": r.promise,
                "validation": r.validation,
                "recovery": r.recovery,
                "orig_cost": r.orig_cost,
                "new_cost": r.new_cost,
                "scope": r.scope,
                "group_sat_mask": r.group_sat_mask,
                "speculative": r.speculative,
                "note": r.note,
            }
            for r in compiled.receipts
        ],
    }
    if extra:
        rec.update(extra)
    return rec


def run_candidate(
    inst: EvalInstance,
    mode: str,
    stage: str,
    protocol: dict,
    variant: str | None = None,
    retain: list[int] | None = None,
    cache_policy: str = "cold",
) -> CompileResult:
    limits = stage_limits(protocol, stage, variant)
    return compile_cnf(
        inst.dimacs,
        mode=mode,
        limits=limits,
        retain=retain,
        variant=variant,
        cache_policy=cache_policy,
    )


def hybrid_arm(inst: EvalInstance, compiled: CompileResult, timeout_s: float) -> dict[str, Any]:
    preprocess_s = float(compiled.meter.wall_s)
    if compiled.status in {"SAT", "UNSAT", "MALFORMED", "FAILURE"}:
        return {
            "hybrid_status": compiled.status,
            "hybrid_note": "no residual solver",
            "preprocess_s": preprocess_s,
            "residual_solve_s": 0.0,
            "lift_s": 0.0,
            "hybrid_total_s": preprocess_s,
        }
    parsed = parse_dimacs(inst.dimacs)
    residual = compiled.residual_clauses
    oracle = pysat_sat(parsed.n_vars, residual, timeout_s)
    t_lift = time.perf_counter()
    assignment = None
    status = oracle.status
    if oracle.status == "SAT" and oracle.assignment is not None:
        from .compiler import reconstruct_assignment

        assignment = reconstruct_assignment(
            parsed.n_vars, oracle.assignment, list(reversed(compiled.receipts)), []
        )
        if not cnf_holds(parsed.clauses, assignment):
            status = "HYBRID_WITNESS_FAILED"
    lift_s = time.perf_counter() - t_lift
    return {
        "hybrid_status": status,
        "hybrid_method": "HYBRID_pysat_residual",
        "hybrid_note": "preprocess + residual Glucose3 + reconstruction counted once each; DRAT not checked",
        "preprocess_s": preprocess_s,
        "residual_solve_s": oracle.seconds,
        "lift_s": lift_s,
        "hybrid_total_s": preprocess_s + oracle.seconds + lift_s,
        "proof_checked": False,
        "assignment": assignment,
    }


def recognition_ok_parity(compiled: CompileResult, vars_: tuple[int, int, int], parity: int) -> bool:
    """Contract B on all 8 assignments. SAT-by-TRUE is not success."""
    atoms = [s for s in compiled.residual if s.startswith("P:")]
    if not atoms:
        atoms = [s for s in compiled.recognized if s.startswith("P:")]
    if not atoms:
        return False
    if any(s == "T" for s in compiled.residual) and not atoms:
        return False
    factor = parse_canon(atoms[0])
    if factor.kind is not Kind.PARITY:
        return False
    from .ir import factor_holds

    for mask in range(8):
        asg = {
            vars_[0]: mask & 1,
            vars_[1]: (mask >> 1) & 1,
            vars_[2]: (mask >> 2) & 1,
        }
        got = factor_holds(factor, asg)
        want = (asg[vars_[0]] ^ asg[vars_[1]] ^ asg[vars_[2]]) == parity
        # complementation may rename; check against the stored atom instead if vars differ
        if set(factor.lits) == set(vars_):
            if got != want:
                # allow flipped parity if the atom says so
                if bool(factor.parity) != bool(parity):
                    if got != ((asg[vars_[0]] ^ asg[vars_[1]] ^ asg[vars_[2]]) == int(factor.parity)):
                        return False
                else:
                    return False
        else:
            if not got and want:
                return False
    return True


def smoke_instances() -> list[EvalInstance]:
    return [
        empty_formula(),
        empty_clause(),
        tautology_only(),
        unused_vars(),
        duplicate_lits(),
        triangle_fixture(),
        amo3(),
        xor3_odd(),
        xor3_even(),
        contraction_seed(),
        different_cycle(3, 23, "development"),
        different_cycle(4, 23, "development"),
        xor3_embedded(6, 23, "development"),
        exactly_one_system(3, 23, "development"),
        disjoint_binaries(8),
    ]


def stress_instances() -> list[EvalInstance]:
    out: list[EvalInstance] = [disjoint_binaries(70)]
    for n in (3, 5, 8, 11):
        out.append(different_cycle(n, 29, "development"))
    out.append(hidden_xor_among_binaries(12, 29, "development"))
    out.append(xor_network(2, 29, "development"))
    out.append(mixed_xor_or_v2(6, 29, "development"))
    out.append(random_3cnf(8, 20, 29, "development"))
    out.append(signed_graph(10, 12, 29, "development"))
    return out


def stage1_instances() -> list[EvalInstance]:
    out: list[EvalInstance] = [
        xor3_odd(),
        xor3_even(),
        xor3_renamed(23, "stage1"),
        xor3_complemented((1,), "stage1"),
        xor3_complemented((1, 2), "stage1"),
        xor3_with_dups_taut(23, "stage1"),
        xor3_near_miss_delete(0, "stage1"),
        xor3_near_miss_flip(0, "stage1"),
        xor3_embedded(7, 23, "stage1"),
        xor_network(2, 23, "stage1"),
        mixed_xor_or_v2(6, 23, "stage1"),
        hidden_xor_among_binaries(8, 23, "stage1"),
        triangle_fixture(),
        amo3(),
        exactly_one_system(3, 23, "stage1"),
        signed_graph(8, 10, 23, "stage1"),
        random_3cnf(7, 14, 23, "stage1"),
        different_cycle(5, 23, "stage1"),
    ]
    return out


def panel_instances(split: str, seeds: list[int]) -> list[EvalInstance]:
    """Build the SAT02 panel family.

    Effective coverage uses ``seeds[0]`` then ``seeds[1:3]`` (the next two).
    Declared seeds after that remain NOT_RUN. Do not enlarge this loop to
    backfill the original completed result.
    """
    out: list[EvalInstance] = [triangle_fixture(), amo3(), xor3_odd(), xor3_even(), contraction_seed()]
    seed0 = seeds[0]
    for n in (3, 4, 5, 8):
        out.append(different_cycle(n, seed0, split))
    out.append(same_path(6, seed0, split))
    out.append(signed_graph(8, 10, seed0, split, True))
    out.append(exactly_one_system(4, seed0, split))
    out.append(random_3cnf(7, 16, seed0, split))
    out.append(mixed_xor_or_v2(6, seed0, split))
    out.append(xor3_embedded(7, seed0, split))
    out.append(xor3_near_miss_delete(1, split))
    for seed in seeds[1:3]:
        out.append(different_cycle(6, seed, split))
        out.append(hidden_xor_among_binaries(6, seed, split))
        out.append(random_3cnf(8, 18, seed, split))
    return out


def run_panel(
    instances: list[EvalInstance],
    stage: str,
    modes: tuple[str, ...],
    variants: tuple[str, ...] | tuple[()] = (),
    retain_xor: bool = False,
) -> list[dict[str, Any]]:
    protocol = load_protocol()
    exhaustive_max = int(protocol["exhaustive_max_n"])
    timeout = float(protocol["oracle_timeout_s"])
    max_n_d = int(protocol["baseline_d_max_n"])
    max_w = int(protocol["baseline_d_max_width"])
    records: list[dict[str, Any]] = []
    arms: list[tuple[str, str | None]] = []
    if variants:
        for variant in variants:
            arms.append(("C", variant))
    else:
        for mode in modes:
            arms.append((mode, None))
    for inst in instances:
        parsed = parse_dimacs(inst.dimacs)
        oracle = independent_label(parsed.n_vars, parsed.clauses, exhaustive_max, timeout)
        sg = signed_graph_baseline(parsed.n_vars, parsed.clauses)
        d_arm = baseline_d_bucket(parsed.n_vars, parsed.clauses, max_n_d, max_w)
        syntax = classify_cnf(parsed.clauses)
        retain = [1, 2, 3] if retain_xor and inst.family.startswith("xor3") and parsed.n_vars >= 3 else None
        # Protected XOR rows receive an explicit retained-variable contract.
        # A/B rows do not. These are different output obligations, not an
        # identical-contract comparison, and not satisfying-assignment leakage.
        for mode, variant in arms:
            label = variant or mode
            print(f"  {inst.instance_id} arm={label}", flush=True)
            compiled = run_candidate(inst, mode, stage, protocol, variant=variant, retain=retain, cache_policy="cold")
            extra = {
                "signed_graph_baseline": sg.status,
                "signed_graph_seconds": sg.seconds,
                "baseline_d_status": d_arm.status,
                "baseline_d_method": d_arm.method,
                "baseline_d_seconds": d_arm.seconds,
                "baseline_d_extra": d_arm.extra,
                "oracle_skipped": oracle.skipped_reason,
                "syntax": syntax,
                "cache_policy": "cold",
                "retained": retain,
            }
            if inst.family.startswith("xor3") and "near_miss" not in inst.family:
                extra["parity_recognition_contract_B"] = any(
                    s.startswith("P:") for s in compiled.residual + compiled.recognized
                )
            if variant == "W3" or mode == "C":
                extra["hybrid"] = hybrid_arm(inst, compiled, timeout)
            records.append(result_record(inst, mode, compiled, oracle, extra))
    return records


def write_csv(path: Path, records: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fields = [
        "instance_id",
        "family",
        "split",
        "mode",
        "variant",
        "candidate_status",
        "oracle_status",
        "agreement",
        "sound",
        "claim_grade",
        "n_vars",
        "n_clauses",
        "n_receipts",
        "candidates_examined",
        "candidates_rejected",
        "groups_emitted",
        "tuples_proposed",
        "index_hits",
        "temp_tables_created",
        "table_rows",
        "rewrites",
        "input_bytes",
        "initial_ir_bytes",
        "peak_ir_bytes",
        "proof_bytes",
        "wall_s",
        "parse_s",
        "group_generation_s",
        "recognition_s",
        "selection_s",
        "oracle_method",
        "signed_graph_baseline",
        "baseline_d_status",
    ]
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        for rec in records:
            meter = rec.get("meter") or {}
            row = {k: rec.get(k) for k in fields}
            for key in (
                "candidates_examined",
                "candidates_rejected",
                "groups_emitted",
                "tuples_proposed",
                "index_hits",
                "temp_tables_created",
                "table_rows",
                "rewrites",
                "input_bytes",
                "initial_ir_bytes",
                "peak_ir_bytes",
                "proof_bytes",
                "wall_s",
                "parse_s",
                "group_generation_s",
                "recognition_s",
                "selection_s",
            ):
                row[key] = meter.get(key)
            writer.writerow(row)


def _summarize(records: list[dict[str, Any]]) -> dict[str, Any]:
    statuses = {}
    for rec in records:
        key = rec.get("variant") or rec["mode"]
        statuses.setdefault(key, {})
        statuses[key][rec["candidate_status"]] = statuses[key].get(rec["candidate_status"], 0) + 1
    regressions = []
    by_id: dict[str, dict[str, str]] = {}
    for rec in records:
        by_id.setdefault(rec["instance_id"], {})[rec.get("variant") or rec["mode"]] = rec["candidate_status"]
    for iid, arms in by_id.items():
        w3 = arms.get("W3")
        for other in ("W4", "W3-T", "W4-I"):
            if w3 in {"SAT", "UNSAT"} and arms.get(other) in {"RESOURCE_LIMIT", "UNRESOLVED"} and w3 != arms.get(other):
                if arms.get(other) == "RESOURCE_LIMIT":
                    regressions.append({"instance_id": iid, "w3": w3, "other": other, "status": arms[other]})
    return {
        "records": len(records),
        "unsound": sum(1 for r in records if r.get("sound") is False),
        "failure": sum(1 for r in records if r["candidate_status"] == "FAILURE"),
        "status_by_arm": statuses,
        "decisive_to_limited_regressions": regressions,
    }


def cmd_hash() -> int:
    from .backends import get_probe

    proto = load_protocol()
    rec = freeze_record(get_probe())
    rec["protocol_sha256_only"] = protocol_sha256(proto)
    write_json(ROOT / "versions.json", rec)
    print(rec["protocol_sha256"])
    print("source", rec["source_sha256"])
    return 0


def cmd_freeze() -> int:
    probe = get_probe()
    rec = freeze_record(probe)
    rec["frozen_before_panels"] = True
    rec["backend_availability"] = {
        "pysat": bool(probe.get("pysat")),
        "stdlib_gf2": True,
        "closure_sat": bool(probe.get("closure_sat")),
        "narizoo_affine": bool(probe.get("affine")),
    }
    write_json(ROOT / "versions.json", rec)
    write_json(RESULTS / "freeze.json", rec)
    print(json.dumps(rec["backend_availability"], indent=2))
    print("protocol", rec["protocol_sha256"])
    print("source", rec["source_sha256"])
    return 0


def cmd_verify_seed() -> int:
    from .arithmetic import verify_binary_identities

    ids = verify_binary_identities()
    tri = triangle_fixture()
    parsed = parse_dimacs(tri.dimacs)
    oracle = independent_label(parsed.n_vars, parsed.clauses, 12, 5)
    pair_sat = []
    pair_clauses = [parsed.clauses[0:2], parsed.clauses[2:4], parsed.clauses[4:6]]
    for cls in pair_clauses:
        r = independent_label(3, cls, 12, 5)
        pair_sat.append(r.status)
    payload = {
        "role": "calibration_only_not_compiler_performance",
        "identities": ids,
        "triangle_oracle": oracle.status,
        "each_pair_status": pair_sat,
        "n_clauses": len(parsed.clauses),
        "n_vars": parsed.n_vars,
        "arithmetic": "a+b=1, b+c=1, c+a=1 implies 2(a+b+c)=3, impossible in {0,1}",
        "fractional_rejected": True,
    }
    write_json(RESULTS / "verify_seed.json", payload)
    print(json.dumps(payload, indent=2))
    assert ids["different_binary"] and ids["same_binary"]
    assert ids["different_polynomials_equal_over_Z"] is False
    assert oracle.status == "UNSAT"
    assert pair_sat == ["SAT", "SAT", "SAT"]
    return 0


def cmd_test() -> int:
    loader = unittest.defaultTestLoader
    suite = loader.discover(str(ROOT / "tests"), pattern="test_*.py")
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    return 0 if result.wasSuccessful() else 1


def cmd_stage(stage: str) -> int:
    RESULTS.mkdir(parents=True, exist_ok=True)
    if stage == "smoke":
        instances = smoke_instances()
        records = run_panel(instances, "smoke", ("A", "B"), variants=())
        records += run_panel(instances, "smoke", ("C",), variants=VARIANTS, retain_xor=True)
    elif stage == "stress":
        instances = stress_instances()
        records = run_panel(instances, "stress", ("C",), variants=VARIANTS)
    elif stage == "stage1":
        instances = stage1_instances()
        records = run_panel(instances, "stage1", ("C",), variants=VARIANTS, retain_xor=True)
    elif stage in {"development", "evaluation"}:
        proto = load_protocol()
        seeds = list(proto[f"{stage}_seeds"])
        instances = panel_instances(split=stage, seeds=seeds)
        records = run_panel(instances, stage, ("A", "B"), variants=())
        records += run_panel(instances, stage, ("C",), variants=VARIANTS, retain_xor=True)
    else:
        raise SystemExit(f"unknown stage {stage}")
    write_json(RESULTS / f"{stage}.json", records)
    write_csv(RESULTS / f"{stage}.csv", records)
    summary = _summarize(records)
    write_json(RESULTS / f"{stage}_summary.json", summary)
    print(json.dumps(summary, indent=2))
    n_fail = summary["unsound"] + summary["failure"]
    return 0 if n_fail == 0 else 1


def cmd_stage2() -> int:
    star = (FIXTURES / "three_color_star.cnf").read_text(encoding="utf-8")
    plus = (FIXTURES / "three_color_star_plus_triangle.cnf").read_text(encoding="utf-8")
    payload = run_stage2(star, plus)
    write_json(RESULTS / "stage2.json", payload)
    print(json.dumps({k: payload[k] for k in payload if k != "overlapping_stars"}, indent=2, default=str))
    print("overlapping orders", list(payload["overlapping_stars"]["orders"]))
    ok = (
        payload["k3"]["extendable_triples"] == 21
        and payload["k3"]["relation_matches"]
        and payload["triangle_composition"]["exact_plus_triangle_unsat"]
        and payload["decoder_round_trip_extendable"]["ok"] == 21
        and payload["encoder_vs_star_fixture"]["clause_set_equal"]
    )
    return 0 if ok else 1


def cmd_controls() -> int:
    proto = load_protocol()
    limits = stage_limits(proto, "smoke", "W3")
    inst = triangle_fixture()
    base = compile_cnf(inst.dimacs, mode="C", limits=limits, variant="W3", cache_policy="cold")
    perm = {1: 2, 2: 3, 3: 1}
    rows = []
    for name, text in [
        ("base", inst.dimacs),
        ("rename", rename_cnf(inst.dimacs, perm)),
        ("complement", complement_cnf(inst.dimacs, {1})),
        ("reorder", reorder_cnf(inst.dimacs, 99)),
        ("duplicate", duplicate_some_clauses(inst.dimacs, 99)),
        ("tautology", add_tautologies(inst.dimacs, 99)),
    ]:
        r = compile_cnf(text, mode="C", limits=limits, variant="W3", cache_policy="cold")
        rows.append({"control": name, "status": r.status, "n_receipts": len(r.receipts)})
    write_json(RESULTS / "controls.json", {"base": base.status, "rows": rows})
    print(json.dumps({"base": base.status, "rows": rows}, indent=2))
    return 0


def cmd_unsafe() -> int:
    payload = triangle_unsafe_counterexample()
    write_json(RESULTS / "unsafe_ablation.json", payload)
    print(json.dumps(payload, indent=2))
    return 0 if payload["unsafe_unsound"] else 1


def cmd_watchdog() -> int:
    r = slow_stub(timeout_s=0.25, sleep_s=2.0)
    write_json(RESULTS / "watchdog.json", {"status": r.status, "seconds": r.seconds, "method": r.method, "skipped": r.skipped_reason})
    print(r.status, r.seconds)
    return 0 if r.status == "RESOURCE_LIMIT" else 1


def cmd_minimality() -> int:
    proto = load_protocol()
    limits = stage_limits(proto, "smoke", "W3")
    xor = xor3_odd()
    parsed = parse_dimacs(xor.dimacs)

    def stall_w3(text: str) -> bool:
        r = compile_cnf(text, mode="C", limits=limits, variant="W3", retain=[1, 2, 3], use_affine=False, cache_policy="cold")
        return not any(s.startswith("P:") for s in r.residual + r.recognized)

    original_stall = stall_w3(xor.dimacs)
    deletions = []
    from .dimacs import to_dimacs

    for i in range(len(parsed.clauses)):
        remaining = [c for j, c in enumerate(parsed.clauses) if j != i]
        text = to_dimacs(3, remaining)
        stall = stall_w3(text)
        # relation changed: 5 SAT rows vs 4
        deletions.append({"deleted_index": i, "selector_still_stalls_w3": stall, "relation_changed": True})
    payload = {
        "declared_property": "W3 does not replace the current factors by a PARITY atom",
        "original_4clause_stall": original_stall,
        "after_each_deletion": deletions,
        "minimality_of_relation": "the 4-clause XOR encoding is 1-minimal as an encoding of XOR=1",
        "minimality_of_stall": "stall remains after each single deletion (3 clauses are still not a grammar atom); deleting a clause therefore does not by itself prove stall-minimality of the selector",
    }
    write_json(RESULTS / "xor_stall_minimality.json", payload)
    print(json.dumps(payload, indent=2))
    return 0


def main(argv: list[str] | None = None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    if not argv:
        print(
            "usage: python run.py [hash|freeze|verify-seed|test|smoke|stress|stage1|stage2|panels --split development|evaluation|controls|unsafe|watchdog|minimality]"
        )
        return 2
    cmd = argv[0]
    dispatch = {
        "hash": cmd_hash,
        "freeze": cmd_freeze,
        "verify-seed": cmd_verify_seed,
        "test": cmd_test,
        "smoke": lambda: cmd_stage("smoke"),
        "stress": lambda: cmd_stage("stress"),
        "stage1": lambda: cmd_stage("stage1"),
        "stage2": cmd_stage2,
        "controls": cmd_controls,
        "unsafe": cmd_unsafe,
        "watchdog": cmd_watchdog,
        "minimality": cmd_minimality,
    }
    if cmd == "panels":
        split = "development"
        if "--split" in argv:
            split = argv[argv.index("--split") + 1]
        return cmd_stage(split)
    if cmd in dispatch:
        return dispatch[cmd]()
    print("unknown command", cmd)
    return 2
