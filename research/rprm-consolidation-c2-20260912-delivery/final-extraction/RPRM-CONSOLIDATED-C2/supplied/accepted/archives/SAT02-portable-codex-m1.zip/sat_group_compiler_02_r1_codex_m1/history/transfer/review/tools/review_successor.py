"""Bounded SAT02-R1 review: exposed fixtures, local checks and finite graph oracle.
No panel execution, installation, freeze, source mutation or new seed scoring.
"""
from __future__ import annotations
import argparse, copy, hashlib, importlib.util, itertools, json, platform, sys, tempfile, time
from pathlib import Path


def save(p, x):
    p.write_text(json.dumps(x, indent=2, sort_keys=True, default=str)+'\n')


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--experiment', type=Path, required=True)
    ap.add_argument('--original', type=Path, required=True)
    ap.add_argument('--prior-review', type=Path, required=True)
    ap.add_argument('--output',type=Path,required=True)
    a=ap.parse_args(); out=a.output;out.mkdir(parents=True,exist_ok=False)
    sys.dont_write_bytecode=True;sys.path.insert(0,str(a.experiment.resolve()))
    from sat_group_compiler.grouping import GroupBudget,iter_connected_groups
    from sat_group_compiler.ir import Factor, Kind
    from sat_group_compiler.compiler import compile_cnf
    from sat_group_compiler.protocol import load_protocol,stage_limits
    from sat_group_compiler.receipts import check_rewrite_receipt,receipt_payload
    from sat_group_compiler.fingerprints import source_sha256,source_file_hashes,write_json
    from sat_group_compiler.backends import get_probe
    proto=load_protocol()
    def lim(arm):
        d=dict(stage_limits(proto,'smoke',arm));d['max_seconds']=10;return d
    # Independent graph oracle. Every labelled undirected graph with 1..5 vertices
    # is realized as a factor incidence graph: a private variable per vertex plus
    # one shared variable per edge. No supplier graph-oracle helper is used.
    graph_count=comparisons=sets_checked=0;bad=[]
    for n in range(1,6):
        edges=list(itertools.combinations(range(n),2))
        for mask in range(1<<len(edges)):
            graph_count+=1
            adj=[set() for _ in range(n)];scopes=[{i+1} for i in range(n)]
            for e,(u,v) in enumerate(edges):
                if mask>>e&1:
                    adj[u].add(v);adj[v].add(u)
                    scopes[u].add(n+e+1);scopes[v].add(n+e+1)
            for order in [list(range(n)),list(reversed(range(n)))]:
                ids={v:1+i for i,v in enumerate(order)}
                fs=[Factor(id=ids[v],kind=Kind.CLAUSE,lits=tuple(sorted(scopes[v]))) for v in order]
                for cap in [n+len(edges), max(2,n)]:
                    want=set()
                    for k in range(2,min(4,n)+1):
                        for comb in itertools.combinations(range(n),k):
                            group=set(comb);seen={comb[0]};todo=[comb[0]]
                            while todo:
                                v=todo.pop()
                                for u in adj[v]&group-seen:seen.add(u);todo.append(u)
                            if seen==group and len(set().union(*(scopes[v] for v in group)))<=cap:
                                want.add(frozenset(ids[v] for v in group))
                    emitted=list(iter_connected_groups(fs,4,cap,GroupBudget(lambda:True,{})))
                    got=[frozenset(f.id for f in g) for g in emitted]
                    comparisons+=1;sets_checked+=len(want)
                    if set(got)!=want or len(got)!=len(set(got)):
                        bad.append({'n':n,'mask':mask,'order':order,'scope_cap':cap})
    save(out/'group_oracle.json',{'graphs':graph_count,'comparisons':comparisons,'expected_groups':sets_checked,'failures':bad,'scope':'Every labelled graph on 1..5 factors, forward/reverse IDs, two scope caps; sizes 2..4. Budget ample. No speed conclusion.'})
    # The earlier independent semantic interpreter is reused, not called a fresh
    # independent implementation. Correct its own omission of boundary preservation.
    spec=importlib.util.spec_from_file_location('prior_oracle',a.prior_review/'scripts/review_sat02.py')
    mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
    def independent(p):
        reasons=mod.independent_receipt(p)
        if p.get('eliminated'):
            rec=p.get('recovery') or {}; gone=set(p['eliminated'])
            if rec.get('type')=='closed_form':
                if set(map(int,rec.get('map',{})))!=gone:reasons.append('recovery_output_not_exactly_eliminated')
            if rec.get('type')=='lex_table':
                for row in rec.get('rows',[]):
                    if set(map(int,row.get('internal',{})))!=gone:reasons.append('recovery_output_not_exactly_eliminated')
        return sorted(set(reasons))
    # Replay saved receipts, not original solver panels or original runtimes.
    rn=0;old_bad=[];rejected=[];recovery_types={}
    for panel in ['smoke','stress','stage1','development','evaluation']:
        rows=json.loads((a.original/'results'/f'{panel}.json').read_text())
        for i,row in enumerate(rows):
            for j,p in enumerate(row.get('receipts',[])):
                rn+=1
                r=check_rewrite_receipt(p);err=independent(p)
                if not r['ok']:rejected.append({'panel':panel,'row':i,'receipt':j,'report':r})
                if err:old_bad.append({'panel':panel,'row':i,'receipt':j,'errors':err})
                typ=(p.get('recovery')or{}).get('type','none');recovery_types[typ]=recovery_types.get(typ,0)+1
    save(out/'saved_receipts_recheck.json',{'count':rn,'rejected':rejected,'independent_errors':old_bad,'recovery_types':recovery_types,'scope':'Replayed saved local receipts, not panel decisions. Earlier evaluator reused with explicit recovery-output check added.'})
    # Protected XOR with all sign complementations and three clause orders.
    xor='p cnf 3 4\n1 2 3 0\n1 -2 -3 0\n-1 2 -3 0\n-1 -2 3 0\n'
    positives=[]
    for arm in ('W3','W4','W3-T','W4-I'):
        r=compile_cnf(xor,mode='C',limits=lim(arm),variant=arm,retain=[1,2,3],use_affine=False)
        positives.append({'arm':arm,'status':r.status,'residual':r.residual,'recognized':r.recognized,'receipts':[receipt_payload(p) for p in r.receipts],'meter':r.meter.as_dict()})
    trials=[];cls=mod.parse_dimacs_independent(xor)[1]
    for bits in itertools.product((0,1),repeat=3):
        cs=[tuple(-l if bits[abs(l)-1] else l for l in c) for c in cls]
        for order in [(0,1,2,3),(3,2,1,0),(1,3,0,2)]:
            text='p cnf 3 4\n'+'\n'.join(' '.join(map(str,cs[i]))+' 0' for i in order)+'\n'
            for arm in ('W4','W3-T','W4-I'):
                r=compile_cnf(text,mode='C',limits=lim(arm),variant=arm,retain=[1,2,3],use_affine=False)
                pp=[s for s in r.residual if s.startswith('P:')]
                correct=bool(pp) and all(mod.atom_truth(pp[0],aa)==mod.clause_truth(cs,aa) for aa in mod.assignments([1,2,3]))
                trials.append({'bits':bits,'order':order,'arm':arm,'exact':correct})
    save(out/'xor_checks.json',{'base':positives,'transform_cases':len(trials),'transform_passed':sum(t['exact']for t in trials),'trials':trials})
    # Production receipt + original mutations and new retained-boundary attacks.
    r=compile_cnf('p cnf 2 2\n1 2 0\n-1 -2 0\n',mode='C',limits=lim('W3'),variant='W3',retain=[1],use_affine=False)
    base=receipt_payload(r.receipts[0]);cases=[]
    fixes={
        'correct_closed_form':base['recovery'],
        'wrong_X_eq_A':{'type':'closed_form','map':{'2':['lit',1]}},
        'missing':{},
        'empty_table':{'type':'lex_table','rows':[]},
        'incomplete_table':{'type':'lex_table','rows':[{'boundary':{'1':0},'internal':{'2':1}}]},
        'good_table':{'type':'lex_table','rows':[{'boundary':{'1':0},'internal':{'2':1}},{'boundary':{'1':1},'internal':{'2':0}}]},
        'closed_boundary_overwrite':{'type':'closed_form','map':{'1':['lit',-1],'2':['lit',-1]}},
        'closed_collapse_to_fixed_pair':{'type':'closed_form','map':{'1':['const',0],'2':['const',1]}},
        'table_boundary_overwrite':{'type':'lex_table','rows':[{'boundary':{'1':0},'internal':{'1':1,'2':0}},{'boundary':{'1':1},'internal':{'1':0,'2':1}}]},
    }
    for name,rec in fixes.items():
        p=copy.deepcopy(base);p['recovery']=rec
        cases.append({'name':name,'payload':p,'checker':check_rewrite_receipt(p),'independent_errors':independent(p)})
    p=copy.deepcopy(base);p['eliminated']=[1,2]
    cases.append({'name':'overlap_partition','payload':p,'checker':check_rewrite_receipt(p),'independent_errors':['scope_partition']})
    p=copy.deepcopy(base);p['input_factor_ids']=[999,1000]
    cases.append({'name':'unbound_original_ids','payload':p,'checker':check_rewrite_receipt(p),'note':'Accepted locally is intentional; binds_original_factor_ids must be false.'})
    save(out/'receipt_controls.json',{'base':base,'cases':cases})
    # Timer-boundary fault injection and certification-status gate.
    import sat_group_compiler.receipts as rr
    orig=rr.check_rewrite_receipt
    def delayed(p):time.sleep(.03);return orig(p)
    rr.check_rewrite_receipt=delayed
    try:
        t=time.perf_counter();r=compile_cnf(xor,mode='C',limits=lim('W4'),variant='W4',retain=[1,2,3],use_affine=False);elapsed=time.perf_counter()-t
    finally:rr.check_rewrite_receipt=orig
    timer={'injected_s_per_receipt':.03,'receipts':len(r.receipts),'receipt_check_s':r.meter.receipt_check_s,'wall_s':r.meter.wall_s,'outer_wall_s':elapsed,'scope':'Synthetic checker delay, not performance measurement.'}
    rr.check_rewrite_receipt=lambda p:{'ok':False,'grade':'rejected','reasons':['INJECTED_REVIEW_FAILURE']}
    try:r=compile_cnf(xor,mode='C',limits=lim('W4'),variant='W4',retain=[1,2,3],use_affine=False)
    finally:rr.check_rewrite_receipt=orig
    timer['failure_grade']=r.claim_grade;timer['failure_status']=r.status
    save(out/'timer_and_grade.json',timer)
    # Actual copied-tree digest remains stable when its output record is written.
    import shutil
    with tempfile.TemporaryDirectory() as td:
        copy_root=Path(td)/'tree';shutil.copytree(a.experiment,copy_root)
        before=source_sha256(copy_root)
        write_json(copy_root/'versions.json',{'source_sha256':before})
        after=source_sha256(copy_root)
        fs={'before':before,'after':after,'stable':before==after,'versions_in_inputs':'versions.json' in source_file_hashes(copy_root)}
    save(out/'fingerprint_check.json',fs)
    # Independent native star / two-star count: explicit existential variables.
    star=0;pairprojs=[set(),set(),set()]
    for aa,bb,cc in itertools.product(range(3),repeat=3):
        valid=any(xx not in (aa,bb,cc) for xx in range(3));star+=valid
        if valid:
            for i,pair in enumerate([(aa,bb),(aa,cc),(bb,cc)]):pairprojs[i].add(pair)
    conj=union=0;agree=True
    for aa,bb,cc,dd,ee in itertools.product(range(3),repeat=5):
        joint=(len({aa,bb,cc})<=2 and len({cc,dd,ee})<=2)
        exists=any(xx not in (aa,bb,cc) and yy not in (cc,dd,ee) for xx in range(3)for yy in range(3))
        conj+=joint;union+=len({aa,bb,cc,dd,ee})<=2;agree &= joint==exists
    save(out/'native_check.json',{'star_accepts':star,'star_domain':27,'pair_projection_sizes':list(map(len,pairprojs)),'two_star_domain':243,'conjunction_accepts':conj,'union_atom_accepts':union,'matches_original_elimination':agree})
    probe=get_probe()
    save(out/'environment.json',{'python':sys.version,'platform':platform.platform(),'executable':sys.executable,'probe':{k:probe.get(k)for k in ['pysat','affine','closure_sat','stdlib_gf2','errors']},'no_panels_executed':True,'no_new_seeds_scored':True})
    assert not bad and not old_bad
    # Some submitted-R1 empty-relation receipts are falsely rejected. Record
    # them as a finding; candidate acceptance is checked separately.
    assert len(trials)==72 and all(t['exact']for t in trials)
    assert star==21 and conj==147 and union==93 and agree and fs['stable']
    assert timer['failure_grade']=='receipt_rejected' and timer['receipt_check_s']>=.025 and timer['wall_s']>=timer['receipt_check_s']
    print(json.dumps({'graphs':graph_count,'graph_checks':comparisons,'receipts':rn,'xor':len(trials),'control_accepts':{c['name']:c['checker']['ok']for c in cases}},indent=2))

if __name__=='__main__':main()
