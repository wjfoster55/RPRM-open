# SAT02 portable Codex M1

This is the active maintenance successor. The accepted partial research result is
unchanged. M1 integrates the reviewed local-checker repair with one small additional
guard for retained-variable writes when no variables are eliminated. The production
change is confined to `sat_group_compiler/receipts.py`; compiler, grouping, scoring,
protocol and seed code are byte-identical to submitted R1.

The integrated checker was tested before export. The final exported ZIP must be
verified from a fresh extraction; that completed replay is reported in the paired
`SAT02-codex-m1-final-evidence.zip` and `CODEX_M1_REVIEW_AND_CLOSEOUT.md`, outside this
hashed build. `M1_INTEGRATION.json` and `M1_MANIFEST.json` identify the current bytes.
The manifest binds bytes, not mathematical truth.

## Portable verification

Use Python 3.10 or newer with assertions enabled. M1 was verified on CPython 3.14.5.
No installation is needed for these checks. The inherited `requirements.txt` names
an optional original performance backend; it is historical and is not needed here.
`portable_check.py` delegates to the unchanged `run.py test` entrypoint, unittest
discovery for the supplied six tests, and the supplied bounded review script. Its
import guard prevents the inherited backend probe from loading hard-coded local
NariZoo modules or installed packages. Python's standard library is the runtime;
all project and review dependencies are delivered here.

From the extracted build, choose a fresh external evidence directory. For example
in PowerShell (if `../m1-replay` already exists, choose a different fresh name):

```powershell
New-Item -ItemType Directory -Path ../m1-replay
python -I -S -B portable_check.py manifest --environment ../m1-replay/manifest-environment.json
python -I -S -B portable_check.py tests --environment ../m1-replay/tests-environment.json
python -I -S -B portable_check.py regressions --environment ../m1-replay/six-environment.json
python -I -S -B portable_check.py review --output ../m1-replay/review --environment ../m1-replay/review-environment.json
python -I -S -B portable_check.py rows --output ../m1-replay/rows --environment ../m1-replay/rows-environment.json
python -I -S -B portable_check.py manifest --environment ../m1-replay/manifest-after-environment.json
```

`tests` discovers 79 = 73 unchanged original tests + six unchanged supplied review
regressions. `regressions` reruns that same six-case subset, not six further tests.
`review` reuses the supplied finite graph, XOR, native-color and receipt checks; its
exit code alone does not require zero receipt rejections. Inspect its actual JSON.
`rows` writes all 982 outcomes and 23 targeted control rows and requires the expected
accepts/rejects, zero rejected saved receipts, zero independent errors, and unchanged
local-only scope flags. The controls are diagnostics, not additional experiments.
Saved rows are read directly from `saved/results/`; no panels or seeds are generated.

## Current scope and history

Recovery on a nonempty Boolean local relation must extend the same retained boundary
and write only eliminated variables. Recomputed emptiness needs no reconstruction
witness; the stored mask and FALSE projection still must agree with the input.
This is local relation/recovery checking: `binds_original_factor_ids=False` and
`whole_solver_derivation_replayed=False` remain explicit. General parser hardening,
arbitrary future receipt grammars and whole-solver derivations are outside M1.

`history/transfer/` is the complete immutable received handoff, including frozen R1,
the three original input archives, the reviewed candidate, historical results and
the old status overlay. Its imperative documents are historical source material;
they are not a new assignment. Frozen R1 remains separate from this active build.
Root `HASHES.json`, `OWNER_RETURN.md`, `RESULT_STATUS.json`, `PATCH_APPLICATION.json`
and inherited protocol/seed records are preserved historical records. In particular,
`PATCH_APPLICATION.json` records the intermediate candidate application, not current
integration status. Original README and claim ledger are in `history/transfer/frozen_r1/`.
Use this README, the current `CLAIM_LEDGER.md`, `M1_INTEGRATION.json` and
`maintenance/M1_STATUS.md` for M1.

Keep 6 RUN / 4 NOT_RUN. Keep W3-T 15→18 then 23→6 as a local structural route; the
three-color star has 21/27 extensions and pair projections of size 9. The correct
two-factor conjunction accepts 147/243; the wrong union atom accepts 93/243.
Comparative speed, complete work budget, ten-seed completion, original dispatch
authentication, whole-solver proof, a new tractable SAT family and P versus NP
claims remain withdrawn or unclaimed. Unavailable historical logs stay unavailable.

C1, Lind–Reichardt and AD 14/16 versus 14/16 stay closed. Fluid and Yang–Mills stay
undispatched. No Task03, panel rerun, seed backfill, general rewrite, installation,
commit, push, merge, publication or other-lane dispatch is part of this build.
