# SAT02-R1: partial research closeout, with two remaining local-checker issues

**12 September 2026.** Review of the uploaded `sat_group_compiler_02_r1.zip`, SHA-256 `26c17cb940a599afecb08f16c993a4f646aa347138a59812ea70aaa326dc155a`.

## Decision

Accept the **partial research closeout**, the exact XOR/temporary-table and three-color specimens, the connected-group repair, the timer-boundary correction, and the version-output fingerprint correction. Preserve the missing seeds as NOT_RUN and the withdrawn comparative/certification claims.

Do **not** accept “the local receipt checker is repaired” without qualification. The submitted checker still permits recovery to overwrite retained variables, and it rejects legitimate empty local relations for lacking a witness. These are two small, directly relevant checker defects, not a new failure of the saved SAT answers or a reason to reopen the research program.

A one-file reviewer candidate fixes those two boundaries and passes the bounded rechecks below. It is supplied separately, **not integrated into the user's workspace, uploaded R1 ZIP, or official export**. No Task03 or new benchmark is requested.

## Sources and execution scope

The uploaded successor was safely extracted separately from the original SAT02 ZIP and the previous review package. Current-conversation originals were used; no repositories, other chats, external websites or missing local Windows directories were substituted.

The original archive remains SHA-256 `a32587d9657ce87366632c8bd93c25bff757b5ac575bda8dfde76602bd26b9ea`. The previous review ZIP matches the owner's reported identity. Nineteen of the owner's selective hash records match the available source files; the twentieth is an original-workspace status overlay that was not delivered. That absent overlay is not needed to execute the successor. This is not an audit of the user's live unuploaded workspace.

The successor has 52 payload files. The three copied protocol files match the original bytes; the JSON protocol's canonical digest remains `2d94c1895d2c5a61b82c2d3e7eb7a45e1f5acc42be633a7f83a1d88b1ea29bb9`. Its raw-file digest is a different quantity, recorded separately. R1 does not contain the old panel payloads; they remain available in the separate original ZIP. Neither archive was changed.

Only existing tests, exposed fixtures, finite validation oracles and injected checker faults were executed. There was no panel generation/scoring, no omitted-seed execution, no package installation, no commit and no dispatch of another lane. Optional original PySAT/NariZoo backends were not reproduced. New environment and full outputs are in `results/`.

## Verified results

| Check | New review result |
|---|---|
| Original supplied unit suite | 57/57 pass |
| R1 supplied unit suite | 73/73 pass |
| Group enumeration | 4,396 comparisons pass across all 1,099 labelled undirected graphs with 1–5 factors, forward/reverse IDs and two scope caps |
| Protected XOR variants | 72/72 exact parity checks pass, including variable complementations and clause reordering |
| W3-T route | The actual API retains temporary TABLE cost 15→18, then parity cost 23→6 |
| Three-color star | 21/27 boundary assignments extend; all three pair projections have size 9 |
| Two overlapping stars | Original elimination matches the two-factor conjunction on all 243 assignments; 147 accepted versus 93 for the incorrect single union atom |
| Timer correction | A controlled 30 ms checker delay is included in reported `wall_s`; this is a boundary diagnostic, not a speed measurement |
| Certification disposition | Injecting a failed local receipt changes the result's claim grade to `receipt_rejected` |
| Fingerprint correction | Writing `versions.json` in a disposable copy leaves the successor source digest unchanged |

The graph oracle does not call the supplier's `connected_subsets_oracle` or connectivity helper. It explicitly traverses each induced graph and compares every allowed subset, checking duplicates as well as omissions. The 4,396 comparisons are related finite validation cases, not independent scientific trials or an asymptotic result. A connected set can be built from its minimum-ID member by repeatedly adding an adjacent unused member. Restricting additions to IDs above that minimum does not exclude a member of the target set; the old restriction above the most recently added ID did. Monotone scope pruning preserves this argument. Completeness is conditional on not stopping early for resource caps.

The saved local receipts were checked with both the successor and the prior reviewer interpreter augmented with a recovery-output-scope check. All **982** remain mathematically valid within that bounded interpretation. The submitted R1 checker accepts **932** and falsely rejects **50**; the precise cause is below. These are saved receipt replays, not fresh executions of the original panels or a whole-chain proof.

## Remaining issue 1: recovery must extend the same boundary

An actual compiler receipt eliminates X from A≠X while retaining A. Its correct recovery is X=1−A.

The old `X=A`, missing recovery, empty/incomplete table and overlapping partition mutations are now rejected. The repaired checker is genuinely stronger than SAT02's original checker.

However, a closed-form recovery is permitted to write A as well as X. For example, it can first replace A by 1−A, then set X=1−A using that changed A. When supplied A=0, it returns A=1, X=0. That pair satisfies A≠X, so the checker accepts it—but it is not an extension of the boundary A=0. An outside constraint requiring A=0 would be broken.

The table form has the same flaw: an `internal` dictionary can contain the supposedly retained A. The merge overwrites the input before evaluating the original relation. Both of these supplied mutations receive `local_relation_checked` in R1. Another accepted mutation collapses both possible inputs to the fixed satisfying pair A=0, X=1.

The missing condition is not another SAT algorithm. For each admissible retained assignment b, a recovery must produce a satisfying assignment **whose restriction to the boundary is still b**. Producing some satisfying pair elsewhere in the relation is insufficient.

Evidence: `results/independent/receipt_controls.json` and the minimal regression file under `candidate_patch/`.

## Remaining issue 2: an empty relation has no witnesses to reconstruct

Fifty saved receipts describe a correctly identified empty local relation, project it to FALSE, and supply no reconstruction. All have recomputed satisfying mask zero, promise C, replacement FALSE, and empty recovery.

R1 nevertheless returns `recovery_missing`. For example, `A=X AND (A OR X) AND (NOT A OR NOT X)` is impossible. There is no satisfying boundary assignment on which recovery must act, so that obligation is vacuous. The empty input/projection equality still has to be checked; the candidate does not trust an asserted zero mask.

These are not fifty wrong UNSAT results. They are fifty valid local contradiction receipts that the newer checker unnecessarily rejects. The earlier review's accepted mathematics remains intact.

## One-file candidate and its evidence

`candidate_patch/receipts.py` changes only `sat_group_compiler/receipts.py`:

1. Recovery is required only when the **recomputed** local relation is nonempty.
2. Recovery output keys must be exactly the eliminated variables; retained or unrelated variables cannot be overwritten.
3. Recovered values must remain Boolean, and closed-form outputs are explicitly checked to preserve the original boundary.

The candidate is hash-pinned and provided as both a complete replacement and a small diff. The six focused regressions fail in three places against unmodified R1 and all pass against the candidate. The candidate also preserves all 73 existing tests, all 72 protected-XOR checks, all 4,396 graph checks, and accepts all **982/982** saved local receipts without changing them. Wrong stored masks, wrong TRUE-for-empty replacements and the previous missing/wrong witness mutations remain rejected.

This is not a comprehensive adversarial parser audit, a verified whole-solver proof, original-factor-ID binding, or validation of arbitrary future receipt grammars. The checker explicitly continues to say that it does not provide those guarantees. The patch does not alter compilation, grouping, protocols, workload budgets or old results.

The first reviewer script assumed no saved receipts would be rejected and stopped at its final assertion when it found the 50 empty-relation rejections. That initial output is preserved. A first candidate text replacement also failed safely at a CRLF/LF precondition, before changing a file; its accidental duplicate unpatched diagnostic is labelled in `results/REVIEWER_RUN_NOTE.md`. The actual patched and tested candidate is the one identified by `candidate_patch/PATCH_IDENTITY.json`, with results under `results/candidate_02/`. No failed reviewer work has been relabelled as a successful candidate run.

## What closes and what does not

**Closed as partial research:** the exact local specimens and the disclosed six-of-ten-seed execution. Preserve the reported panels as descriptive development evidence; do not rerun or backfill them to turn this into a stronger benchmark.

**Verified implementation corrections:** connected group coverage within finite tests and its stated traversal argument; inclusion of receipt checks in the candidate timer; exclusion of the generated versions record from the source digest; appropriate whole-proof claim downgrade.

**Still limited in submitted R1:** local checker acceptance, with the two concrete defects above. The reviewer candidate closes those reproductions but is not yet the owner's integrated build. It may be retained as a patch or integrated as a narrow maintenance action before the checker is relied on. No further scientific experiment is required for this decision.

**Still unclaimed:** complete work budgets, clean method-speed ranking, all ten seeds, authenticated original dispatch, complete solver derivation checking, a new tractable SAT class or a P versus NP result. Keeping exact temporary relations and recovery records has real costs; the local 15→18→6 structural score is not elapsed time or a general speedup.

C1, Lind–Reichardt and AD 14/16 remain closed. Fluid and Yang–Mills remain undispatched in this review. Nothing here launches Task03.
