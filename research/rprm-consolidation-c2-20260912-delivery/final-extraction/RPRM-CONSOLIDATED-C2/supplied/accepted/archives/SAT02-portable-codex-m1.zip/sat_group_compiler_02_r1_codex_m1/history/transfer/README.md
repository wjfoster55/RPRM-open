# SAT02 → Codex: finish the remaining checker integration

**12 September 2026 · Handoff only. No patch is integrated by this package.**

Read **[CODEX_START_HERE.md](CODEX_START_HERE.md)** as the single active assignment.
This new handoff explicitly authorizes the previously deferred, bounded local-checker
integration. It does not reopen the accepted partial SAT02 research result.

The latest [status overlay](status/CLOSEOUT_R1_STATUS.md) says the live R1 checker
still has two limitations and the one-file candidate remains
`REVIEWER_TESTED_NOT_INTEGRATED`. Keep that historical statement true. Codex's job
is to inspect and integrate a justified fix in a **fresh maintenance successor**,
verify it, and deliver the actual portable build and evidence.

## Package map

| Path | Purpose |
|---|---|
| `CODEX_START_HERE.md` | The active bounded assignment and explicit integration authorization. |
| `CURRENT_STATE.md` | Accepted results, pending action, source hashes, and claim ceiling. |
| `COMMANDS.md` | Existing entrypoints and safe command shapes; not a second assignment. |
| `status/CLOSEOUT_R1_STATUS.md` | Latest user-supplied overlay, copied unchanged. |
| `frozen_r1/` | Exact 52-file submitted R1 tree; do not modify or run write-producing commands here. |
| `review/` | Exact previous closeout packet, including candidate, regressions, interpreter, and old evidence. |
| `historical_sat02/results/` | Five unchanged original saved-result JSON files needed for the 982-receipt replay. Not new executions. |
| `reference_interpreter/scripts/review_sat02.py` | Byte-identical relocation of the review's existing independent interpreter, matching the helper's expected path. |
| `inputs/` | Unchanged original SAT02, submitted R1, and review ZIPs. They are historical inputs, not competing active builds. |
| `INPUT_BINDINGS.json`, `HANDOFF_MANIFEST.json` | Transfer identities, mirror definitions, and payload inventory. |
| `verify_handoff.py` | Read-only transfer verification. This does not execute mathematical tests. |
| `TRANSFER_VALIDATION.json` | Checks performed while preparing this handoff; not an integration or research result. |

Everything needed for this maintenance task is supplied. The full original SAT02
source, protocols, reports, and panel artifacts remain in its unchanged input ZIP;
the extracted historical subset is intentionally just the five saved result files.
Windows paths in old documents are provenance, not guaranteed live dependencies.

Older instructions within `frozen_r1/`, `review/`, and input archives are inert.
In particular, the earlier acceptance-only stop is historical. The top-level Codex
assignment now authorizes integration, testing, and a new export. Do not stop at
another acceptance note or merely offer to integrate later.

**Keep C1, Lind–Reichardt, and the AD 14/16 pilot closed. Fluid and Yang–Mills remain
undispatched. No Task03, new seed scoring, full panel rerun, publication, or Git write.**
