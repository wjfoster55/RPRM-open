# V1 errata (bounded; v1 sources were not edited)

These notes refer to `experiments/sat_group_compiler_01` as frozen. Reproduction used `handoff/review_checks.py` against that tree on 11 September 2026. Host times are not the finding; the bypasses are.

## Reproduced review findings

| Item | Evidence | v2 repair |
| --- | --- | --- |
| Eager pair/triple scan | 70 disjoint binaries: `raw_pairs_plus_triples=57155`, `candidates_examined=0`, `status=UNRESOLVED`, `skipped=[]`, `elapsed_s≈0.40` under `max_seconds=0.01` | Incidence-driven lazy generation; budget checks during generation; over-budget is `RESOURCE_LIMIT` |
| Hard-coded scope/group size | `compiler.py:_enum_groups` used `<= 6` and pair/triple loops | `max_scope` / `max_factors` from `protocol_v2.json` + variant |
| Overlapping `selection_s` | recognition time included in selection | exclusive `recognition_s` vs `selection_s` |
| `_finish` ignored `t0` | no `wall_s` | `meter.wall_s = now - t0` |
| Hybrid double-count / omitted preprocess | `cli.py:hybrid_arm` | `preprocess_s + residual_solve_s + lift_s` once each |
| PySAT timeout after `solve()` | `backends.py:pysat_sat` | killable worker; slow-stub watchdog test |
| Incomplete table accounting | `group_sat_masks` only | template / projection / validation / recovery rows charged |
| Approximate proof bytes | formula on promise strings | actual JSON serialization of receipts and recoveries |
| Missing initial IR peak | peak started after simplify | `initial_ir_bytes` before native close |
| Shared template cache | sequential A/B/C could warm C | default `cache_policy=cold` |
| Protocol hash only | affine import repair did not change v1 protocol hash | source + config + dependency fingerprints |
| Validation string as proof | receipts recorded `"group_truth_table_boundary"` | independent `check_rewrite_receipt`; string is not authority |
| XOR four-factor diagnostic | unprotected → `TRUE` (SAT); retain `{1,2,3}` → `P:1,2,3=1` while affine off left `UNRESOLVED` | recognition scored separately from solving; W4/W3-T/W4-I tested |
| Stress B decisive / C limited | eight cycle/graph ids | reported as regressions, not “C always matches B” |
| Stall “minimality” | deleting a clause changes the XOR relation | property declared and rerun on each deletion (`results/xor_stall_minimality.json`) |
| 2-SAT/Horn need a family label | too strong | syntactic `classify_cnf` is computed work |
| `idx[v]` vs `idx[w]` in Tarjan | v1 used `idx[w]`; a v2 draft typo `idx[v]` falsely SAT-labeled odd cycles | restored `idx[w]` and checked models |

## Not claimed

No unsound SAT/UNSAT was found in the supplied v1 panel JSON (`reported_unsound=0`). These are measurement, budget, and claim-scope defects.
