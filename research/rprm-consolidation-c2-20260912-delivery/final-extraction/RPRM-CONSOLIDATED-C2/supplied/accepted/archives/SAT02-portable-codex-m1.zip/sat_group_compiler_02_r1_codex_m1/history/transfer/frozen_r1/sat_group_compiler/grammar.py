"""Grammar recognition from fixed-scope truth tables (n bounded by config)."""

from __future__ import annotations

from itertools import combinations

from .ir import Factor, Kind, Promise, canon_factor_payload, factor_holds

_ATOM_CACHE: dict[int, list[tuple[Factor, int]]] = {}
_TEMPLATE_ROWS: dict[int, int] = {}


def clear_atom_cache() -> None:
    _ATOM_CACHE.clear()
    _TEMPLATE_ROWS.clear()


def cache_is_warm() -> bool:
    return bool(_ATOM_CACHE)


def cached_arities() -> list[int]:
    return sorted(_ATOM_CACHE)


def clause_from_lits(lits: tuple[int, ...], fid: int = -1) -> Factor | None:
    seen: set[int] = set()
    cleaned: list[int] = []
    for lit in lits:
        if lit in seen:
            continue
        if -lit in seen:
            return Factor(id=fid, kind=Kind.TRUE, promise=Promise.A)
        seen.add(lit)
        cleaned.append(lit)
    if not cleaned:
        return Factor(id=fid, kind=Kind.FALSE, promise=Promise.A)
    if len(cleaned) == 1:
        return Factor(id=fid, kind=Kind.UNIT, lits=(cleaned[0],), promise=Promise.A)
    ordered = tuple(sorted(cleaned, key=lambda lit: (abs(lit), lit < 0)))
    return Factor(id=fid, kind=Kind.CLAUSE, lits=ordered, promise=Promise.A)


def group_sat_masks(factors: list[Factor], scope: tuple[int, ...], meter: dict[str, int]) -> int:
    n = len(scope)
    observed = 0
    universe = 1 << n
    for mask in range(universe):
        meter["table_rows"] = meter.get("table_rows", 0) + 1
        assignment = {scope[i]: (mask >> i) & 1 for i in range(n)}
        if all(factor_holds(factor, assignment) for factor in factors):
            observed |= 1 << mask
    return observed


def _mask_for_atom(atom: Factor, scope: tuple[int, ...]) -> int:
    n = len(scope)
    observed = 0
    for mask in range(1 << n):
        assignment = {scope[i]: (mask >> i) & 1 for i in range(n)}
        if factor_holds(atom, assignment):
            observed |= 1 << mask
    return observed


def _remap_atom(atom: Factor, scope: tuple[int, ...]) -> Factor:
    def mv(var: int) -> int:
        return scope[var - 1]

    def ml(lit: int) -> int:
        return (1 if lit > 0 else -1) * mv(abs(lit))

    if atom.kind in (Kind.TRUE, Kind.FALSE):
        return atom
    if atom.kind in (Kind.SAME, Kind.DIFFERENT, Kind.PARITY):
        return Factor(id=-1, kind=atom.kind, lits=tuple(mv(v) for v in atom.lits), parity=atom.parity)
    return Factor(id=-1, kind=atom.kind, lits=tuple(ml(lit) for lit in atom.lits), parity=atom.parity)


def _build_templates(n: int) -> list[tuple[Factor, int]]:
    local = tuple(range(1, n + 1))
    atoms: list[Factor] = [
        Factor(id=-1, kind=Kind.TRUE),
        Factor(id=-1, kind=Kind.FALSE),
    ]
    for var in local:
        atoms.append(Factor(id=-1, kind=Kind.UNIT, lits=(var,)))
        atoms.append(Factor(id=-1, kind=Kind.UNIT, lits=(-var,)))
    for a, b in combinations(local, 2):
        atoms.append(Factor(id=-1, kind=Kind.SAME, lits=(a, b)))
        atoms.append(Factor(id=-1, kind=Kind.DIFFERENT, lits=(a, b)))
    for bits in range(1, 1 << n):
        vars_ = tuple(local[i] for i in range(n) if bits >> i & 1)
        if len(vars_) < 2:
            continue
        atoms.append(Factor(id=-1, kind=Kind.PARITY, lits=vars_, parity=False))
        atoms.append(Factor(id=-1, kind=Kind.PARITY, lits=vars_, parity=True))
    states: list[tuple[int, ...]] = [()]
    for var in local:
        grown: list[tuple[int, ...]] = []
        for prev in states:
            grown.append(prev)
            grown.append(prev + (var,))
            grown.append(prev + (-var,))
        states = grown
    for lits in states:
        if len(lits) < 2:
            continue
        atoms.append(Factor(id=-1, kind=Kind.AMO, lits=lits))
        atoms.append(Factor(id=-1, kind=Kind.XO, lits=lits))
        if not any(-lit in lits for lit in lits):
            clause = clause_from_lits(lits)
            if clause is not None and clause.kind is Kind.CLAUSE:
                atoms.append(clause)
    rows = 0
    cached: list[tuple[Factor, int]] = []
    for atom in atoms:
        rows += 1 << n
        cached.append((atom, _mask_for_atom(atom, local)))
    _TEMPLATE_ROWS[n] = rows
    return cached


def ensure_templates(n: int, meter: dict[str, int] | None = None) -> list[tuple[Factor, int]]:
    if n not in _ATOM_CACHE:
        _ATOM_CACHE[n] = _build_templates(n)
        if meter is not None:
            meter["template_construction_rows"] = meter.get("template_construction_rows", 0) + _TEMPLATE_ROWS[n]
            meter["template_cache_misses"] = meter.get("template_cache_misses", 0) + 1
    else:
        if meter is not None:
            meter["template_cache_hits"] = meter.get("template_cache_hits", 0) + 1
    return _ATOM_CACHE[n]


def _iter_atoms(scope: tuple[int, ...], meter: dict[str, int] | None = None) -> list[tuple[Factor, int]]:
    n = len(scope)
    templates = ensure_templates(n, meter)
    return [(_remap_atom(atom, scope), mask) for atom, mask in templates]


def extract_units(scope: tuple[int, ...], sat_mask: int, meter: dict[str, int] | None = None) -> tuple[list[Factor], tuple[int, ...], int]:
    n = len(scope)
    units: list[Factor] = []
    free_idx: list[int] = []
    for i, var in enumerate(scope):
        seen0 = False
        seen1 = False
        for mask in range(1 << n):
            if meter is not None:
                meter["projection_rows"] = meter.get("projection_rows", 0) + 1
            if not (sat_mask >> mask) & 1:
                continue
            if (mask >> i) & 1:
                seen1 = True
            else:
                seen0 = True
            if seen0 and seen1:
                break
        if seen0 and not seen1:
            units.append(Factor(id=-1, kind=Kind.UNIT, lits=(-var,)))
        elif seen1 and not seen0:
            units.append(Factor(id=-1, kind=Kind.UNIT, lits=(var,)))
        else:
            free_idx.append(i)
    if not free_idx:
        return units, (), sat_mask
    free_scope = tuple(scope[i] for i in free_idx)
    projected = 0
    for mask in range(1 << n):
        if meter is not None:
            meter["projection_rows"] = meter.get("projection_rows", 0) + 1
        if not (sat_mask >> mask) & 1:
            continue
        new = 0
        for j, i in enumerate(free_idx):
            if (mask >> i) & 1:
                new |= 1 << j
        projected |= 1 << new
    return units, free_scope, projected


def project_mask(scope: tuple[int, ...], sat_mask: int, keep: tuple[int, ...], meter: dict[str, int] | None = None) -> int:
    index = {var: i for i, var in enumerate(scope)}
    keep_idx = [index[var] for var in keep]
    n = len(scope)
    projected = 0
    for mask in range(1 << n):
        if meter is not None:
            meter["projection_rows"] = meter.get("projection_rows", 0) + 1
        if not (sat_mask >> mask) & 1:
            continue
        new = 0
        for j, i in enumerate(keep_idx):
            if (mask >> i) & 1:
                new |= 1 << j
        projected |= 1 << new
    return projected


def lex_completion(
    scope: tuple[int, ...],
    sat_mask: int,
    boundary: tuple[int, ...],
    internal: tuple[int, ...],
    boundary_asg: dict[int, int],
    meter: dict[str, int] | None = None,
) -> dict[int, int] | None:
    n = len(scope)
    best: dict[int, int] | None = None
    for mask in range(1 << n):
        if meter is not None:
            meter["recovery_rows"] = meter.get("recovery_rows", 0) + 1
        if not (sat_mask >> mask) & 1:
            continue
        assignment = {scope[i]: (mask >> i) & 1 for i in range(n)}
        if any(assignment[var] != boundary_asg[var] for var in boundary):
            continue
        internal_asg = {var: assignment[var] for var in internal}
        if best is None or tuple(internal_asg[v] for v in internal) < tuple(best[v] for v in internal):
            best = internal_asg
    return best


def closed_form_recovery(
    scope: tuple[int, ...],
    sat_mask: int,
    boundary: tuple[int, ...],
    internal: tuple[int, ...],
    meter: dict[str, int] | None = None,
) -> dict[int, tuple[str, int]] | None:
    n = len(scope)
    if not internal:
        return {}
    rows: list[dict[int, int]] = []
    for mask in range(1 << n):
        if meter is not None:
            meter["recovery_rows"] = meter.get("recovery_rows", 0) + 1
        if not (sat_mask >> mask) & 1:
            continue
        rows.append({scope[i]: (mask >> i) & 1 for i in range(n)})
    if not rows:
        return None
    mapping: dict[int, tuple[str, int]] = {}
    for var in internal:
        values = {row[var] for row in rows}
        if len(values) == 1:
            mapping[var] = ("const", next(iter(values)))
            continue
        found = None
        for b in boundary:
            col_eq = all(row[var] == row[b] for row in rows)
            col_neg = all(row[var] == 1 - row[b] for row in rows)
            if col_eq:
                found = ("lit", b)
                break
            if col_neg:
                found = ("lit", -b)
                break
        if found is None:
            return None
        mapping[var] = found
    return mapping


def recognize(
    scope: tuple[int, ...],
    sat_mask: int,
    meter: dict[str, int],
) -> list[Factor] | None:
    n = len(scope)
    full_mask = (1 << (1 << n)) - 1
    if sat_mask == 0:
        return [Factor(id=-1, kind=Kind.FALSE)]
    if sat_mask == full_mask:
        return [Factor(id=-1, kind=Kind.TRUE)]

    units, free_scope, rem = extract_units(scope, sat_mask, meter)
    if not free_scope:
        return units or [Factor(id=-1, kind=Kind.TRUE)]

    best: list[Factor] | None = None
    best_cost: int | None = None
    best_canon: str | None = None
    n_free = len(free_scope)
    templates = ensure_templates(n_free, meter)
    for atom, expected in templates:
        meter["recognition_atoms"] = meter.get("recognition_atoms", 0) + 1
        if expected != rem:
            continue
        atom = _remap_atom(atom, free_scope)
        cleaned = [canon_factor_payload(atom)]
        if atom.kind is Kind.TRUE:
            cleaned = []
        if atom.kind is Kind.FALSE:
            return [Factor(id=-1, kind=Kind.FALSE)]
        combined = [canon_factor_payload(u) for u in units] + cleaned
        cost = sum(f.structural_cost() for f in combined)
        key = "|".join(f.canon_string() for f in combined)
        if (
            best is None
            or cost < best_cost
            or (cost == best_cost and key < best_canon)  # type: ignore[operator]
        ):
            best = combined
            best_cost = cost
            best_canon = key
    if best is None:
        return None
    return best


def table_factor(scope: tuple[int, ...], sat_mask: int, fid: int = -1) -> Factor:
    return Factor(id=fid, kind=Kind.TABLE, lits=scope, table_mask=sat_mask)
