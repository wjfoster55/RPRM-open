"""Grouped-representation compiler candidate. No SAT solver imports."""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
import json
import time
from typing import Any

from .arithmetic import penalty_from_clauses
from .dimacs import DimacsError, parse_dimacs
from .fingerprints import peak_process_rss_bytes
from .grammar import (
    clause_from_lits,
    clear_atom_cache,
    cache_is_warm,
    closed_form_recovery,
    group_sat_masks,
    lex_completion,
    project_mask,
    recognize,
    table_factor,
)
from .grouping import GroupBudget, iter_connected_groups, iter_same_support_groups, live_factors
from .ir import (
    Factor,
    Kind,
    Promise,
    canon_factor_payload,
    canonical_json_bytes,
    cnf_holds,
    factor_holds,
    ir_bytes,
    ir_hash,
    live_vars,
    total_cost,
)
from .receipts import serialized_receipts_bytes
from .signed_uf import SignedUF


@dataclass
class Meter:
    tuples_proposed: int = 0
    groups_emitted: int = 0
    starts_considered: int = 0
    discarded_disconnected: int = 0
    discarded_scope: int = 0
    adjacency_pairs: int = 0
    index_hits: int = 0
    index_buckets: int = 0
    candidates_examined: int = 0
    candidates_rejected: int = 0
    speculation_routes: int = 0
    speculation_rejected: int = 0
    temp_table_candidates_before_truncation: int = 0
    temp_tables_created: int = 0
    temp_tables_rejected: int = 0
    table_rows: int = 0
    template_construction_rows: int = 0
    template_cache_hits: int = 0
    template_cache_misses: int = 0
    projection_rows: int = 0
    validation_rows: int = 0
    recovery_rows: int = 0
    recognition_atoms: int = 0
    rewrites: int = 0
    cost_increasing_rewrites: int = 0
    parse_s: float = 0.0
    initial_simplify_s: float = 0.0
    group_generation_s: float = 0.0
    recognition_s: float = 0.0
    selection_s: float = 0.0
    validation_s: float = 0.0
    recovery_s: float = 0.0
    rewrite_close_s: float = 0.0
    composition_s: float = 0.0
    residual_encode_s: float = 0.0
    affine_s: float = 0.0
    receipt_check_s: float = 0.0
    wall_s: float = 0.0
    oracle_calls: int = 0
    peak_ir_bytes: int = 0
    live_ir_bytes: int = 0
    initial_ir_bytes: int = 0
    max_coeff_bits: int = 0
    boundary_sizes: list[int] = field(default_factory=list)
    witness_bytes: int = 0
    proof_bytes: int = 0
    recovery_bytes: int = 0
    residual_encode_bytes: int = 0
    input_bytes: int = 0
    peak_process_rss_bytes: int | None = None
    skipped: list[str] = field(default_factory=list)
    affine_calls: int = 0
    native_close_steps: int = 0
    cache_policy: str = "cold"
    cache_was_warm_at_entry: bool = False
    effective_config: dict[str, Any] = field(default_factory=dict)

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class Receipt:
    input_factor_ids: tuple[int, ...]
    input_identities: list[str]
    boundary: tuple[int, ...]
    eliminated: tuple[int, ...]
    replacement: list[str]
    promise: str
    validation: str
    recovery: dict[str, Any]
    orig_cost: int
    new_cost: int
    table_rows: int
    scope: tuple[int, ...]
    group_sat_mask: int
    speculative: bool = False
    note: str = ""


@dataclass
class CompileResult:
    status: str
    assignment: dict[int, int] | None
    residual: list[str]
    derivation: list[str]
    receipts: list[Receipt]
    meter: Meter
    n_vars: int
    original_clauses: tuple[tuple[int, ...], ...]
    residual_clauses: tuple[tuple[int, ...], ...]
    warnings: tuple[str, ...]
    mode: str
    variant: str = ""
    error: str | None = None
    affine_label: str | None = None
    claim_grade: str = "none"
    recognized: list[str] = field(default_factory=list)
    receipt_checks: list[dict[str, Any]] = field(default_factory=list)


def _vars(factor: Factor) -> set[int]:
    return set(factor.vars())


def _boundary_internal(
    group: list[Factor], all_factors: list[Factor], retain: set[int]
) -> tuple[tuple[int, ...], tuple[int, ...]]:
    gids = {f.id for f in group}
    block_vars: set[int] = set()
    for factor in group:
        block_vars |= _vars(factor)
    outside: set[int] = set()
    for factor in all_factors:
        if factor.id in gids or factor.kind is Kind.TRUE:
            continue
        outside |= _vars(factor)
    boundary = tuple(sorted((block_vars & outside) | (block_vars & retain)))
    internal = tuple(sorted(block_vars - set(boundary)))
    return boundary, internal


def _live(factors: list[Factor]) -> list[Factor]:
    return live_factors(factors)


def _record_ir(meter: Meter, factors: list[Factor]) -> None:
    blob = ir_bytes(_live(factors))
    meter.live_ir_bytes = len(blob)
    meter.peak_ir_bytes = max(meter.peak_ir_bytes, len(blob))
    rss = peak_process_rss_bytes()
    if rss is not None:
        meter.peak_process_rss_bytes = max(meter.peak_process_rss_bytes or 0, rss)


def _next_id(counter: list[int]) -> int:
    counter[0] += 1
    return counter[0]


def replace_promise(factor: Factor, promise: Promise) -> Factor:
    return Factor(
        id=factor.id,
        kind=factor.kind,
        lits=factor.lits,
        parity=factor.parity,
        promise=promise,
        table_mask=factor.table_mask,
    )


def native_close(
    factors: list[Factor],
    n_vars: int,
    counter: list[int],
    derivation: list[str],
    meter: Meter,
) -> list[Factor]:
    guard = 0
    while guard < 10000:
        guard += 1
        meter.native_close_steps += 1
        factors = _live(factors)
        if any(f.kind is Kind.FALSE for f in factors):
            derivation.append("FALSE factor")
            return factors
        uf = SignedUF()
        conflict = False
        for factor in factors:
            if factor.kind is Kind.UNIT:
                lit = factor.lits[0]
                if not uf.assign(abs(lit), 1 if lit > 0 else 0):
                    conflict = True
                    break
            elif factor.kind is Kind.SAME:
                if not uf.union(factor.lits[0], factor.lits[1], False):
                    conflict = True
                    break
            elif factor.kind is Kind.DIFFERENT:
                if not uf.union(factor.lits[0], factor.lits[1], True):
                    conflict = True
                    break
        if conflict:
            derivation.append("signed-UF/unit conflict")
            return [Factor(id=_next_id(counter), kind=Kind.FALSE)]

        new_units: list[Factor] = []
        have_unit_lits = {f.lits[0] for f in factors if f.kind is Kind.UNIT}
        for var in range(1, n_vars + 1):
            val = uf.value_of(var) if var in uf.parent else None
            if val is None:
                continue
            lit = var if val == 1 else -var
            if lit not in have_unit_lits:
                new_units.append(
                    Factor(id=_next_id(counter), kind=Kind.UNIT, lits=(lit,), promise=Promise.B)
                )
        if new_units:
            factors = factors + new_units
            derivation.append(f"UF-derived units {[u.lits[0] for u in new_units]}")
            continue

        changed = False
        nxt: list[Factor] = []
        for factor in factors:
            if factor.kind in (Kind.UNIT, Kind.SAME, Kind.DIFFERENT, Kind.TRUE, Kind.TABLE):
                nxt.append(factor)
                continue
            if factor.kind is Kind.CLAUSE:
                keep: list[int] = []
                taut = False
                for lit in factor.lits:
                    val = uf.value_of(abs(lit))
                    if val is None:
                        keep.append(lit)
                        continue
                    lit_true = (val == 1 and lit > 0) or (val == 0 and lit < 0)
                    if lit_true:
                        taut = True
                        break
                if taut:
                    changed = True
                    continue
                if not keep:
                    derivation.append("empty clause after UP")
                    return [Factor(id=_next_id(counter), kind=Kind.FALSE)]
                if len(keep) < len(factor.lits):
                    changed = True
                rebuilt = clause_from_lits(tuple(keep), fid=_next_id(counter))
                assert rebuilt is not None
                nxt.append(replace_promise(rebuilt, Promise.B))
                continue
            if factor.kind in (Kind.AMO, Kind.XO):
                lits = list(factor.lits)
                forced_true: list[int] = []
                rest: list[int] = []
                for lit in lits:
                    val = uf.value_of(abs(lit))
                    if val is None:
                        rest.append(lit)
                        continue
                    lit_true = (val == 1 and lit > 0) or (val == 0 and lit < 0)
                    if lit_true:
                        forced_true.append(lit)
                if len(forced_true) > 1:
                    derivation.append("AMO/XO two trues")
                    return [Factor(id=_next_id(counter), kind=Kind.FALSE)]
                if factor.kind is Kind.XO and not rest and not forced_true:
                    derivation.append("XO all false")
                    return [Factor(id=_next_id(counter), kind=Kind.FALSE)]
                if forced_true:
                    for lit in rest:
                        nxt.append(
                            Factor(
                                id=_next_id(counter),
                                kind=Kind.UNIT,
                                lits=(-lit,),
                                promise=Promise.B,
                            )
                        )
                    changed = True
                    continue
                if factor.kind is Kind.XO and len(rest) == 1 and not forced_true:
                    nxt.append(
                        Factor(
                            id=_next_id(counter),
                            kind=Kind.UNIT,
                            lits=(rest[0],),
                            promise=Promise.B,
                        )
                    )
                    changed = True
                    continue
                if factor.kind is Kind.AMO and len(rest) <= 1:
                    changed = True
                    continue
                if len(rest) != len(factor.lits):
                    changed = True
                    nxt.append(
                        Factor(
                            id=_next_id(counter),
                            kind=factor.kind,
                            lits=tuple(rest),
                            promise=Promise.B,
                        )
                    )
                    continue
                nxt.append(factor)
                continue
            if factor.kind is Kind.PARITY:
                acc = int(factor.parity)
                restv: list[int] = []
                for var in factor.lits:
                    val = uf.value_of(var)
                    if val is None:
                        restv.append(var)
                    else:
                        acc ^= val
                if not restv:
                    if acc % 2 == 1:
                        derivation.append("parity 0=1")
                        return [Factor(id=_next_id(counter), kind=Kind.FALSE)]
                    changed = True
                    continue
                if len(restv) == 1:
                    lit = restv[0] if acc % 2 == 1 else -restv[0]
                    nxt.append(
                        Factor(id=_next_id(counter), kind=Kind.UNIT, lits=(lit,), promise=Promise.B)
                    )
                    changed = True
                    continue
                if len(restv) != len(factor.lits) or (acc % 2 == 1) != factor.parity:
                    changed = True
                    nxt.append(
                        Factor(
                            id=_next_id(counter),
                            kind=Kind.PARITY,
                            lits=tuple(sorted(restv)),
                            parity=bool(acc % 2),
                            promise=Promise.B,
                        )
                    )
                    continue
                nxt.append(factor)
                continue
            nxt.append(factor)
        factors = nxt
        if not changed:
            break
    return _live(factors)


class _Budget:
    def __init__(self, t0: float, limits: dict[str, Any], meter: Meter):
        self.t0 = t0
        self.limits = limits
        self.meter = meter

    def time_ok(self) -> bool:
        if time.perf_counter() - self.t0 > float(self.limits["max_seconds"]):
            if "max_seconds" not in self.meter.skipped:
                self.meter.skipped.append("max_seconds")
            return False
        return True

    def work_ok(self) -> bool:
        # max_table_rows charges meter.table_rows only. Template construction,
        # projection, and recovery counters are accounted separately and are
        # not this cap. Do not read this as a complete total-work budget.
        if not self.time_ok():
            return False
        if self.meter.candidates_examined >= int(self.limits["max_candidates"]):
            if "max_candidates" not in self.meter.skipped:
                self.meter.skipped.append("max_candidates")
            return False
        if self.meter.table_rows >= int(self.limits["max_table_rows"]):
            if "max_table_rows" not in self.meter.skipped:
                self.meter.skipped.append("max_table_rows")
            return False
        if self.meter.rewrites >= int(self.limits["max_rewrites"]):
            if "max_rewrites" not in self.meter.skipped:
                self.meter.skipped.append("max_rewrites")
            return False
        return True

    def resource_hit(self) -> bool:
        return any(
            flag in self.meter.skipped
            for flag in ("max_seconds", "max_candidates", "max_table_rows", "max_rewrites")
        )


def _score_key(
    new_cost: int,
    improvement: int,
    n_internal: int,
    n_repl: int,
    canon: str,
    ids: tuple[int, ...],
    speculative: bool,
) -> tuple:
    # Ordinary compressing rewrites outrank speculative tables.
    return (int(speculative), new_cost, -improvement, -n_internal, n_repl, canon, ids)


def _absorb_local(meter: Meter, local: dict[str, int]) -> None:
    meter.table_rows += local.get("table_rows", 0)
    meter.recognition_atoms += local.get("recognition_atoms", 0)
    meter.template_construction_rows += local.get("template_construction_rows", 0)
    meter.template_cache_hits += local.get("template_cache_hits", 0)
    meter.template_cache_misses += local.get("template_cache_misses", 0)
    meter.projection_rows += local.get("projection_rows", 0)
    meter.recovery_rows += local.get("recovery_rows", 0)
    meter.validation_rows += local.get("validation_rows", 0)


def _iter_groups(factors: list[Factor], limits: dict[str, Any], budget: _Budget, gen_meter: dict[str, int]):
    max_factors = int(limits["max_factors"])
    max_scope = int(limits["max_scope"])
    gb = GroupBudget(check=budget.work_ok, meter=gen_meter)
    seen: set[frozenset[int]] = set()
    if limits.get("use_support_index"):
        for group in iter_same_support_groups(factors, max_factors, max_scope, gb):
            ids = frozenset(f.id for f in group)
            if ids in seen:
                continue
            seen.add(ids)
            yield group, True
        if gb.exhausted:
            return
    for group in iter_connected_groups(factors, max_factors, max_scope, gb):
        ids = frozenset(f.id for f in group)
        if ids in seen:
            continue
        seen.add(ids)
        yield group, False


def compile_cnf(
    text: str | bytes,
    mode: str,
    limits: dict[str, Any],
    retain: list[int] | None = None,
    use_affine: bool = True,
    variant: str | None = None,
    cache_policy: str | None = None,
) -> CompileResult:
    meter = Meter()
    t0 = time.perf_counter()
    variant = variant or str(limits.get("variant") or "")
    policy = cache_policy or str(limits.get("cache_policy") or "cold")
    meter.cache_policy = policy
    meter.cache_was_warm_at_entry = cache_is_warm()
    if policy == "cold":
        clear_atom_cache()
        meter.cache_was_warm_at_entry = False
    retain_set = set(retain or [])
    derivation: list[str] = []
    receipts: list[Receipt] = []
    recognized: list[str] = []

    max_factors = int(limits.get("max_factors", 3))
    if mode == "A":
        max_factors = 0
    elif mode == "B" and not variant:
        max_factors = 2
    elif mode == "C" and not variant:
        max_factors = int(limits.get("max_factors", 3))
    work_limits = dict(limits)
    work_limits["max_factors"] = max_factors
    work_limits["variant"] = variant
    meter.effective_config = {
        "mode": mode,
        "variant": variant,
        "max_factors": max_factors,
        "max_scope": int(limits.get("max_scope", 6)),
        "max_seconds": float(limits["max_seconds"]),
        "max_candidates": int(limits["max_candidates"]),
        "max_rewrites": int(limits["max_rewrites"]),
        "max_table_rows": int(limits["max_table_rows"]),
        "allow_temp_table": bool(limits.get("allow_temp_table", False)),
        "use_support_index": bool(limits.get("use_support_index", False)),
        "max_temp_table_vars": int(limits.get("max_temp_table_vars", 6)),
        "max_speculation_depth": int(limits.get("max_speculation_depth", 3)),
        "max_beam": int(limits.get("max_beam", 4)),
        "max_temp_tables": int(limits.get("max_temp_tables", 8)),
        "cache_policy": policy,
        "retain": sorted(retain_set),
        "table_row_cap_charges": "meter.table_rows_only",
        "template_and_projection_not_in_table_row_cap": True,
        "temporary_table_follows_selected_top_path": True,
        "wall_s_includes_receipt_checks": True,
        "unsat_checked_derivation_not_whole_chain_replay": True,
    }

    t_parse = time.perf_counter()
    try:
        parsed = parse_dimacs(text)
    except DimacsError as exc:
        meter.parse_s = time.perf_counter() - t_parse
        meter.wall_s = time.perf_counter() - t0
        return CompileResult(
            status="MALFORMED",
            assignment=None,
            residual=[],
            derivation=[],
            receipts=[],
            meter=meter,
            n_vars=0,
            original_clauses=(),
            residual_clauses=(),
            warnings=(),
            mode=mode,
            variant=variant,
            error=str(exc),
            claim_grade="none",
        )
    meter.parse_s = time.perf_counter() - t_parse
    meter.input_bytes = len(parsed.raw_bytes)
    penalty = penalty_from_clauses(parsed.clauses)
    meter.max_coeff_bits = penalty.max_coeff_bits()
    n_vars = parsed.n_vars
    counter = [0]
    factors: list[Factor] = []
    for clause in parsed.clauses:
        factor = clause_from_lits(clause, fid=_next_id(counter))
        assert factor is not None
        factors.append(factor)

    meter.initial_ir_bytes = len(ir_bytes(_live(factors)))
    _record_ir(meter, factors)

    budget = _Budget(t0, work_limits, meter)

    if any(f.kind is Kind.FALSE for f in factors):
        derivation.append("empty clause in input")
        return _finish("UNSAT", None, factors, derivation, receipts, meter, parsed, mode, t0, variant, "checked_derivation", recognized)

    t_simp = time.perf_counter()
    factors = native_close(factors, n_vars, counter, derivation, meter)
    meter.initial_simplify_s = time.perf_counter() - t_simp
    _record_ir(meter, factors)
    if any(f.kind is Kind.FALSE for f in factors):
        return _finish("UNSAT", None, factors, derivation, receipts, meter, parsed, mode, t0, variant, "checked_derivation", recognized)

    seen_hashes = {ir_hash(factors)}
    allow_groups = max_factors >= 2
    allow_temp = bool(work_limits.get("allow_temp_table", False))
    max_temp_vars = int(work_limits.get("max_temp_table_vars", 6))
    max_spec_depth = int(work_limits.get("max_speculation_depth", 3))
    max_beam = int(work_limits.get("max_beam", 4))
    max_temp_tables = int(work_limits.get("max_temp_tables", 8))

    while allow_groups:
        if not budget.work_ok():
            return _finish("RESOURCE_LIMIT", None, factors, derivation, receipts, meter, parsed, mode, t0, variant, "none", recognized)

        gen_meter: dict[str, int] = {}
        best = None
        best_key = None
        rec_g = None
        rec_boundary = None
        rec_internal = None
        rec_scope = None
        rec_sat = None
        rec_orig_cost = None
        rec_promise = None
        rec_speculative = False
        rec_from_index = False
        rec_rows_before = meter.table_rows
        table_beam: list[tuple[tuple, list[Factor], dict[str, Any]]] = []

        gen = _iter_groups(factors, work_limits, budget, gen_meter)
        while True:
            t_gen = time.perf_counter()
            try:
                group, from_index = next(gen)
            except StopIteration:
                meter.group_generation_s += time.perf_counter() - t_gen
                break
            meter.group_generation_s += time.perf_counter() - t_gen
            if not budget.work_ok():
                break
            meter.candidates_examined += 1
            glist = list(group)
            scope = tuple(sorted(_vars(glist[0]).union(*(_vars(f) for f in glist[1:])))) if len(glist) > 1 else tuple(sorted(_vars(glist[0])))
            t_rec = time.perf_counter()
            local: dict[str, int] = {"table_rows": 0, "recognition_atoms": 0}
            sat = group_sat_masks(glist, scope, local)
            boundary, internal = _boundary_internal(glist, factors, retain_set)
            if internal:
                keep = boundary
                if not keep:
                    replacement = (
                        [Factor(id=-1, kind=Kind.TRUE)]
                        if sat
                        else [Factor(id=-1, kind=Kind.FALSE)]
                    )
                    promise = Promise.C
                else:
                    proj = project_mask(scope, sat, keep, local)
                    replacement = recognize(keep, proj, local)
                    promise = Promise.C
            else:
                replacement = recognize(scope, sat, local)
                promise = Promise.B
            meter.recognition_s += time.perf_counter() - t_rec
            _absorb_local(meter, local)

            t_sel = time.perf_counter()
            speculative = False
            if replacement is None and allow_temp and len(scope) <= max_temp_vars:
                meter.speculation_routes += 1
                if meter.temp_tables_created >= max_temp_tables:
                    meter.temp_tables_rejected += 1
                    meter.speculation_rejected += 1
                    meter.candidates_rejected += 1
                    meter.selection_s += time.perf_counter() - t_sel
                    continue
                if meter.cost_increasing_rewrites >= max_spec_depth:
                    meter.speculation_rejected += 1
                    meter.candidates_rejected += 1
                    meter.selection_s += time.perf_counter() - t_sel
                    continue
                replacement = [table_factor(scope if not internal else boundary, sat if not internal else project_mask(scope, sat, boundary, local))]
                promise = Promise.C if internal else Promise.B
                speculative = True
            if replacement is None:
                meter.candidates_rejected += 1
                meter.selection_s += time.perf_counter() - t_sel
                continue
            replacement = [canon_factor_payload(f) for f in replacement]
            orig_cost = sum(f.structural_cost() for f in glist)
            new_cost = sum(f.structural_cost() for f in replacement)
            improvement = orig_cost - new_cost
            is_false = any(f.kind is Kind.FALSE for f in replacement)
            is_table = any(f.kind is Kind.TABLE for f in replacement)
            if is_table and not speculative:
                # recognize() never returns TABLE; defensive.
                speculative = True
            if not is_false and not speculative and improvement <= 0 and not internal:
                meter.candidates_rejected += 1
                meter.selection_s += time.perf_counter() - t_sel
                continue
            if not is_false and not speculative and new_cost >= orig_cost and not internal:
                meter.candidates_rejected += 1
                meter.selection_s += time.perf_counter() - t_sel
                continue
            if speculative and is_table:
                if new_cost <= orig_cost and not internal:
                    # still a table; do not claim compression
                    pass
            canon = "|".join(f.canon_string() for f in replacement)
            ids = tuple(sorted(f.id for f in glist))
            key = _score_key(new_cost, improvement, len(internal), len(replacement), canon, ids, speculative)
            payload = {
                "g": glist,
                "boundary": boundary,
                "internal": internal,
                "scope": scope,
                "sat": sat,
                "orig_cost": orig_cost,
                "promise": promise,
                "from_index": from_index,
            }
            if speculative:
                table_beam.append((key, replacement, payload))
            elif best is None or key < best_key:
                best = replacement
                best_key = key
                rec_g = glist
                rec_boundary = boundary
                rec_internal = internal
                rec_scope = scope
                rec_sat = sat
                rec_orig_cost = orig_cost
                rec_promise = promise
                rec_speculative = False
                rec_from_index = from_index
            meter.selection_s += time.perf_counter() - t_sel

        meter.tuples_proposed += gen_meter.get("tuples_proposed", 0)
        meter.groups_emitted += gen_meter.get("groups_emitted", 0)
        meter.starts_considered += gen_meter.get("starts_considered", 0)
        meter.discarded_disconnected += gen_meter.get("discarded_disconnected", 0)
        meter.discarded_scope += gen_meter.get("discarded_scope", 0)
        meter.index_hits += gen_meter.get("index_hits", 0)
        meter.index_buckets += gen_meter.get("index_buckets", 0)
        meter.adjacency_pairs += gen_meter.get("adjacency_pairs", 0)

        if best is None and allow_temp and table_beam:
            table_beam.sort(key=lambda item: item[0])
            meter.temp_table_candidates_before_truncation += len(table_beam)
            kept = table_beam[:max_beam]
            meter.speculation_rejected += max(0, len(table_beam) - len(kept))
            # Selected temporary path: only the top stored candidate is followed.
            # max_beam truncates the stored list; this is not a demonstrated
            # multi-path beam search.
            key, replacement, payload = kept[0]
            best = replacement
            best_key = key
            rec_g = payload["g"]
            rec_boundary = payload["boundary"]
            rec_internal = payload["internal"]
            rec_scope = payload["scope"]
            rec_sat = payload["sat"]
            rec_orig_cost = payload["orig_cost"]
            rec_promise = payload["promise"]
            rec_speculative = True
            rec_from_index = payload["from_index"]

        if best is None:
            if budget.resource_hit():
                return _finish("RESOURCE_LIMIT", None, factors, derivation, receipts, meter, parsed, mode, t0, variant, "none", recognized)
            break

        t_val = time.perf_counter()
        assert rec_g is not None
        val_local = {"table_rows": 0, "validation_rows": 0}
        if rec_internal:
            keep = rec_boundary or ()
            if keep:
                proj = project_mask(rec_scope, rec_sat, keep, val_local)
                repl_mask = group_sat_masks(best, keep, val_local)
                val_local["validation_rows"] += val_local.get("table_rows", 0)
                if proj != repl_mask:
                    meter.skipped.append("validation_failed")
                    meter.validation_s += time.perf_counter() - t_val
                    _absorb_local(meter, val_local)
                    return _finish("FAILURE", None, factors, derivation, receipts, meter, parsed, mode, t0, variant, "none", recognized)
            else:
                want_false = rec_sat == 0
                got_false = any(f.kind is Kind.FALSE for f in best)
                got_true = (not best) or all(f.kind is Kind.TRUE for f in best)
                if want_false != got_false or (not want_false and not got_true and not got_false):
                    meter.validation_s += time.perf_counter() - t_val
                    return _finish("FAILURE", None, factors, derivation, receipts, meter, parsed, mode, t0, variant, "none", recognized)
        else:
            repl_mask = group_sat_masks(best, rec_scope, val_local)
            val_local["validation_rows"] += val_local.get("table_rows", 0)
            if repl_mask != rec_sat:
                meter.validation_s += time.perf_counter() - t_val
                _absorb_local(meter, val_local)
                return _finish("FAILURE", None, factors, derivation, receipts, meter, parsed, mode, t0, variant, "none", recognized)
        meter.validation_s += time.perf_counter() - t_val
        _absorb_local(meter, val_local)

        t_recov = time.perf_counter()
        recovery: dict[str, Any] = {}
        recov_local: dict[str, int] = {"recovery_rows": 0}
        if rec_internal:
            if not rec_boundary:
                if rec_sat:
                    nsc = len(rec_scope)
                    for mask in range(1 << nsc):
                        recov_local["recovery_rows"] += 1
                        if (rec_sat >> mask) & 1:
                            asg = {rec_scope[i]: (mask >> i) & 1 for i in range(nsc)}
                            recovery = {
                                "type": "closed_form",
                                "map": {str(k): ["const", v] for k, v in asg.items()},
                            }
                            break
                else:
                    recovery = {}
            else:
                cf = closed_form_recovery(rec_scope, rec_sat, rec_boundary, rec_internal, recov_local)
                if cf is not None:
                    recovery = {"type": "closed_form", "map": {str(k): list(v) for k, v in cf.items()}}
                else:
                    table = []
                    nb = len(rec_boundary)
                    for bmask in range(1 << nb):
                        recov_local["recovery_rows"] += 1
                        basg = {rec_boundary[i]: (bmask >> i) & 1 for i in range(nb)}
                        comp = lex_completion(rec_scope, rec_sat, rec_boundary, rec_internal, basg, recov_local)
                        if comp is not None:
                            table.append({"boundary": basg, "internal": comp})
                    recovery = {"type": "lex_table", "rows": table}
        meter.recovery_s += time.perf_counter() - t_recov
        _absorb_local(meter, recov_local)

        t_comp = time.perf_counter()
        drop_ids = {f.id for f in rec_g}
        input_identities = [f.canon_string() for f in rec_g]
        new_factors = [f for f in factors if f.id not in drop_ids]
        stamped = []
        for factor in best:
            stamped.append(
                Factor(
                    id=_next_id(counter),
                    kind=factor.kind,
                    lits=factor.lits,
                    parity=factor.parity,
                    promise=rec_promise,
                    table_mask=factor.table_mask,
                )
            )
        new_factors.extend(stamped)
        if rec_speculative:
            meter.temp_tables_created += 1
            meter.cost_increasing_rewrites += 1
        receipt = Receipt(
            input_factor_ids=tuple(sorted(drop_ids)),
            input_identities=input_identities,
            boundary=rec_boundary or (),
            eliminated=rec_internal or (),
            replacement=[f.canon_string() for f in stamped],
            promise=rec_promise.value if rec_promise else "B",
            validation="group_truth_table_boundary_not_a_proof",
            recovery=recovery,
            orig_cost=rec_orig_cost or 0,
            new_cost=sum(f.structural_cost() for f in stamped),
            table_rows=meter.table_rows - rec_rows_before,
            scope=rec_scope or (),
            group_sat_mask=int(rec_sat or 0),
            speculative=rec_speculative,
            note=f"group_size={len(rec_g)};index={int(rec_from_index)};variant={variant or mode}",
        )
        receipts.append(receipt)
        recognized.extend(receipt.replacement)
        meter.rewrites += 1
        if rec_boundary:
            meter.boundary_sizes.append(len(rec_boundary))
        potential_old = (total_cost(factors), len(_live(factors)), len(live_vars(factors)))
        factors = new_factors
        meter.composition_s += time.perf_counter() - t_comp

        t_close = time.perf_counter()
        factors = native_close(factors, n_vars, counter, derivation, meter)
        meter.rewrite_close_s += time.perf_counter() - t_close
        potential_new = (total_cost(factors), len(_live(factors)), len(live_vars(factors)))
        digest = ir_hash(factors)
        if digest in seen_hashes:
            derivation.append("cycle_detected")
            meter.skipped.append("rewrite_cycle")
            return _finish("UNRESOLVED", None, factors, derivation, receipts, meter, parsed, mode, t0, variant, "none", recognized)
        if potential_new >= potential_old and not any(f.kind is Kind.FALSE for f in factors) and not rec_speculative:
            if potential_new == potential_old:
                derivation.append("no_progress")
                break
        seen_hashes.add(digest)
        _record_ir(meter, factors)
        if any(f.kind is Kind.FALSE for f in factors):
            return _finish("UNSAT", None, factors, derivation, receipts, meter, parsed, mode, t0, variant, "checked_derivation", recognized)

    factors = _live(factors)
    affine_kinds = {Kind.TRUE, Kind.FALSE, Kind.UNIT, Kind.SAME, Kind.DIFFERENT, Kind.PARITY}
    if use_affine and factors and all(f.kind in affine_kinds for f in factors):
        from .backends import affine_close_factors

        t_aff = time.perf_counter()
        meter.affine_calls += 1
        status, wit, label = affine_close_factors(factors, n_vars)
        meter.affine_s = time.perf_counter() - t_aff
        if status == "UNSAT":
            derivation.append(f"known-algebra {label} empty")
            return _finish("UNSAT", None, factors, derivation, receipts, meter, parsed, mode, t0, variant, "checked_derivation", recognized, affine_label=label)
        if status == "SAT" and wit is not None:
            recs = list(reversed(receipts))
            assignment = reconstruct_assignment(n_vars, wit, recs, factors)
            if not cnf_holds(parsed.clauses, assignment):
                assignment = reconstruct_assignment(n_vars, assignment, recs, factors)
            if cnf_holds(parsed.clauses, assignment):
                return _finish("SAT", assignment, factors, derivation, receipts, meter, parsed, mode, t0, variant, "witness_on_original", recognized, affine_label=label)

    constraining = [f for f in factors if f.kind not in (Kind.TRUE,)]
    leftover_tables = [f for f in constraining if f.kind is Kind.TABLE]
    if leftover_tables and all(f.kind in (Kind.TRUE, Kind.TABLE) for f in factors):
        derivation.append("leftover_table_is_not_a_decision")
        return _finish("UNRESOLVED", None, factors, derivation, receipts, meter, parsed, mode, t0, variant, "none", recognized)

    if not constraining:
        assignment = reconstruct_assignment(n_vars, {v: 0 for v in range(1, n_vars + 1)}, list(reversed(receipts)), factors)
        if cnf_holds(parsed.clauses, assignment):
            return _finish("SAT", assignment, factors, derivation, receipts, meter, parsed, mode, t0, variant, "witness_on_original", recognized)
        meter.skipped.append("empty_residual_witness_failed")
        return _finish("FAILURE", None, factors, derivation, receipts, meter, parsed, mode, t0, variant, "none", recognized)

    only_uf = all(f.kind in (Kind.UNIT, Kind.SAME, Kind.DIFFERENT) for f in factors)
    if only_uf:
        uf = SignedUF()
        for factor in factors:
            if factor.kind is Kind.UNIT:
                if not uf.assign(abs(factor.lits[0]), 1 if factor.lits[0] > 0 else 0):
                    return _finish("UNSAT", None, factors, derivation, receipts, meter, parsed, mode, t0, variant, "checked_derivation", recognized)
            elif factor.kind is Kind.SAME:
                if not uf.union(factor.lits[0], factor.lits[1], False):
                    return _finish("UNSAT", None, factors, derivation, receipts, meter, parsed, mode, t0, variant, "checked_derivation", recognized)
            else:
                if not uf.union(factor.lits[0], factor.lits[1], True):
                    return _finish("UNSAT", None, factors, derivation, receipts, meter, parsed, mode, t0, variant, "checked_derivation", recognized)
        assignment = uf.assignment_map(list(range(1, n_vars + 1)), 0)
        assignment = reconstruct_assignment(n_vars, assignment, list(reversed(receipts)), factors)
        if cnf_holds(parsed.clauses, assignment):
            return _finish("SAT", assignment, factors, derivation, receipts, meter, parsed, mode, t0, variant, "witness_on_original", recognized)
        derivation.append("uf_witness_failed_on_original")
        return _finish("UNRESOLVED", None, factors, derivation, receipts, meter, parsed, mode, t0, variant, "none", recognized)

    asg0 = reconstruct_assignment(
        n_vars, {v: 0 for v in range(1, n_vars + 1)}, list(reversed(receipts)), factors
    )
    if all(factor_holds(f, asg0) for f in factors) and cnf_holds(parsed.clauses, asg0):
        derivation.append("residual_satisfied_by_all_zero")
        return _finish("SAT", asg0, factors, derivation, receipts, meter, parsed, mode, t0, variant, "witness_on_original", recognized)

    return _finish("UNRESOLVED", None, factors, derivation, receipts, meter, parsed, mode, t0, variant, "none", recognized)


def reconstruct_assignment(
    n_vars: int,
    seed: dict[int, int],
    receipts_newest_first: list[Receipt],
    factors: list[Factor],
) -> dict[int, int]:
    assignment = {var: int(seed.get(var, 0)) for var in range(1, n_vars + 1)}
    for rec in receipts_newest_first:
        recov = rec.recovery or {}
        if recov.get("type") == "closed_form":
            for var_s, spec in recov["map"].items():
                var = int(var_s)
                kind, arg = spec[0], spec[1]
                if kind == "const":
                    assignment[var] = int(arg)
                else:
                    lit = int(arg)
                    bit = assignment[abs(lit)]
                    assignment[var] = bit if lit > 0 else 1 - bit
        elif recov.get("type") == "lex_table":
            for row in recov.get("rows", []):
                if isinstance(row["boundary"], dict):
                    if all(assignment.get(int(k), 0) == int(v) for k, v in row["boundary"].items()):
                        for iv, bit in row["internal"].items():
                            assignment[int(iv)] = int(bit)
                        break
    for var in range(1, n_vars + 1):
        assignment.setdefault(var, 0)
        if assignment[var] not in (0, 1):
            raise ValueError("non-binary reconstructed assignment")
    return assignment


def _finish(
    status: str,
    assignment: dict[int, int] | None,
    factors: list[Factor],
    derivation: list[str],
    receipts: list[Receipt],
    meter: Meter,
    parsed: Any,
    mode: str,
    t0: float,
    variant: str = "",
    claim_grade: str = "none",
    recognized: list[str] | None = None,
    affine_label: str | None = None,
) -> CompileResult:
    _record_ir(meter, factors)
    t_enc = time.perf_counter()
    from .encode import factors_to_clauses

    residual_clauses = tuple(factors_to_clauses(_live(factors)))
    meter.residual_encode_s = time.perf_counter() - t_enc
    meter.residual_encode_bytes = len(canonical_json_bytes(residual_clauses))
    proof_blob = serialized_receipts_bytes(receipts)
    meter.proof_bytes = len(proof_blob)
    meter.recovery_bytes = len(
        canonical_json_bytes([r.recovery for r in receipts])
    )
    if assignment is not None:
        meter.witness_bytes = len(canonical_json_bytes({str(k): v for k, v in assignment.items()}))
        from .arithmetic import reject_fractional

        reject_fractional(assignment)
    residual = [f.canon_string() for f in _live(factors)]
    from .receipts import check_rewrite_receipt, receipt_payload

    t_check = time.perf_counter()
    checks = [check_rewrite_receipt(receipt_payload(r)) for r in receipts]
    meter.receipt_check_s = time.perf_counter() - t_check
    failed_receipts = [c for c in checks if not c.get("ok")]
    if failed_receipts:
        if status == "SAT":
            claim_grade = "witness_on_original_receipt_rejected" if assignment is not None else "receipt_rejected"
        elif status == "UNSAT":
            claim_grade = "unsat_receipt_rejected"
        else:
            claim_grade = "receipt_rejected"
    elif status == "UNSAT" and claim_grade == "checked_derivation":
        claim_grade = "unsat_local_or_algebra_not_whole_chain_replay"
    elif status == "UNSAT":
        claim_grade = "unchecked"
    meter.wall_s = time.perf_counter() - t0
    return CompileResult(
        status=status,
        assignment=assignment,
        residual=residual,
        derivation=derivation,
        receipts=receipts,
        meter=meter,
        n_vars=parsed.n_vars,
        original_clauses=parsed.clauses,
        residual_clauses=residual_clauses,
        warnings=parsed.warnings,
        mode=mode,
        variant=variant,
        affine_label=affine_label,
        claim_grade=claim_grade,
        recognized=recognized or [],
        receipt_checks=checks,
    )
