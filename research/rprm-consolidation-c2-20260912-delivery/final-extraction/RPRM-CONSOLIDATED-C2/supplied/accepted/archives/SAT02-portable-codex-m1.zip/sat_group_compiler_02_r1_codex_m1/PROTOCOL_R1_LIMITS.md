# PROTOCOL limits after SAT02-REVIEW-01

The frozen `protocol_v2.json` / `PROTOCOL_V2.md` bytes are unchanged so the protocol hash remains `2d94c1895d2c5a61b82c2d3e7eb7a45e1f5acc42be633a7f83a1d88b1ea29bb9`. These are successor claim bounds, not a new frozen protocol version and not a new holdout.

- Declared seeds remain ten. Effective SAT02 execution is six. Omitted seeds are NOT_RUN.
- `max_table_rows` charges primary table-row enumeration only. Template-construction and projection/recovery counters are recorded and are outside that cap.
- Adjacency is not built when the group budget is already exhausted. If generation is allowed to start, live adjacency may still be built; that is not a complete-work claim.
- W3-T follows a selected temporary path (`kept[0]`). `max_beam` truncates a stored list; it is not a demonstrated multi-path beam search.
- `wall_s` in this successor includes receipt checking.
- Local receipt checks are not independently replayed whole-solver proofs. UNSAT `checked_derivation` is downgraded to `unsat_local_or_algebra_not_whole_chain_replay`.
- Source fingerprint excludes `versions.json`. No retained pre-run 47-file inventory is available for the original freeze.
- Protected XOR rows with `retain_xor` receive retained IDs from the family label. That is an explicit local contract, not unassisted raw-CNF discovery.
- Production panel grading that only looks for a `P:` string is not the eight-assignment parity contract.
- No DRAT / original-instance whole-chain replay is supplied.
