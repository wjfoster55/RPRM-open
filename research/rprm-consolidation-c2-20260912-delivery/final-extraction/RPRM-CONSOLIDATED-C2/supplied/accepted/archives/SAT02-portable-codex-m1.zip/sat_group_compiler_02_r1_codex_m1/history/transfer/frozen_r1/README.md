# SAT02-R1 — bounded owner closeout

Successor development after SAT02-REVIEW-01. Not Task03, not a panel rerun, not seed backfill, and not a new general proof system.

Original completed return (frozen): `../sat_group_compiler_02/`.
Review package copy: `../sat02_review_01_package/SAT02-REVIEW-01/`.
Submitted zip was not modified.

## What this successor is

A claim-bounded repair of the implementation boundaries named by the accepted review, plus regressions. Original exact specimens are preserved and re-checked here. Original panel JSON is not rewritten.

## Commands

From this directory:

```powershell
$env:PYTHONPATH = (Get-Location).Path
python run.py test
```

Do not run `freeze` or `panels` as if completing the original SAT02 result.

## Claim ceiling

See `CLAIM_LEDGER.md` and `OWNER_RETURN.md`.
