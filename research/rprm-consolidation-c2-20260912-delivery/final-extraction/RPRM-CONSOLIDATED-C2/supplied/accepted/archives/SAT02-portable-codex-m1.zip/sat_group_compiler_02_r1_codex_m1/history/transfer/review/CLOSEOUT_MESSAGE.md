# SAT02-R1 — carry-forward status

**Partial research closeout accepted. Not a whole-solver certification or completed benchmark.**

Reviewed owner artifact: `sat_group_compiler_02_r1.zip`, SHA-256 `26c17cb940a599afecb08f16c993a4f646aa347138a59812ea70aaa326dc155a`.

The exact protected-XOR/W3-T route survives: TABLE structural cost 15→18, then parity 23→6. The three-color star and the 147/243 two-factor conjunction remain exact; the 93/243 union atom is not equivalent. The group-generation repair, timer correction and versions-file exclusion were independently checked. Original tests: 57/57. Owner successor tests: 73/73.

Development seeds 23,29,31 and evaluation seeds 20011,20021,20047 were run in the original panels. Development 37,41 and evaluation 20063,20089 remain NOT_RUN. No new panel or seed execution was performed in this closeout. Comparative/whole-proof/complete-budget claims remain withdrawn or limited. Do not call “completed locally” a complete execution of the declared ten-seed protocol.

**Local checker qualification:** R1 still accepts recovery records that overwrite retained boundary variables, and falsely rejects fifty saved empty-relation receipts for lacking recovery. All 982 saved local receipts remain mathematically valid in the separate review scope; no wrong saved SAT/UNSAT answer is inferred from these findings.

A hash-pinned one-file reviewer candidate is supplied separately. It restricts recovery to eliminated outputs and treats recovery on an independently verified empty relation as vacuous. All 73 existing tests plus six new regressions pass on that candidate; all 982 saved receipts pass. Candidate status: REVIEWER_TESTED_NOT_INTEGRATED. Do not label it as the submitted R1 or silently replace R1's recorded hash.

**No new research assignment.** Either retain R1 with this checker limitation explicitly recorded, or integrate the supplied minimal guard as maintenance before relying on its local certificates. The latter requires only source reconciliation, the existing unit suite, the six focused regressions and a fresh artifact identity—not new panels, seeds, beam search, DRAT infrastructure or Task03.

Retain C1, Lind–Reichardt and the AD 14/16 pilot as closed. Fluid and Yang–Mills remain undispatched. No commit, push, merge, publication or additional worker is authorized by this note.
