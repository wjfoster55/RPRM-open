"""Source, configuration, and dependency fingerprints."""

from __future__ import annotations

import hashlib
import json
import platform
import sys
from pathlib import Path
from typing import Any

from .protocol import PROTOCOL_PATH, canonical_json_bytes, load_protocol, protocol_sha256

ROOT = Path(__file__).resolve().parent.parent


def _hash_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def source_file_hashes(root: Path | None = None) -> dict[str, str]:
    base = root or ROOT
    out: dict[str, str] = {}
    for path in sorted(base.rglob("*")):
        if not path.is_file():
            continue
        rel = path.relative_to(base).as_posix()
        if "__pycache__" in rel or rel.startswith("results/") or rel.startswith("_handoff/"):
            continue
        if rel == "versions.json":
            # Output receipt written by freeze/hash. Including it makes the
            # recorded source digest change when the receipt is written.
            continue
        if path.suffix.lower() not in {".py", ".json", ".md", ".cnf", ".ps1", ".txt"}:
            continue
        out[rel] = _hash_bytes(path.read_bytes())
    return out


def source_sha256(root: Path | None = None) -> str:
    files = source_file_hashes(root)
    blob = canonical_json_bytes(files)
    return _hash_bytes(blob)


def dependency_fingerprint(probe: dict[str, Any]) -> dict[str, Any]:
    pysat_version = None
    try:
        import pysat  # type: ignore

        pysat_version = getattr(pysat, "__version__", "unknown")
    except Exception:
        pysat_version = None
    return {
        "python": sys.version,
        "python_implementation": platform.python_implementation(),
        "platform": platform.platform(),
        "pysat_version": pysat_version,
        "pysat_available": bool(probe.get("pysat")),
        "pysat_solver": probe.get("pysat_solver"),
        "closure_sat": bool(probe.get("closure_sat")),
        "narizoo_affine": bool(probe.get("affine")),
        "stdlib_gf2": True,
        "two_sat_import": bool(probe.get("two_sat")),
        "horn_import": bool(probe.get("horn")),
        "robdd_import": bool(probe.get("robdd")),
        "probe_errors": probe.get("errors", {}),
        "paths": probe.get("paths", {}),
    }


def peak_process_rss_bytes() -> int | None:
    try:
        import ctypes
        from ctypes import wintypes

        class PROCESS_MEMORY_COUNTERS(ctypes.Structure):
            _fields_ = [
                ("cb", wintypes.DWORD),
                ("PageFaultCount", wintypes.DWORD),
                ("PeakWorkingSetSize", ctypes.c_size_t),
                ("WorkingSetSize", ctypes.c_size_t),
                ("QuotaPeakPagedPoolUsage", ctypes.c_size_t),
                ("QuotaPagedPoolUsage", ctypes.c_size_t),
                ("QuotaPeakNonPagedPoolUsage", ctypes.c_size_t),
                ("QuotaNonPagedPoolUsage", ctypes.c_size_t),
                ("PagefileUsage", ctypes.c_size_t),
                ("QuotaPeakPagefileUsage", ctypes.c_size_t),
            ]

        counters = PROCESS_MEMORY_COUNTERS()
        counters.cb = ctypes.sizeof(PROCESS_MEMORY_COUNTERS)
        handle = ctypes.windll.kernel32.GetCurrentProcess()
        ok = ctypes.windll.psapi.GetProcessMemoryInfo(handle, ctypes.byref(counters), counters.cb)
        if not ok:
            return None
        return int(counters.PeakWorkingSetSize)
    except Exception:
        try:
            import resource  # type: ignore

            usage = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
            # Linux reports KiB; macOS bytes. The field name remains
            # peak_process_rss_bytes for compatibility; this is a process
            # lifetime high-water mark, not an isolated per-arm peak, and on
            # Linux it is KiB stored in a field named bytes.
            return int(usage)
        except Exception:
            return None


def freeze_record(probe: dict[str, Any]) -> dict[str, Any]:
    protocol = load_protocol()
    files = source_file_hashes()
    return {
        "protocol_id": protocol["protocol_id"],
        "protocol_version": protocol["protocol_version"],
        "protocol_sha256": protocol_sha256(protocol),
        "protocol_path": str(PROTOCOL_PATH),
        "source_sha256": source_sha256(),
        "source_file_count": len(files),
        "config_sha256": protocol_sha256(protocol),
        "effective_group_rule": protocol["group_rule"],
        "variants": protocol["variants"],
        "seeds": {
            "development": protocol["development_seeds"],
            "evaluation": protocol["evaluation_seeds"],
            "v1_evaluation_are_regressions": protocol["v1_evaluation_seeds_are_regressions_not_holdouts"],
        },
        "dependencies": dependency_fingerprint(probe),
        "note": (
            "Input-source inventory excludes versions.json and results/. "
            "Writing the freeze receipt must not change the source digest. "
            "Protocol hash, source digest, and dependency probe are separate identities. "
            "No retained pre-run 47-file inventory is available for the original SAT02 freeze."
        ),
    }


def write_json(path: Path, obj: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, sort_keys=True, default=str), encoding="utf-8")
