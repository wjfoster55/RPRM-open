# Historical saved-result convenience subset

The five JSON files under `results/` are exact bytes extracted from the supplied
original `sat_group_compiler_02.zip`. They contain 466 already-saved result rows and
982 local receipts, used by `review/tools/review_successor.py`.

This directory is NOT an entire source checkout or a fresh run. The full original
archive, including source, protocol, reports, CSVs, and original execution records,
is retained unchanged at `../inputs/sat_group_compiler_02.zip`. Its file identity
is recorded in `../INPUT_BINDINGS.json`.

Do not regenerate any of these panels or execute the four omitted seeds. Saved
receipt replay does not establish a complete original solver derivation or
recreate the historical runtime environment.
