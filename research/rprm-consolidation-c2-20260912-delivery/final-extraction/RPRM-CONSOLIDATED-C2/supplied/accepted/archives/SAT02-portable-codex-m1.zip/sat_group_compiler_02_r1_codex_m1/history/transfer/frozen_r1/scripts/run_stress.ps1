$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot\..
$env:PYTHONPATH = (Get-Location).Path
python run.py freeze
python run.py stress
python run.py stage1
python run.py stage2
