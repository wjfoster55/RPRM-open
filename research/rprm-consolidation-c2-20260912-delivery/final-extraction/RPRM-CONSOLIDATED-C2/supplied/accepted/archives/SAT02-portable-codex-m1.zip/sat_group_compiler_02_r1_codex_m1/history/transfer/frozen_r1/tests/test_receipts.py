from __future__ import annotations

import unittest

from sat_group_compiler.compiler import compile_cnf
from sat_group_compiler.protocol import load_protocol, stage_limits
from sat_group_compiler.receipts import check_rewrite_receipt, corrupt_receipt, receipt_payload


class ReceiptCheckerTests(unittest.TestCase):
    def test_checker_accepts_w4_parity_receipt(self):
        xor = "p cnf 3 4\n1 2 3 0\n1 -2 -3 0\n-1 2 -3 0\n-1 -2 3 0\n"
        limits = stage_limits(load_protocol(), "smoke", "W4")
        r = compile_cnf(xor, mode="C", limits=limits, variant="W4", retain=[1, 2, 3], use_affine=False)
        self.assertTrue(r.receipts)
        payload = receipt_payload(r.receipts[0])
        checked = check_rewrite_receipt(payload)
        self.assertTrue(checked["ok"], msg=checked)
        self.assertTrue(checked["did_not_invoke_compiler"])
        self.assertTrue(checked["did_not_trust_validation_string"])

    def test_checker_rejects_flipped_mask(self):
        xor = "p cnf 3 4\n1 2 3 0\n1 -2 -3 0\n-1 2 -3 0\n-1 -2 3 0\n"
        limits = stage_limits(load_protocol(), "smoke", "W4")
        r = compile_cnf(xor, mode="C", limits=limits, variant="W4", retain=[1, 2, 3], use_affine=False)
        payload = corrupt_receipt(receipt_payload(r.receipts[0]), "mask_flip")
        checked = check_rewrite_receipt(payload)
        self.assertFalse(checked["ok"])

    def test_validation_string_is_not_authority(self):
        xor = "p cnf 3 4\n1 2 3 0\n1 -2 -3 0\n-1 2 -3 0\n-1 -2 3 0\n"
        limits = stage_limits(load_protocol(), "smoke", "W4")
        r = compile_cnf(xor, mode="C", limits=limits, variant="W4", retain=[1, 2, 3], use_affine=False)
        payload = receipt_payload(r.receipts[0])
        payload["validation"] = "totally_legit"
        checked = check_rewrite_receipt(payload)
        self.assertTrue(checked["ok"])
        bad = corrupt_receipt(payload, "mask_flip")
        bad["validation"] = "totally_legit"
        self.assertFalse(check_rewrite_receipt(bad)["ok"])


if __name__ == "__main__":
    unittest.main()
