$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot\..
$env:PYTHONPATH = (Get-Location).Path
python run.py freeze
python verify_seed.py
python run.py test
python run.py watchdog
python run.py smoke
