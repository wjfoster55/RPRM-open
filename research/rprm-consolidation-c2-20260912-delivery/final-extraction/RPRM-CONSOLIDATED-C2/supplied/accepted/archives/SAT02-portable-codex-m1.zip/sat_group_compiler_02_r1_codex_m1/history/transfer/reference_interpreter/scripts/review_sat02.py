"""Bounded read-only review of SAT02. No installation, new panels, or source edits.

Usage: python -B review_sat02.py --experiment PATH --output FRESH_DIRECTORY
Checks saved rows against reconstructed inputs and an independent local truth-table
interpreter; reruns only selected exposed fixtures and diagnostic counterexamples.
"""
from __future__ import annotations
import argparse, collections, copy, hashlib, itertools, json, platform, sys, time
from pathlib import Path


def jsave(path: Path, obj):
    path.write_text(json.dumps(obj, indent=2, sort_keys=True, default=str)+'\n',encoding='utf-8')


def clause_truth(clauses, a):
    return all(any(a[abs(l)] == int(l>0) for l in c) for c in clauses)


def parse_dimacs_independent(text):
    n=0; clauses=[]; cur=[]
    for line in text.splitlines():
        if not line.strip() or line.lstrip().startswith('c'): continue
        if line.lstrip().startswith('p'):
            n=int(line.split()[2]);continue
        for token in line.split():
            x=int(token)
            if x==0: clauses.append(tuple(cur));cur=[]
            else: cur.append(x)
    assert not cur
    return n,clauses


def assignments(vs):
    for bits in itertools.product((0,1), repeat=len(vs)):
        yield dict(zip(vs,bits))


def atom_truth(s, a):
    if s=='T':return True
    if s=='F':return False
    if s.startswith('P:'):
        vs,p=s[2:].split('='); vs=[int(x) for x in vs.split(',') if x]
        return sum(a[v] for v in vs)%2 == int(p)
    if s.startswith('TBL:'):
        vs,m=s[4:].split(':');vs=[int(x) for x in vs.split(',') if x]
        idx=sum(a[v]<<i for i,v in enumerate(vs))
        return bool(int(m,16)&(1<<idx))
    kind,ls=s.split(':'); ls=[int(x) for x in ls.split(',') if x]
    if kind in ['D','S']:
        return (a[ls[0]]==a[ls[1]]) == (kind=='S')
    vals=[a[abs(l)] if l>0 else 1-a[abs(l)] for l in ls]
    return {'C':lambda:any(vals),'U':lambda:vals[0]==1,'A':lambda:sum(vals)<=1,'X':lambda:sum(vals)==1}[kind]()


def independent_receipt(p):
    scope=p['scope']; b=p['boundary']; gone=p['eliminated']; reasons=[]
    if set(b)&set(gone) or set(scope)!=set(b)|set(gone):reasons.append('scope_partition')
    ins=p['input_identities']; outs=p['replacement']
    sats=[a for a in assignments(scope) if all(atom_truth(s,a) for s in ins)]
    mask=sum(1<<sum(a[v]<<i for i,v in enumerate(scope)) for a in sats)
    if mask!=p['group_sat_mask']: reasons.append('input_mask')
    keep=scope if p['promise']=='B' else b
    allowed={tuple(a[v] for v in keep) for a in sats}
    for a in assignments(keep):
        if all(atom_truth(s,a) for s in outs)!=(tuple(a[v] for v in keep) in allowed):reasons.append('relation');break
    if gone:
        rec=p.get('recovery') or {}
        for bits in allowed:
            a=dict(zip(keep,bits));result=dict(a)
            if rec.get('type')=='closed_form':
                for var,spec in rec.get('map',{}).items():
                    kind,arg=spec
                    if kind=='const':result[int(var)]=int(arg)
                    elif abs(int(arg)) in result:result[int(var)]=result[abs(int(arg))] if int(arg)>0 else 1-result[abs(int(arg))]
                    else:reasons.append('missing_dependency')
            elif rec.get('type')=='lex_table':
                matches=[row for row in rec.get('rows',[]) if {int(k):int(v) for k,v in row['boundary'].items()}==a]
                if len(matches)!=1:reasons.append('recovery_row_coverage');continue
                result.update({int(k):int(v) for k,v in matches[0]['internal'].items()})
            else:reasons.append('recovery_missing');continue
            if not set(scope)<=set(result) or any(result.get(v) not in (0,1) for v in scope):reasons.append('recovery_type');continue
            if not all(atom_truth(s,result) for s in ins):reasons.append('recovery_wrong')
    return sorted(set(reasons))


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--experiment',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);args=ap.parse_args()
    root=args.experiment.resolve();out=args.output.resolve();out.mkdir(parents=True,exist_ok=False)
    initial={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in root.rglob('*') if p.is_file()}
    sys.path.insert(0,str(root))
    from sat_group_compiler import cli, grouping
    from sat_group_compiler.compiler import compile_cnf, Meter
    from sat_group_compiler.ir import Factor, Kind
    from sat_group_compiler.protocol import load_protocol,stage_limits,protocol_sha256
    from sat_group_compiler.fingerprints import source_file_hashes,source_sha256
    from sat_group_compiler.receipts import check_rewrite_receipt,receipt_payload
    from sat_group_compiler.backends import get_probe
    proto=load_protocol()
    panel_defs={'smoke':cli.smoke_instances(),'stress':cli.stress_instances(),'stage1':cli.stage1_instances(),'development':cli.panel_instances('development',proto['development_seeds']),'evaluation':cli.panel_instances('evaluation',proto['evaluation_seeds'])}
    summaries={};bad_sat=[];bad_verdict=[];bad_local=[];assign_count=0;decisive_oracle=0;unknown_unsat=[];receipt_n=0;recovery_n=0
    truth_cache={};row_count=0;scope_counts=collections.Counter();all_status=collections.Counter();family_routes=[]
    for panel,instances in panel_defs.items():
        byid={i.instance_id:i for i in instances};rows=json.loads((root/'results'/f'{panel}.json').read_text())
        counts=collections.defaultdict(collections.Counter);seeds=set();matched=set();n_checked=0
        for r in rows:
            row_count+=1;arm=r.get('variant') or r['mode'];counts[arm][r['candidate_status']]+=1;all_status[r['candidate_status']]+=1
            if r['seed'] is not None:seeds.add(r['seed'])
            inst=byid[r['instance_id']];matched.add(inst.instance_id);n,clauses=parse_dimacs_independent(inst.dimacs)
            if (r.get('retained') or []):family_routes.append({'panel':panel,'id':inst.instance_id,'arm':arm,'retain':r['retained']})
            if r['candidate_status']=='SAT':
                assign_count+=1;a={int(k):v for k,v in r['assignment'].items()}
                if not set(range(1,n+1))<=set(a) or any(type(x) is not int or x not in (0,1) for x in a.values()) or not clause_truth(clauses,a):bad_sat.append([panel,inst.instance_id,arm])
            if n<=12:
                key=hashlib.sha256(inst.dimacs.encode()).hexdigest()
                if key not in truth_cache:truth_cache[key]=any(clause_truth(clauses,a) for a in assignments(list(range(1,n+1))))
                truth='SAT' if truth_cache[key] else 'UNSAT'
                n_checked+=1
                if r['candidate_status'] in ('SAT','UNSAT'):
                    decisive_oracle+=1
                    if r['candidate_status']!=truth:bad_verdict.append([panel,inst.instance_id,arm,truth])
            elif r['candidate_status']=='UNSAT':unknown_unsat.append([panel,inst.instance_id,arm,n])
            for j,p in enumerate(r['receipts']):
                receipt_n+=1;recovery_n+=int(bool(p['eliminated']));scope_counts[len(p['scope'])]+=1
                reasons=independent_receipt(p)
                if reasons:bad_local.append({'panel':panel,'id':inst.instance_id,'arm':arm,'receipt':j,'reasons':reasons})
        summaries[panel]={'rows':len(rows),'instances':len(matched),'status_by_arm':dict(counts),'non_null_seeds':sorted(seeds),'declared_seeds':proto.get(panel+'_seeds'), 'exhaustive_checked_row_count':n_checked}
    freeze=json.loads((root/'results/freeze.json').read_text())
    jsave(out/'saved_result_audit.json',{'scope':'Recount of supplied rows plus independent arithmetic on generated inputs. This is not a fresh execution of the panel or a complete derivation-chain verification.','panels':summaries,'rows':row_count,'statuses':dict(all_status),'sat_witnesses_checked':assign_count,'bad_sat_witnesses':bad_sat,'decisive_verdicts_checked_by_exhaustive_oracle':decisive_oracle,'bad_decisive_verdicts':bad_verdict,'unsat_outside_exhaustive_scope':unknown_unsat,'local_receipts_independently_checked':receipt_n,'receipts_with_eliminations':recovery_n,'bad_local_receipts':bad_local,'scope_counts':dict(scope_counts),'family_derived_retain_rows':family_routes,'source_hash_current':source_sha256(),'source_file_count_current':len(source_file_hashes()),'source_hash_frozen':freeze['source_sha256'],'source_file_count_frozen':freeze['source_file_count'],'protocol_hash_current':protocol_sha256(),'protocol_hash_frozen':freeze['protocol_sha256'],'source_file_hashes':source_file_hashes(),'environment':{'python':sys.version,'platform':platform.platform(),'probe':{k:v for k,v in get_probe().items() if k in ('pysat','affine','closure_sat','stdlib_gf2','errors')}}})
    # Exposed positive: use same bounded caps but no panel rerun.
    positive=[];xor='p cnf 3 4\n1 2 3 0\n1 -2 -3 0\n-1 2 -3 0\n-1 -2 3 0\n'
    for arm in cli.VARIANTS:
        r=compile_cnf(xor,'C',stage_limits(proto,'smoke',arm),retain=[1,2,3],variant=arm,use_affine=False)
        ps=[receipt_payload(p) for p in r.receipts]
        positive.append({'arm':arm,'status':r.status,'residual':r.residual,'recognized':r.recognized,'receipts':ps,'independent_receipt_errors':[independent_receipt(p) for p in ps],'meter':r.meter.as_dict()})
    jsave(out/'protected_xor_replay.json',positive)
    # Every sign complementation and six clause permutations, fixed protected IDs.
    transforms=[]
    base_clauses=parse_dimacs_independent(xor)[1]
    for signs in itertools.product((0,1),repeat=3):
      cls=[tuple(-l if signs[abs(l)-1] else l for l in c) for c in base_clauses]
      for order in [(0,1,2,3),(3,2,1,0),(1,3,0,2)]:
       text='p cnf 3 4\n'+'\n'.join(' '.join(map(str,cls[i]))+' 0' for i in order)+'\n'
       for arm in ('W4','W3-T','W4-I'):
        r=compile_cnf(text,'C',stage_limits(proto,'smoke',arm),retain=[1,2,3],variant=arm,use_affine=False)
        par=[s for s in r.residual if s.startswith('P:')];want=1^(sum(signs)%2)
        valid=bool(par) and all(atom_truth(par[0],a)==(sum(a.values())%2==want) for a in assignments([1,2,3]))
        transforms.append({'signs':signs,'order':order,'arm':arm,'parity_exact':valid,'status':r.status})
    jsave(out/'xor_variants_independent.json',{'cases':len(transforms),'passed':sum(r['parity_exact'] for r in transforms),'rows':transforms})
    # Grouping coverage diagnostic independent BFS oracle on connected clause scopes.
    scopes=[(1,2),(3,4),(2,3)];gs=[]
    for order in itertools.permutations(range(3)):
        fs=[Factor(i+1,Kind.CLAUSE,scopes[j]) for i,j in enumerate(order)]
        generated=list(grouping.iter_connected_groups(fs,3,4,grouping.GroupBudget(lambda:True,{})))
        gs.append({'input_scope_order':[f.lits for f in fs],'complete_triple_found':any(len(g)==3 for g in generated),'emitted_scopes':[[f.lits for f in g] for g in generated]})
    # Check adjacency build occurs before even consulting zero budget.
    seen={'pairs':0,'budget_checks':0};orig_neighbor=grouping.neighbor_map
    def count_neighbor(fs):
        res=orig_neighbor(fs);seen['pairs']=sum(len(v) for v in res.values())//2;return res
    def refused():seen['budget_checks']+=1;return False
    grouping.neighbor_map=count_neighbor
    try:list(grouping.iter_connected_groups([Factor(i,Kind.CLAUSE,(1,i+2)) for i in range(1,81)],3,6,grouping.GroupBudget(refused,{})))
    finally:grouping.neighbor_map=orig_neighbor
    jsave(out/'grouping_counterexample.json',{'scope':'same three connected factors, all six ID orders; no restrictive resource budget','rows':gs,'all_triples_expected':6,'triples_found':sum(x['complete_triple_found'] for x in gs),'zero_budget_adjacency':seen})
    # Recovery faults: use actual production C receipt for X != A, with A retained.
    r=compile_cnf('p cnf 2 2\n1 2 0\n-1 -2 0\n','C',stage_limits(proto,'smoke','W3'),retain=[1],variant='W3',use_affine=False)
    p=receipt_payload(r.receipts[0]);mut=[]
    for name in ['good','wrong_closed_form','missing_recovery','empty_lex_table','incomplete_lex_table','overlap_boundary_elimination','bogus_input_ids']:
        q=copy.deepcopy(p)
        if name=='wrong_closed_form':q['recovery']={'type':'closed_form','map':{'2':['lit',1]}}
        elif name=='missing_recovery':q['recovery']={}
        elif name=='empty_lex_table':q['recovery']={'type':'lex_table','rows':[]}
        elif name=='incomplete_lex_table':q['recovery']={'type':'lex_table','rows':[{'boundary':{'1':0},'internal':{'2':1}}]}
        elif name=='overlap_boundary_elimination':q['eliminated']=[1,2]
        elif name=='bogus_input_ids':q['input_factor_ids']=[999,1000]
        mut.append({'name':name,'submitted_checker':check_rewrite_receipt(q),'independent_local_errors':independent_receipt(q),'scope_note':'Original-instance ID anchoring cannot be checked by this standalone local relation function.' if name=='bogus_input_ids' else '', 'payload':q})
    jsave(out/'receipt_counterexamples.json',mut)
    # Actual finishing API ignores a failing receipt report and stops wall time first.
    import sat_group_compiler.receipts as rr
    checker=rr.check_rewrite_receipt
    def reject_with_delay(p):time.sleep(.02);return {'ok':False,'grade':'rejected','reasons':['REVIEW_FAULT_INJECTION']}
    rr.check_rewrite_receipt=reject_with_delay
    try:
        t=time.perf_counter();ret=compile_cnf(xor,'C',stage_limits(proto,'smoke','W4'),variant='W4',retain=[1,2,3]);elapsed=time.perf_counter()-t
    finally:rr.check_rewrite_receipt=checker
    jsave(out/'finish_boundary_diagnostic.json',{'scope':'Focused post-validation failure/time injection, NOT mathematical evidence','status':ret.status,'claim_grade':ret.claim_grade,'receipt_checks':ret.receipt_checks,'meter_wall_s':ret.meter.wall_s,'external_elapsed_s':elapsed,'deliberate_checker_delay_s':.02})
    # Native check independent of claimed counts / named-atom assertion.
    from sat_group_compiler import native3
    triples=list(itertools.product(range(3),repeat=3));valid=[t for t in triples if any(all(x!=v for v in t) for x in range(3))]
    pair_sizes=[len({(t[i],t[j]) for t in valid}) for i,j in itertools.combinations(range(3),2)]
    nodes=('A','B','C','X'); edges=[('X','A'),('X','B'),('X','C')]
    n,cls=native3.encode_star_onehot(nodes,edges);cnf_models=[];bad_enc=[]
    for a in assignments(list(range(1,n+1))):
        good=clause_truth(cls,a);decoded=native3.decode_onehot(nodes,a)
        native=decoded is not None and all(decoded[x]!=decoded[y] for x,y in edges)
        if good:cnf_models.append(a)
        if good!=native:bad_enc.append(a)
    ov=[];union=[]
    for vs in itertools.product(range(3),repeat=5):
        a,b,c,d,e=vs
        exists=any(x!=a and x!=b and x!=c and y!=c and y!=d and y!=e for x,y in itertools.product(range(3),repeat=2))
        product_ok=len({a,b,c})<=2 and len({c,d,e})<=2
        assert exists==product_ok
        if exists:ov.append(vs)
        if len(set(vs))<=2:union.append(vs)
    # Six global permutations preserve joint outcome; no performance claim.
    perms_ok=all((len({p[a],p[b],p[c]})<=2 and len({p[c],p[d],p[e]})<=2)==(len({a,b,c})<=2 and len({c,d,e})<=2) for p in itertools.permutations(range(3)) for a,b,c,d,e in itertools.product(range(3),repeat=5))
    jsave(out/'native_independent.json',{'k3_accepted':len(valid),'pair_projection_sizes':pair_sizes,'exact_plus_triangle':sum(t[0]!=t[1] and t[1]!=t[2] and t[0]!=t[2] for t in valid),'pairwise_ablation_plus_triangle':6,'onehot_all_assignments_checked':2**n,'onehot_satisfying_assignments':len(cnf_models),'onehot_disagreements':bad_enc,'overlap_boundaries_checked':243,'original_two_stars_equals_two_projected_factors':True,'two_factor_conjunction_accepted':len(ov),'single_atmosttwo_union_accepted':len(union),'example_separating_union':next(v for v in ov if v not in union),'global_color_permutations_pass':perms_ok,'note':'Keeping two factors is already a compact exact conjunction for this specimen; no theorem here requires merging to one named atom.'})
    final={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in root.rglob('*') if p.is_file()}
    jsave(out/'no_source_changes.json',{'unchanged':initial==final,'files':len(initial)})
    print(json.dumps({'saved_rows':row_count,'SAT_witnesses':assign_count,'bad_witnesses':len(bad_sat),'bad_verdicts':len(bad_verdict),'local_receipts':receipt_n,'bad_local_receipts':len(bad_local),'positive_xor_cases':len(transforms),'XOR_pass':sum(x['parity_exact'] for x in transforms),'source_unchanged':initial==final},indent=2))

if __name__=='__main__':main()
