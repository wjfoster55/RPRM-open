# SAT02 M1 maintenance status

M1 checker integrated in this fresh successor; accepted partial research unchanged.
The reviewed candidate was adopted with an additional eight-line output guard for
nonempty relations with no eliminated variables. Both recovery forms previously
accepted writes to retained variables in that case. M1 rejects those writes while
preserving absent/identity recovery and empty-relation vacuity.

The supplied candidate itself passed 73 original tests, six regressions and 982 saved
receipts, but failed the two added no-elimination overwrite controls. M1 passes all
23 focused controls. The original six-test file and all seven original test files
are byte-identical to their sources. The production code delta remains one file.

The paired external evidence and CODEX_M1_REVIEW_AND_CLOSEOUT.md report the final
ZIP's actual fresh-extraction verification. This build carries no self-referential
claim that its own future export replay was already run. Root HASHES.json and
PATCH_APPLICATION.json remain historical; M1_MANIFEST.json binds current payload.

Research: accepted partial. Seeds: 6 RUN / 4 NOT_RUN. Comparative and whole-proof
claims: withdrawn/limited. C1, Lind–Reichardt and AD 14/16 stay closed; Fluid and
Yang–Mills stay undispatched. No next experiment or Task03 is assigned.
