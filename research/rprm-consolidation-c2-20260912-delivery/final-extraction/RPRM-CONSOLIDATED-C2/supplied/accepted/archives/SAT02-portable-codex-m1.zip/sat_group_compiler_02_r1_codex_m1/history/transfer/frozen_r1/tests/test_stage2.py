from __future__ import annotations

import unittest
from pathlib import Path

from sat_group_compiler.native3 import (
    compose_with_triangle,
    decode_onehot,
    encode_coloring,
    encode_star_onehot,
    project_star_center,
    recover_center,
    run_stage2,
    sizes_for_k,
    uses_at_most_2_colors,
    verify_k3_rule,
)

ROOT = Path(__file__).resolve().parents[1]


class NativeStarTests(unittest.TestCase):
    def test_k3_21_of_27(self):
        k3 = verify_k3_rule()
        self.assertEqual(k3["extendable_triples"], 21)
        self.assertEqual(k3["pair_projection_sizes"], [9, 9, 9])
        self.assertTrue(k3["relation_matches"])
        self.assertTrue(k3["unsafe_pair_closure_accepts_012"])

    def test_triangle_unsat_vs_unsafe(self):
        payload = compose_with_triangle()
        self.assertTrue(payload["exact_plus_triangle_unsat"])
        self.assertTrue(payload["unsafe_admits_all_distinct"])

    def test_recovery_missing_color(self):
        self.assertEqual(recover_center((0, 0, 1)), 2)
        self.assertIsNone(recover_center((0, 1, 2)))

    def test_k_star_not_built_by_3k_enum(self):
        info = project_star_center(("A", "B", "C", "D", "E"))
        self.assertEqual(info["enumerated_assignments_to_construct"], 0)
        self.assertEqual(info["arity"], 5)
        sizes = sizes_for_k(6)
        self.assertLess(sizes["projected_serialized"], sizes["naive_table_bytes_estimate"])
        self.assertTrue(sizes["constructed_without_3k_enum"])

    def test_encoder_matches_fixture(self):
        star = (ROOT / "fixtures" / "three_color_star.cnf").read_text(encoding="utf-8")
        plus = (ROOT / "fixtures" / "three_color_star_plus_triangle.cnf").read_text(encoding="utf-8")
        payload = run_stage2(star, plus)
        self.assertTrue(payload["encoder_vs_star_fixture"]["clause_set_equal"])
        self.assertEqual(payload["encoder_vs_star_fixture"]["boolean_vars"], 12)
        self.assertEqual(payload["decoder_round_trip_extendable"]["ok"], 21)
        self.assertEqual(payload["label_raw_cnf_discovery"], "SKIPPED_not_implemented")
        self.assertTrue(payload["encoder_vs_star_plus_triangle_fixture"]["clause_set_equal"])
        overlap = payload["overlapping_stars"]
        for name, arm in overlap["orders"].items():
            self.assertEqual(arm["compact_merge"]["supported_named_relation_on_union"], False)
            self.assertIn("two-factor conjunction", arm["compact_merge"]["reason"])
        versus = overlap["conjunction_versus_union"]
        self.assertEqual(versus["two_factor_conjunction_accepted"], 147)
        self.assertEqual(versus["single_union_atom_accepted"], 93)
        self.assertEqual(versus["separating_example"], [0, 0, 1, 1, 2])
        self.assertFalse(overlap["orders_establish_policy_superiority"])

    def test_uses_at_most_2(self):
        self.assertTrue(uses_at_most_2_colors((0, 0, 1)))
        self.assertFalse(uses_at_most_2_colors((0, 1, 2)))


if __name__ == "__main__":
    unittest.main()
