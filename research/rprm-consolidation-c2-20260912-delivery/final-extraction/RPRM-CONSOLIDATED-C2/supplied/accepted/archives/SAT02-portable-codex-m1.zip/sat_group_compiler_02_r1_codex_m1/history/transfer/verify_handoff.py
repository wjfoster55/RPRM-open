"""Read-only transfer check. No solver, patch application, test generation or writes."""
from __future__ import annotations
import argparse
import hashlib
import json
import stat
import sys
import zipfile
from pathlib import Path, PurePosixPath

def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def local(root: Path, name: str) -> Path:
    part = PurePosixPath(name)
    if not name or '\\' in name or part.is_absolute() or '..' in part.parts or any(':' in p for p in part.parts):
        raise ValueError('Unsafe relative path: ' + name)
    p = root.joinpath(*part.parts)
    if p.is_symlink() or not p.resolve().is_relative_to(root.resolve()):
        raise ValueError('External or symbolic path: ' + name)
    return p

def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--root', type=Path, default=Path(__file__).resolve().parent)
    args = ap.parse_args()
    root = args.root.resolve()
    try:
        for p in root.rglob('*'):
            require(not p.is_symlink(), 'Symbolic path in handoff: ' + str(p))
        manifest = json.loads((root/'HANDOFF_MANIFEST.json').read_text(encoding='utf-8'))
        rows = manifest['files']
        names = [r['path'] for r in rows]
        require(len(names) == len(set(names)), 'Duplicate manifest path')
        actual = {p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()}
        require(actual == set(names) | {'HANDOFF_MANIFEST.json'}, 'File set differs from transfer manifest')
        for row in rows:
            b = local(root, row['path']).read_bytes()
            require(len(b) == row['bytes'] and sha(b) == row['sha256'], 'Payload mismatch: ' + row['path'])
        bindings = json.loads((root/'INPUT_BINDINGS.json').read_text(encoding='utf-8'))
        for row in bindings['inputs']:
            b = local(root, row['path']).read_bytes()
            require(len(b) == row['bytes'] and sha(b) == row['sha256'], 'Input mismatch: ' + row['path'])
        for spec in bindings['mirrors']:
            count = 0
            selection = set(spec['selection']) if spec['selection'] is not None else None
            with zipfile.ZipFile(local(root, spec['archive'])) as z:
                require(z.testzip() is None, 'ZIP CRC failure: ' + spec['archive'])
                seen = set()
                for info in z.infolist():
                    name = info.filename
                    local(root, name)
                    require(name not in seen, 'Duplicate archive member: ' + name)
                    require(not stat.S_ISLNK(info.external_attr >> 16), 'Archive symlink: ' + name)
                    seen.add(name)
                    if info.is_dir():
                        continue
                    require(name.startswith(spec['source_prefix']), 'Unexpected archive root: ' + name)
                    rel = name[len(spec['source_prefix']):]
                    if selection is not None and rel not in selection:
                        continue
                    out = local(root, spec['destination'] + '/' + rel)
                    require(out.read_bytes() == z.read(info), 'Source mirror mismatch: ' + str(out))
                    count += 1
            require(count == spec['file_count'], 'Mirror coverage mismatch: ' + spec['destination'])
        patch = bindings['patch']
        require(sha((root/'frozen_r1'/patch['source_file']).read_bytes()) == patch['before_sha256'], 'R1 checker identity mismatch')
        require(sha((root/'review/candidate_patch/receipts.py').read_bytes()) == patch['after_sha256'], 'Candidate checker identity mismatch')
        ref = bindings['reference_interpreter']
        require(local(root, ref['original']).read_bytes() == local(root, ref['convenience_copy']).read_bytes(), 'Interpreter relocation mismatch')
        print(json.dumps({'status':'PASS','scope':'transfer_integrity_only','payload_files':len(rows),
                          'input_files':len(bindings['inputs']),'source_mirrors':len(bindings['mirrors']),
                          'patch_integrated':False,'solver_tests_executed':False},indent=2))
        return 0
    except (ValueError, OSError, KeyError, TypeError, zipfile.BadZipFile) as exc:
        print(json.dumps({'status':'FAIL','scope':'transfer_integrity_only','error':str(exc)},indent=2))
        return 1

if __name__ == '__main__':
    sys.exit(main())
