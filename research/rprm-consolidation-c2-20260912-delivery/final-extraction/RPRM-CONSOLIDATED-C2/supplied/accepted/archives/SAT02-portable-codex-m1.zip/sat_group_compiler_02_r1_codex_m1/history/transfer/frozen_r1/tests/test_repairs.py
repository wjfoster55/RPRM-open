from __future__ import annotations

import time
import unittest

from sat_group_compiler.backends import classify_cnf, slow_stub
from sat_group_compiler.compiler import compile_cnf
from sat_group_compiler.dimacs import to_dimacs
from sat_group_compiler.grammar import cache_is_warm, clear_atom_cache
from sat_group_compiler.protocol import load_protocol, stage_limits


def limits(variant="W3", **overrides):
    lim = dict(stage_limits(load_protocol(), "smoke", variant))
    lim.update(overrides)
    return lim


class LazyGenerationTests(unittest.TestCase):
    def test_disjoint_binaries_do_not_scan_cubic_disconnected_tuples(self):
        m = 70
        text = to_dimacs(2 * m, [(2 * i + 1, 2 * i + 2) for i in range(m)])
        lim = limits("W3", max_seconds=0.01, max_candidates=2500)
        start = time.perf_counter()
        r = compile_cnf(text, mode="C", limits=lim, variant="W3", use_affine=False, cache_policy="cold")
        elapsed = time.perf_counter() - start
        self.assertLess(r.meter.tuples_proposed, 500, msg=r.meter.as_dict())
        self.assertEqual(r.meter.groups_emitted, 0)
        if r.meter.wall_s > 0.01 or elapsed > 0.05:
            self.assertEqual(r.status, "RESOURCE_LIMIT")
            self.assertIn("max_seconds", r.meter.skipped)
        else:
            self.assertIn(r.status, {"UNRESOLVED", "RESOURCE_LIMIT"})

    def test_config_max_scope_is_effective(self):
        xor = "p cnf 3 4\n1 2 3 0\n1 -2 -3 0\n-1 2 -3 0\n-1 -2 3 0\n"
        lim = limits("W4", max_scope=2)
        r = compile_cnf(xor, mode="C", limits=lim, variant="W4", retain=[1, 2, 3], use_affine=False)
        self.assertEqual(r.meter.effective_config["max_scope"], 2)
        self.assertFalse(any(s.startswith("P:") for s in r.residual + r.recognized))

    def test_config_max_factors_is_effective(self):
        xor = "p cnf 3 4\n1 2 3 0\n1 -2 -3 0\n-1 2 -3 0\n-1 -2 3 0\n"
        lim3 = limits("W3")
        lim4 = limits("W4")
        self.assertEqual(lim3["max_factors"], 3)
        self.assertEqual(lim4["max_factors"], 4)
        w3 = compile_cnf(xor, mode="C", limits=lim3, variant="W3", retain=[1, 2, 3], use_affine=False)
        w4 = compile_cnf(xor, mode="C", limits=lim4, variant="W4", retain=[1, 2, 3], use_affine=False)
        self.assertFalse(any(s.startswith("P:") for s in w3.residual))
        self.assertTrue(any(s.startswith("P:") for s in w4.residual + w4.recognized))


class TimingTests(unittest.TestCase):
    def test_finish_records_independent_wall_time(self):
        r = compile_cnf("p cnf 1 1\n1 0\n", mode="A", limits=limits())
        self.assertGreaterEqual(r.meter.wall_s, r.meter.parse_s)
        phases = (
            r.meter.parse_s
            + r.meter.initial_simplify_s
            + r.meter.group_generation_s
            + r.meter.recognition_s
            + r.meter.selection_s
            + r.meter.validation_s
            + r.meter.recovery_s
            + r.meter.rewrite_close_s
            + r.meter.composition_s
            + r.meter.residual_encode_s
            + r.meter.affine_s
        )
        self.assertGreaterEqual(r.meter.wall_s + 1e-3, max(phases, r.meter.parse_s))

    def test_initial_ir_recorded_before_simplify(self):
        r = compile_cnf("p cnf 1 1\n1 0\n", mode="A", limits=limits())
        self.assertGreater(r.meter.initial_ir_bytes, 0)
        self.assertGreaterEqual(r.meter.peak_ir_bytes, r.meter.initial_ir_bytes)

    def test_proof_bytes_are_actual_serialization(self):
        text = "p cnf 3 6\n1 2 0\n-1 -2 0\n2 3 0\n-2 -3 0\n3 1 0\n-3 -1 0\n"
        r = compile_cnf(text, mode="B", limits=limits())
        self.assertGreater(r.meter.proof_bytes, 16)
        self.assertGreater(r.meter.recovery_bytes, 2)


class CachePolicyTests(unittest.TestCase):
    def test_cold_clears_templates(self):
        xor = "p cnf 3 4\n1 2 3 0\n1 -2 -3 0\n-1 2 -3 0\n-1 -2 3 0\n"
        compile_cnf(xor, mode="C", limits=limits("W4"), variant="W4", retain=[1, 2, 3], cache_policy="warm")
        self.assertTrue(cache_is_warm())
        compile_cnf(xor, mode="C", limits=limits("W4"), variant="W4", retain=[1, 2, 3], cache_policy="cold")
        # cold run may refill during recognition
        clear_atom_cache()
        self.assertFalse(cache_is_warm())
        r = compile_cnf(xor, mode="C", limits=limits("W4"), variant="W4", retain=[1, 2, 3], cache_policy="cold")
        self.assertFalse(r.meter.cache_was_warm_at_entry)
        self.assertEqual(r.meter.cache_policy, "cold")


class WatchdogTests(unittest.TestCase):
    def test_slow_stub_is_killed(self):
        t0 = time.perf_counter()
        r = slow_stub(timeout_s=0.3, sleep_s=3.0)
        elapsed = time.perf_counter() - t0
        self.assertEqual(r.status, "RESOURCE_LIMIT")
        self.assertLess(elapsed, 2.0)
        self.assertTrue(r.skipped_reason)


class SyntaxClassificationTests(unittest.TestCase):
    def test_2cnf_and_horn_are_computed(self):
        info = classify_cnf(((1, 2), (-1, 3)))
        self.assertTrue(info["is_2cnf"])
        self.assertTrue(info["computed"])
        horn = classify_cnf(((-1, -2), (3,)))
        self.assertTrue(horn["is_horn"])
        not_horn = classify_cnf(((1, 2, 3),))
        self.assertFalse(not_horn["is_horn"])
        self.assertFalse(not_horn["is_2cnf"])


if __name__ == "__main__":
    unittest.main()
