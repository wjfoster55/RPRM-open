# SAT02 M1 claim ledger

Accepted partial research is unchanged. Owner-submitted R1 is frozen with its two
documented defects; the reviewer candidate is historical prior evidence. This M1
successor integrates the repair plus the relevant empty-elimination output guard.

| Claim | Carrier / receiver | Evidence and disposition |
| --- | --- | --- |
| Recovery extends the same retained assignment | Finite Boolean local relation R on scope S; B and E disjoint and cover S; promise C projects R to B | Code inspection plus unchanged 73+6 suite, 23 focused controls, and 982 saved local replays; M1 maintenance result only |
| Recovery is vacuous for empty input | Independently recomputed R is empty; replacement represents its empty projection | Accepted with no witness; incorrect stored zero masks and TRUE-for-empty replacements reject |
| No elimination permits no recovery writes | E is empty, R is nonempty; B=S | Both recovery forms must have no output keys. Absent recovery and identity forms remain accepted. Additional candidate flaw reproduced and repaired |
| Protected XOR and W3-T | Explicit retained variables {1,2,3} and supplied finite fixture | 72 parity transformations retained; ordinary W3 limitation retained; TABLE score 15→18, then parity 23→6. Structural score is not elapsed time |
| Native three-color star | {0,1,2}; existential center X; retained A,B,C | 21/27 extend; each pair projection has all 9 values |
| Overlapping stars | Two joint factors on 5 retained color variables | Exact conjunction 147/243; single union atom 93/243 is not equivalent; separator (0,0,1,1,2) retained |
| Saved local receipts | 982 receipts in 466 already-saved result rows | All accepted by M1 and the reused review interpretation with output-scope guard; no new panels and no new independent interpretation |
| Historical SAT answers and witnesses | Earlier reconstructed generators, n≤12 | Prior review evidence preserved as history; no fresh whole-instance claim in M1 |
| Connected grouping | Labelled graphs on 1–5 factors, forward/reverse IDs and two caps | Inherited repair unchanged; finite 1,099-graph / 4,396-comparison oracle retained, not an unbounded test proof |
| Timer and fingerprint repairs | Synthetic checker delay; generated versions record | Inherited corrections unchanged; checks retained, no performance ranking |
| Seed coverage | Original declared 10 seeds | 6 RUN / 4 NOT_RUN; no backfill; development 37,41 and evaluation 20063,20089 remain NOT_RUN |
| Whole-solver certification | Binding live input factor IDs and complete original-instance derivation | Not supplied. `binds_original_factor_ids=False`, `whole_solver_derivation_replayed=False`; local-only grade |
| Comparative/complete claims | Work budget, speed ranking, ten-seed completion, original dispatch, tractability, P versus NP | Withdrawn, unclaimed or explicitly limited; no new evidence upgrades them |

The recovery obligation is a section of existential projection: for every b in
pi_B(R), recovered r belongs to R and r restricted to B equals b. It does not
reconstruct every original satisfying occurrence or identify a whole solver chain.
Masks and enumeration concern finite admitted local scopes, not a general solver
soundness theorem. Malformed receipts, aliases accepted by integer coercion and
arbitrary extensions of the parser/grammar have not undergone a comprehensive
adversarial audit. Emptiness is established by evaluating the supplied input
identities, not by trusting their declared mask or binding them to a live instance.

Evidence grades remain distinct: historical run, written/code inspection, finite
unit/regression checks and reused independent local interpretation. No formal proof
was added. Hashes establish source identity only. Reproducible controls and corrected
counterexamples are retained alongside the surviving results.
