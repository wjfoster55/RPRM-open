"""Encode residual grammar factors back to CNF (hybrid arm only)."""

from __future__ import annotations

from .ir import Factor, Kind


def parity_cnf(vars_: tuple[int, ...], parity: bool) -> list[tuple[int, ...]]:
    n = len(vars_)
    clauses: list[tuple[int, ...]] = []
    for mask in range(1 << n):
        bits = [(mask >> i) & 1 for i in range(n)]
        if (sum(bits) % 2) == int(parity):
            continue
        clause = tuple(-vars_[i] if bits[i] else vars_[i] for i in range(n))
        clauses.append(clause)
    return clauses


def factors_to_clauses(factors: list[Factor]) -> list[tuple[int, ...]]:
    clauses: list[tuple[int, ...]] = []
    for factor in factors:
        if factor.kind is Kind.TRUE:
            continue
        if factor.kind is Kind.FALSE:
            clauses.append(())
        elif factor.kind is Kind.UNIT:
            clauses.append((factor.lits[0],))
        elif factor.kind is Kind.CLAUSE:
            clauses.append(factor.lits)
        elif factor.kind is Kind.SAME:
            a, b = factor.lits
            clauses.extend([(a, -b), (-a, b)])
        elif factor.kind is Kind.DIFFERENT:
            a, b = factor.lits
            clauses.extend([(a, b), (-a, -b)])
        elif factor.kind is Kind.PARITY:
            clauses.extend(parity_cnf(factor.lits, factor.parity))
        elif factor.kind is Kind.AMO:
            lits = factor.lits
            for i, a in enumerate(lits):
                for b in lits[i + 1 :]:
                    clauses.append((-a, -b))
        elif factor.kind is Kind.XO:
            lits = factor.lits
            clauses.append(tuple(lits))
            for i, a in enumerate(lits):
                for b in lits[i + 1 :]:
                    clauses.append((-a, -b))
        elif factor.kind is Kind.TABLE:
            n = len(factor.lits)
            for mask in range(1 << n):
                if (factor.table_mask >> mask) & 1:
                    continue
                clause = tuple(
                    -factor.lits[i] if (mask >> i) & 1 else factor.lits[i]
                    for i in range(n)
                )
                clauses.append(clause)
    return clauses
