"""Apply the narrowly reviewed receipt patch to a NEW local copy, never in place.

Usage:
  python -B apply_to_fresh_copy.py --source PATH_TO_EXTRACTED_R1 --destination NEW_PATH

No tests, panels, installations, Git operations or freeze commands are launched.
The copied HASHES.json remains the historical owner's record; PATCH_APPLICATION.json
identifies the changed file. This is a review candidate, not an official R1 export.
"""
from __future__ import annotations
import argparse,hashlib,json,shutil
from pathlib import Path

def sha(p:Path)->str:return hashlib.sha256(p.read_bytes()).hexdigest()

def main()->None:
    ap=argparse.ArgumentParser();ap.add_argument('--source',type=Path,required=True);ap.add_argument('--destination',type=Path,required=True);a=ap.parse_args()
    here=Path(__file__).resolve().parent;meta=json.loads((here/'PATCH_IDENTITY.json').read_text())
    source=a.source.resolve();dest=a.destination.resolve()
    if not source.is_dir():ap.error('Source must be an extracted R1 directory.')
    if dest.exists() or dest==source or source in dest.parents:ap.error('Destination must be a new directory outside the source tree.')
    if any(p.is_symlink()for p in source.rglob('*')):ap.error('Refusing symlinks in source tree.')
    original=source/'sat_group_compiler/receipts.py';replacement=here/'receipts.py'
    if sha(original)!=meta['before_sha256']:ap.error('Source file is not the reviewed R1 receipt checker.')
    if sha(replacement)!=meta['after_sha256']:ap.error('Replacement file does not match its recorded digest.')
    shutil.copytree(source,dest)
    shutil.copyfile(replacement,dest/'sat_group_compiler/receipts.py')
    record=dict(meta);record.update(source=str(source),destination=str(dest),kind='REVIEW_CANDIDATE_NOT_INTEGRATED',historical_hashes_json_not_a_candidate_manifest=True)
    (dest/'PATCH_APPLICATION.json').write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps(record,indent=2))

if __name__=='__main__':main()
