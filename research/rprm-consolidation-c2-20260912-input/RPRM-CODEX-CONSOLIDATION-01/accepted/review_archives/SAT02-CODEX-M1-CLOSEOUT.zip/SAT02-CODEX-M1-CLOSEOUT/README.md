# Independent review evidence for SAT02 Codex M1

Start with `REVIEW.md`; use `CLOSEOUT_MESSAGE.md` for a compact status transfer.
This folder is supporting acceptance evidence, not a new solver build and not
an integration or research assignment. The exact accepted implementation and
Codex evidence retain their original names/hashes in the review.

`results/ACCEPTANCE_SUMMARY.json` records final disposition and actual fresh-run
commands. `source_snapshots/` contains unchanged extracts of the delivered closeout,
claim ledger, integration metadata, seed status and diffs. `results/replay_*`
contains raw commands, stdout/stderr, environments and actual result rows.
`results/local_extension_diagnostic.json` is a new limited direct-set diagnostic;
it is separate from the inherited review's saved-row interpretation.

## Reproduction from a separately extracted active build

Use an existing Python runtime. Replace BUILD and OUTPUT with real paths. OUTPUT
must be fresh and outside the active build. No installations are needed here.

```text
python tools/replay_delivery.py --build BUILD --output OUTPUT
python -I -S -B tools/check_local_extension.py --build BUILD --output OUTPUT/local_extension.json
python -I -S -B tools/compare_receipt_versions.py --build BUILD --controls OUTPUT/rows/results/m1_boundary_controls.json --output OUTPUT/version_comparison.json
```

The first command runs manifest, tests, the same six regressions, saved rows and
inherited review, using isolated child runtimes. Inspect the rows, not merely an
exit code. A manifest replay after checks can be run with a second fresh output:

```text
python tools/replay_delivery.py --build BUILD --output SECOND_OUTPUT --checks manifest
```

`check_integrity.py` additionally compares the extracted evidence manifest and the
historical sources with the original R1, SAT02 and previous handoff archives. Its
CLI names all required inputs and writes only an external result.

The reviewer made no changes to submitted production code, protocols or saved
panels. Hashes in this folder's `MANIFEST.json` establish review-artifact identity
only and explicitly exclude that manifest itself.
