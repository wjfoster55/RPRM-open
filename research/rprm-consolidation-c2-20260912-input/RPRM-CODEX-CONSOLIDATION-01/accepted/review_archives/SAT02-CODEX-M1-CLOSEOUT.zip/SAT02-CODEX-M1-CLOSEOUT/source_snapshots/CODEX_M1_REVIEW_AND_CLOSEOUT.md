# CODEX M1 review and closeout

**Disposition: INTEGRATED_AND_VERIFIED_WITHIN_LOCAL_SCOPE.**
12 September 2026. SAT02 remains an accepted partial research closeout. Maintenance
is integrated into the delivered fresh successor, not into frozen owner-submitted
R1. The final ZIP was extracted and replayed successfully after export.

Delivered files:

- `SAT02-portable-codex-m1.zip` — the one active maintenance build, including current
  implementation, original 73 tests, six supplied regressions, saved panels,
  review dependencies, current manifest, and immutable historical handoff.
- `SAT02-portable-codex-m1.sha256` — build digest.
- `SAT02-codex-m1-final-evidence.zip` and its `.sha256` — separate final-extraction
  evidence, baseline failures, candidate counterexamples and all actual result rows.
- This `CODEX_M1_REVIEW_AND_CLOSEOUT.md` — readable disposition and scope.

The build SHA-256 is `8300b2643de12210c98897b7693d28d7a45d8ecce71a8f1842743b46f5788ca5`.
The evidence ZIP has its own external SHA-256 text file. It is intentionally not
embedded into the build, and neither archive contains its own hash or active export.

## What was integrated

Only one production file changed: `sat_group_compiler/receipts.py`, in its promise C
local projection/recovery branch. Promise A/B behavior remains unchanged.
The supplied candidate was **adopted with a relevant minimal correction**, rather
than accepted unchanged. It correctly repairs the two supplied cases:

1. Recovery output for a nonempty relation is confined to eliminated variables,
   preserving the retained boundary in both closed-form and table representations.
   Recovered values must be Boolean and satisfy the original stored local relation.
2. Recovery is unnecessary when the independently recomputed local relation is
   empty. Input-mask and replacement/projection checks still run; a false stored
   zero mask and TRUE-for-empty replacement remain rejected.

Independent inspection found the same boundary-overwrite defect when `eliminated=[]`.
This was reproduced against the actual candidate before the additional edit:

```json
{
  "promise": "C", "scope": [1, 2], "boundary": [1, 2], "eliminated": [],
  "input_identities": ["D:1,2"], "replacement": ["D:1,2"], "group_sat_mask": 6,
  "recovery": {"type": "closed_form", "map": {"1": ["lit", -1], "2": ["lit", -2]}}
}
```

The candidate accepted this receipt while recovery swapped `(0,1)` and `(1,0)`.
Both results satisfy the local disequality, but neither retains the requested
boundary. A table exchanging the same two assignments was also accepted. These
are canonical Boolean payloads, not a speculative parser-hardening concern.

M1 adds eight lines: on nonempty input with no eliminated variables, reject a
nonempty closed-form output map or a table row with nonempty internal outputs.
Absent recovery, empty identity forms and explicit table identity remain accepted.
The empty-relation case remains vacuous. The candidate and M1 outcomes, full
payloads, and before/after boundary traces are in
`candidate_row_audit/m1_boundary_controls.json` and
`final_saved_rows/m1_boundary_controls.json` inside the evidence archive.
Both attacks now reject specifically with `recovery_output_scope`.

| Checker | SHA-256 |
| --- | --- |
| Frozen R1 | `ececdfdfa4c074b094810c1b58cfe081086cfd638f7e04f34cfc5997184d0c8d` |
| Supplied reviewer candidate | `137d2748bffc085af709707275333a54166aa85229365fb2745f6f6bc0b3ea3f` |
| Integrated M1 | `ef05c2f7c31d61c5a3c647242c3d8eb75989f058d99f80595b5ee6c9b3b52bce` |

Both full R1→M1 and candidate→M1 diffs are delivered in `maintenance/` and copied
into the evidence. CRLF formatting was retained in the final checker.

## Verification actually performed

| Execution | Actual result |
| --- | --- |
| Transfer integrity before execution | Original ZIP digest, complete handoff manifest, input archive bindings and source mirrors verified |
| Disposable unpatched R1 | 73/73 original tests pass; three expected failures among six supplied regressions |
| Baseline saved receipt replay | 932 accepted, 50 rejected solely for `recovery_missing`; zero errors in the supplied review interpretation |
| Supplied candidate before M1 edit | 73/73 plus 6/6 pass; 982/982 saved receipts accepted; both additional no-elimination boundary attacks falsely accepted |
| Integrated M1, final checker bytes before export | 79/79 = 73 unchanged original tests + six unchanged supplied regressions; focused receipt controls pass |
| Final exported ZIP, fresh extraction | 79/79 pass; same six-case subset also rerun separately; no skipped tests |
| Final saved local replay | All 982 accepted, zero rejected, zero independent errors; every result row retained and inspected |
| Additional local diagnostics | All 23 control expectations met; these are controls, not additional scientific experiments |
| Inherited graph oracle | 4,396 comparisons across 1,099 labelled graphs pass; no duplicate/omission failures |
| Protected XOR | All 72 exact parity transformation cases pass |
| W3-T | TABLE structural score 15→18, then parity 23→6 retained |
| Native three-color | Star 21/27; pair projections 9,9,9; conjunction 147/243; wrong union atom 93/243 |
| Timer/claim diagnostic | Controlled 30 ms delay included in checker and wall time; failed receipt gives `receipt_rejected` and `UNRESOLVED` |
| Fingerprint diagnostic | Writing `versions.json` in a disposable copy leaves the source digest unchanged |
| Final integrity | Exact payload manifest passes before and after replay; original archived handoff verifies inside final extraction; original external handoff verifies again |

The baseline failures were exactly `test_closed_form_cannot_overwrite_boundary`,
`test_table_cannot_overwrite_boundary`, and `test_empty_relation_does_not_need_recovery`.
Their tracebacks show wrong Boolean accepts/rejects, not incidental exceptions.
The false-zero and wrong-empty-replacement controls passed on the baseline and
remain rejecting in M1. Wrong closed/table recovery, missing recovery, empty or
incomplete recovery tables, overlapping scope, nonbinary output and boundary writes
remain rejected. Empty input is also tested with a nonempty retained boundary.

Saved receipt distribution was smoke 89, stress 134, stage1 150, development 297,
evaluation 312: 982 receipts within 466 unchanged saved result rows. The replay
records retain original `candidate_status` counts, including UNRESOLVED and
RESOURCE_LIMIT rows; these statuses were not converted to successes. The 50 changed
acceptance decisions were matched by panel/row/receipt identity and independently
recomputed to mask zero, promise C, FALSE replacement and no recovery. Their exact
transitions are in `EMPTY_RECEIPT_50_TRANSITIONS.json`.

Actual rows, not aggregate PASS labels, were used for acceptance:

- `final_saved_rows/all_982_receipt_rows.json`: all 982 checker reports, input
  locator and payload digest, recomputed masks and independent-error lists.
- `final_review_rows/receipt_controls.json`: expected valid and hostile outcomes;
  unbound original IDs intentionally remain only a local accepted check.
- `final_saved_rows/m1_boundary_controls.json`: all 23 concrete payloads, expected
  and actual outcomes, rejection reasons and no-elimination recovery traces.
- `final_review_rows/xor_checks.json`, `native_check.json`, `group_oracle.json`,
  `timer_and_grade.json`, and `fingerprint_check.json`: actual specimen/diagnostic results.
- `FINAL_REPLAY_SUMMARY.json`, `FINAL_ZIP_EXTRACTION.json`, command receipts and
  environment records: final archive identity and execution provenance.

## Exact final replay and dependencies

Workspace: `C:\github\RPRM-open`.
Git HEAD: `9b5e132ee36334311f125027c2a719563890a3c1`; status was clean before and after maintenance.
All work products are under the ignored `.artifacts/sat02-m1-20260912/` directory.
Python: CPython 3.14.5 on Windows 11; executable
`C:\Users\bkbee\AppData\Local\Python\pythoncore-3.14-64\python.exe`.
The final build was freshly extracted outside the original workspace at:
`C:\Users\bkbee\AppData\Local\Temp\sat02-codex-m1-final-mjyc9mzi\sat_group_compiler_02_r1_codex_m1`.

The actual subprocesses used `-I -S -B`: isolated Python, no site packages, no
bytecode writes, and assertions enabled. From that extracted root they ran:

```text
python -I -S -B portable_check.py manifest --environment <external>/final_manifest_before_environment.json
python -I -S -B portable_check.py tests --environment <external>/final_79_environment.json
python -I -S -B portable_check.py regressions --environment <external>/final_six_environment.json
python -I -S -B portable_check.py review --output <external>/final_review_rows --environment <external>/final_review_environment.json
python -I -S -B portable_check.py rows --output <external>/final_saved_rows --environment <external>/final_row_audit_environment.json
python -I -S -B portable_check.py manifest --environment <external>/final_manifest_after_environment.json
python -I -S -B history/transfer/verify_handoff.py
```

These are readable command shapes. Every exact executable, argument, working
directory, checker hash, start time, duration, exit code and raw stdout/stderr is
retained in each `final_*/command.json` and adjacent output files. All final
subprocesses returned zero. The 79 discovered test IDs equal the disjoint union
of the 73 baseline IDs and six supplied IDs, with all outcomes `ok`.

The small portable launcher invokes the existing `run.py test`, standard unittest
discovery, and the unchanged supplied review script. It does not replace the solver
or alter tests. Its import guard was necessary because inherited backend probes
prepend hard-coded NariZoo paths even under isolated Python. Those external imports
were blocked and recorded; all loaded project modules came from the extracted build.
Python standard-library modules supplied the runtime. PySAT was unavailable in the
isolated environment; external NariZoo backends were deliberately unavailable.
The optional original performance environment was not reproduced or installed.

The supplied earlier interpreter is reused, with the supplied review's output-scope
guard. This is not a newly independent method. The additional row exporter stores
every outcome and exercises the concrete M1 boundary controls. Neither replay
entrypoint generates panels, supplies omitted seeds, or upgrades local receipts to
a whole original-instance derivation.

## Preserved history, limits and stop condition

Of 52 original R1 files, 49 remain byte-identical in the active successor. The only
changed originals are `receipts.py`, the current README and current claim ledger.
The complete original versions remain under `history/transfer/frozen_r1/`.
All compiler/grouping/protocol code, original tests, fixtures, three original
protocol files, `SEED_STATUS.json`, `HASHES.json` and `OWNER_RETURN.md` are unchanged.
The supplied six-regression file is unchanged. Current manifest verification
asserts the exact change boundary and zero deleted original files.

The full received handoff is retained byte-for-byte as history, including original
archives, source mirrors, old overlay and review failures. The original downloaded
ZIP remains digest `9c00868c188edf53f969d713f6e5bab7f06ee3eca26016b41c65fbe8d322b077`.
Old imperative documents are historical evidence. The active user instruction
authorized M1; it did not reactivate their optional future assignments.
`PATCH_APPLICATION.json` is preserved as the intermediate REVIEW_CANDIDATE record,
and root `HASHES.json` is explicitly historical. `M1_INTEGRATION.json` and
`M1_MANIFEST.json` identify this successor; the external final replay establishes
its completed verification without modifying the already-hashed ZIP.

Work-session imperfections are preserved: an early log parser missed CRLF test-ID
lines and was corrected by parsing the unchanged raw stderr; no test outcomes were
changed. The first integrated row-audit launch collided with the command-log
directory and stopped before inspecting data (`integrated_row_audit/`, exit 1).
It was rerun successfully with a fresh distinct output path
(`integrated_row_audit_retry/`, rows under `integrated_saved_rows/`). The preliminary
mixed-line-ending checker was normalized to the original CRLF convention, then the
final bytes and final ZIP were tested. Earlier records retain their actual hashes.
The candidate diagnostic initially counted an absent generic status field; the
final row audit reads actual `candidate_status`. No saved panel was modified.

The recovery correction concerns promise C on finite Boolean local relations with supplied
identities and a partition into retained and eliminated ports. For each satisfying
retained assignment, recovery must extend that same assignment and satisfy the
relation. Empty relations have an empty completion fiber. The evidence grade is
code inspection and bounded executable checks, not a formal or whole-solver proof.
Gratuitous recovery payloads on promises A/B received no new audit. General
malformed-input/parser hardening and arbitrary future receipt grammars
remain outside scope. Input factor IDs remain unbound, and all accepted saved rows
retain `binds_original_factor_ids=False` and `whole_solver_derivation_replayed=False`.

**6 RUN / 4 NOT_RUN is preserved:** development 23,29,31 and evaluation
20011,20021,20047 remain RUN; development 37,41 and evaluation 20063,20089 remain
NOT_RUN. W3-T is a local structural route, not a speedup. The correct 147/243
two-factor conjunction is retained; the 93/243 union substitution remains rejected.
Comparative speed, complete work budget, ten-seed completion, authenticated original
dispatch, whole-solver certification, a new tractable SAT family and P versus NP
claims remain withdrawn, limited or unclaimed. Unavailable historical inventories
were not reconstructed and presented as original evidence.

C1, Lind–Reichardt and AD's 14/16-versus-14/16 pilot stay closed. Fluid and Yang–Mills
remain undispatched. There was no panel rerun, seed backfill, Task03, general rewrite,
installation, commit, stage, push, merge, publication or other-lane dispatch. One
read-only reviewer assisted on this same checker task; the primary agent was the
sole writer. The bounded integration is complete; no next experiment is launched.
