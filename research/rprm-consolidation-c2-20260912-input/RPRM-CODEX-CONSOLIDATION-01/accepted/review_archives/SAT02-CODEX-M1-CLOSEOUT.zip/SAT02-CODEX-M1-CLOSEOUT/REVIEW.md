# SAT02 Codex M1 — independent maintenance acceptance

**12 September 2026 · ACCEPTED_WITHIN_LOCAL_SCOPE; maintenance assignment closed.**

The submitted M1 checker is integrated, not merely a reviewer-tested optional candidate. This review accepts the delivered maintenance successor after a fresh extraction and replay. The SAT02 research result remains accepted **as partial**, with the same six run seeds, four NOT_RUN seeds, exact local specimens and withdrawn comparative/whole-solver claims. No new blocker was found within this assignment's local relation/recovery scope.

## 1. Exact accepted artifact

Active build: `SAT02-portable-codex-m1.zip`  
SHA-256: `8300b2643de12210c98897b7693d28d7a45d8ecce71a8f1842743b46f5788ca5`

Paired Codex evidence: `SAT02-codex-m1-final-evidence.zip`  
SHA-256: `4ebfa840c085ddbdae557fac56838ff34b86c2790a76127278a46bdf2d2b34f7`

Integrated production checker: `sat_group_compiler/receipts.py`  
SHA-256: `ef05c2f7c31d61c5a3c647242c3d8eb75989f058d99f80595b5ee6c9b3b52bce`

The user supplied an outer working-session archive, `sat02-m1-20260912.zip`, SHA-256 `34cb02d108f4492e0f7e402a61b3361f38a0def9755a74256d1c07c54f59261f`. Its `deliverables/` directory contains the two named final archives and their matching SHA-256 files. Those exact inner archives, not an intermediate working directory, were independently extracted and replayed. The review does not alter or replace the accepted build.

## 2. Fresh work performed in this review

The replay used CPython 3.13.5 on Linux, with `-I -S -B`, assertions enabled, no package installation, and the supplied import guard. This is a separate replay from Codex's recorded Windows/CPython 3.14.5 run. Captured module-origin records report no unexpected imports. Optional original PySAT/NariZoo backends were not reproduced; the local checks do not require them.

| Check | New review result | Exact meaning |
|---|---|---|
| Build manifest | 215/215 listed files match; exact payload file set | Byte identity, not proof of mathematical truth |
| External evidence manifest | 139/139 listed files match; exact file set | Integrity of supplied historical and final evidence |
| Delivered unit tests | 79 distinct test IDs, all `ok` | 73 unchanged original tests + six unchanged supplied regressions |
| Regression subset | Same six pass again | A subset replay, not six additional tests |
| Saved local receipts | 982 accepted, zero inherited-interpreter errors, across 466 unchanged saved rows | Local relation/projection/recovery scope only |
| Focused controls | All 23 expected accepts/rejects and named reasons agree | Concrete diagnostics, not scientific trials |
| Inherited selector oracle | 4,396 comparisons across 1,099 labelled graphs pass | Small finite exhaustive grouping check |
| Protected parity | 72/72 transformations pass | Exact retained-boundary XOR specimens |
| Reviewer-derived extension diagnostic | 384/384 cases on all 16 two-bit relations pass | Additional canonical local recovery check, not a general verifier proof |

Actual row lists and rejection reasons were inspected; acceptance is not based solely on an aggregate `PASS`. All 982 saved reports retain `grade=local_relation_checked`, `binds_original_factor_ids=False`, and `whole_solver_derivation_replayed=False`. Source masks also match the independently recomputed masks in the delivered reference procedure.

The 982-row reference interpreter and the graph/XOR checks are inherited review code, freshly executed here. That replay is not presented as a newly independent implementation of those procedures. The additional `tools/check_local_extension.py` uses direct sets of two-bit assignments, not the submitted projection/recovery helpers, to determine its expectations. It tests both possible one-variable boundaries, all Boolean recovery functions in the two supported forms, absent recovery, identity forms, and forbidden writes when nothing is eliminated.

Evidence: `results/ACCEPTANCE_SUMMARY.json`, `results/replay_tests/`, `results/replay_rows/`, and `results/local_extension_diagnostic.json`.

## 3. What was integrated

Only one original production file differs from R1: `sat_group_compiler/receipts.py`. The original current README and claim ledger were also revised to identify the successor; their frozen versions remain in history. Compiler, grouping, protocol and original test files are unchanged.

### Boundary preservation

For a local relation R, with retained variables B and eliminated variables E, recovery must return a satisfying extension of **the same** retained assignment. Satisfying R after changing the input boundary is not enough.

For example, from `A != X`, fixing `A=0` permits recovery `X=1`. Returning `A=1, X=0` satisfies the disequality but violates the input boundary. M1 rejects both the closed-form and table versions of this overwrite. For nonempty relations with variables eliminated, output keys must be exactly E; recovered values must be Boolean and satisfy the supplied local relation.

### Empty relations

When the independently recomputed relation has no satisfying assignments, there is no satisfying boundary assignment to reconstruct. M1 correctly allows the empty projection without a recovery witness. It still checks the source relation, stored mask, and replacement. Claiming a false zero mask or substituting TRUE for an empty relation remains rejected.

A direct three-version replay confirms:

| Version | Accepted saved receipts |
|---|---:|
| Frozen R1 | 932/982 |
| Supplied reviewer candidate | 982/982 |
| Integrated M1 | 982/982 |

Exactly 50 historical receipts change from rejection to acceptance. Every one was rejected only for `recovery_missing` and has an empty local relation and FALSE replacement. These are corrections to the checker's false rejection of valid local contradictions, not fifty newly solved instances or corrected solver answers.

### Codex's additional no-elimination guard

The supplied candidate still permitted recovery to overwrite retained variables when `E=[]`, because the old branch skipped checking recovery in that case. Codex's example retains the disequality on both variables and complements both: the output still satisfies the relation but does not retain the requested boundary.

The eight-line addition rejects nonempty output maps/internal outputs when the input relation is nonempty and no variables are eliminated. Absent and empty identity forms remain accepted. Both additional overwrite attacks fail against the intermediate candidate and are correctly rejected by M1. The new guard is within the existing task; no new algebra or whole-solver proof is being claimed.

Evidence: `results/receipt_version_comparison.json` contains actual three-version outcomes, the 50 saved transitions, and all control payloads. `source_snapshots/review_candidate_to_m1.patch` and `r1_to_m1.patch` identify the changes.

## 4. Preserved research and history

All 52 original owner-submitted R1 files exactly match their copies in `history/transfer/frozen_r1/`; 49 remain identical in the active tree. The only three changed original files are the checker, README and claim ledger. No original file is deleted. All 146 files from the previous handoff match the delivered historical mirror. The five saved panel JSON files are byte-identical to the original SAT02 upload. The manifest still passes after all new checks.

The exact local specimens remain:

- Protected XOR/W3-T takes a temporary structural-score increase **15→18**, then a later replacement **23→6**. This is a scored local representation route, not elapsed time or a universal SAT shortcut.
- The three-color star has **21/27** extendable boundary assignments, with all nine assignments in each pair projection.
- The overlapping two-factor conjunction accepts **147/243** assignments. A single whole-union atom accepts only **93/243** and is not an equivalent replacement.
- The inherited group-ID, timing-boundary and self-writing fingerprint repairs remain in force. Their diagnostic replays do not supply a performance ranking.

Coverage remains development **23,29,31** and evaluation **20011,20021,20047** RUN; development **37,41** and evaluation **20063,20089** NOT_RUN. No panel generation, seed backfill, new scoring or solver benchmark occurred here.

Evidence: `results/independent_integrity.json`, the individual review JSON files under `results/replay_rows/review/results/`, and the preserved `source_snapshots/SEED_STATUS.json`.

## 5. Limits and final disposition

The accepted implementation checks finite, canonically represented local relation/projection/recovery claims with a declared retained/eliminated partition. It does not bind the stored identities to the original live solver factors or replay the full sequence from the original formula to an UNSAT conclusion. Comprehensive parser hardening, coercion aliases, gratuitous A/B recovery payloads, unsupported future grammars and arbitrary malformed inputs have not been certified.

No complete work-budget guarantee, comparative speed ranking, ten-seed completion, authenticated missing original dispatch, new tractable family, P versus NP result, or proof-assistant certification follows. Hash validation and finite software tests are distinct evidence kinds. The written recovery obligation helps explain the implementation but is not a machine-checked universal proof.

**Accept M1 within this scope and close the maintenance assignment.** Frozen R1 keeps its historical limitations; the active successor no longer has the two pending maintenance defects or the additional no-elimination overwrite defect tested here. No further SAT02 repair prompt, panel rerun, seed backfill or Task03 is requested by this review.

C1, Lind–Reichardt and the AD 14/16-versus-14/16 pilot remain closed. Fluid and Yang–Mills are not dispatched by this acceptance. No repository, commit, push, merge, installation, publication or other project state was changed. This review is a supporting evidence packet, not a successor implementation.
