"""Reviewer-derived finite recovery-law diagnostic, not a solver experiment.

Enumerates all 16 two-bit relations using direct Python sets (not the supplied
projection/recovery helpers). Compares the public local checker on canonical
receipts. No general parser or whole-solver certification is claimed.
"""
from __future__ import annotations
import argparse, itertools, json, sys
from pathlib import Path

def main() -> int:
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--build',type=Path,required=True)
    ap.add_argument('--output',type=Path,required=True)
    a=ap.parse_args(); root=a.build.resolve()
    if a.output.resolve().is_relative_to(root):
        raise ValueError('Output must remain outside frozen build')
    sys.path.insert(0,str(root))
    from sat_group_compiler.receipts import check_rewrite_receipt
    scope=[2,7]; records=[]
    def check(name,p,expected,kind):
        actual=check_rewrite_receipt(p)
        records.append({'name':name,'kind':kind,'payload':p,'expected_ok':expected,
                        'actual':actual,'matches':actual['ok'] is expected})
    for mask in range(16):
        states={bits for bits in itertools.product((0,1),repeat=2)
                if mask & (1<<(bits[0]+2*bits[1]))}
        atom=f'TBL:2,7:{mask:x}'
        for bindex in (0,1):
            eindex=1-bindex; bv=scope[bindex]; ev=scope[eindex]
            admitted={bits[bindex] for bits in states}
            proj=sum(1<<b for b in admitted)
            base={'promise':'C','scope':scope,'boundary':[bv],'eliminated':[ev],
                  'input_identities':[atom],'replacement':[f'TBL:{bv}:{proj:x}'],
                  'group_sat_mask':mask,'speculative':True}
            for outputs in itertools.product((0,1),repeat=2):
                expected=all(any(bits[bindex]==b and bits[eindex]==outputs[b] for bits in states)
                             for b in admitted)
                if outputs[0]==outputs[1]: spec=['const',outputs[0]]
                else: spec=['lit',bv if outputs==(0,1) else -bv]
                for form,recovery in [
                    ('closed',{'type':'closed_form','map':{str(ev):spec}}),
                    ('table',{'type':'lex_table','rows':[{'boundary':{str(bv):b},'internal':{str(ev):outputs[b]}}
                                                       for b in sorted(admitted)]})]:
                    check(f'{mask}/{bv}/{outputs}/{form}',dict(base,recovery=recovery),expected,'one_eliminated')
            check(f'{mask}/{bv}/missing',dict(base,recovery={}),not states,'missing_recovery')
        base={'promise':'C','scope':scope,'boundary':scope,'eliminated':[],
              'input_identities':[atom],'replacement':[atom],'group_sat_mask':mask,'speculative':True}
        for name,recovery in [
            ('absent',{}),('closed_empty',{'type':'closed_form','map':{}}),
            ('table_empty',{'type':'lex_table','rows':[]}),
            ('table_identity',{'type':'lex_table','rows':[{'boundary':{str(v):bits[i] for i,v in enumerate(scope)},'internal':{}}
                                                        for bits in sorted(states)]})]:
            check(f'{mask}/no_elimination/{name}',dict(base,recovery=recovery),True,'identity')
        for name,recovery in [
            ('closed_overwrite',{'type':'closed_form','map':{'2':['lit',-2],'7':['lit',-7]}}),
            ('table_overwrite',{'type':'lex_table','rows':[{'boundary':{str(v):bits[i] for i,v in enumerate(scope)},
                                                          'internal':{str(v):1-bits[i] for i,v in enumerate(scope)}}
                                                         for bits in sorted(states)]})]:
            check(f'{mask}/no_elimination/{name}',dict(base,recovery=recovery),not states,'no_elimination_write')
    bad=[r for r in records if not r['matches']]
    kinds={k:sum(r['kind']==k for r in records) for k in sorted({r['kind'] for r in records})}
    summary={'scope':'Canonical two-bit local extension/projection diagnostic. Not whole-solver or general parser proof.',
             'relations':16,'cases':len(records),'by_kind':kinds,'passed':len(records)-len(bad),'failures':bad,'rows':records}
    a.output.parent.mkdir(parents=True,exist_ok=True)
    a.output.write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps({k:v for k,v in summary.items() if k!='rows'},indent=2))
    return int(bool(bad))
if __name__=='__main__':
    raise SystemExit(main())
