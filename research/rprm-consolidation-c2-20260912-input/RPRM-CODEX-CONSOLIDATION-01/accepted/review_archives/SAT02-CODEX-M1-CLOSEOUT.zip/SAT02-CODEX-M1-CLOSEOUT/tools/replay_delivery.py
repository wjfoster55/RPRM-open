"""Replay only delivered M1 local checks. No panel generation or installs."""
from __future__ import annotations
import argparse, datetime as dt, hashlib, json, os, platform, subprocess, sys, time
from pathlib import Path

def main() -> int:
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--build',type=Path,required=True)
    ap.add_argument('--output',type=Path,required=True)
    ap.add_argument('--checks',nargs='+',default=['manifest','tests','regressions','rows','review'])
    args=ap.parse_args()
    root=args.build.resolve(); out=args.output.resolve()
    if out.is_relative_to(root):
        raise ValueError('Evidence must be outside build')
    allowed={'manifest','tests','regressions','rows','review'}
    if not set(args.checks)<=allowed or len(args.checks)!=len(set(args.checks)):
        raise ValueError('Invalid or duplicate check name')
    out.mkdir(parents=True,exist_ok=False)
    env=os.environ.copy()
    for key in ('PYTHONPATH','PYTHONHOME'):
        env.pop(key,None)
    jobs=[]
    for choice in args.checks:
        dest=out/choice; dest.mkdir()
        cmd=[sys.executable,'-I','-S','-B','portable_check.py',choice,'--environment',str(dest/'environment.json')]
        if choice in ('rows','review'):
            cmd.extend(['--output',str(dest/'results')])
        start=dt.datetime.now(dt.timezone.utc).isoformat(); t=time.perf_counter()
        try:
            p=subprocess.run(cmd,cwd=root,env=env,capture_output=True,timeout=120)
            code=p.returncode; stdout=p.stdout; stderr=p.stderr; timeout=False
        except subprocess.TimeoutExpired as exc:
            code=None; stdout=exc.stdout or b''; stderr=exc.stderr or b''; timeout=True
        (dest/'stdout.txt').write_bytes(stdout); (dest/'stderr.txt').write_bytes(stderr)
        record={'job':choice,'command':cmd,'cwd':str(root),'started_utc':start,'elapsed_s':time.perf_counter()-t,
                'exit_code':code,'timed_out':timeout,'stdout_sha256':hashlib.sha256(stdout).hexdigest(),
                'stderr_sha256':hashlib.sha256(stderr).hexdigest(),'scope':'Delivered local checks, not a new panel'}
        (dest/'command.json').write_text(json.dumps(record,indent=2)+'\n')
        jobs.append(record)
        print(choice,code,round(record['elapsed_s'],3),flush=True)
        print(stdout.decode(errors='replace')[-1500:],flush=True)
        print(stderr.decode(errors='replace')[-1500:],flush=True)
    result={'python':sys.version,'platform':platform.platform(),'build':str(root),
            'checker_sha256':hashlib.sha256((root/'sat_group_compiler/receipts.py').read_bytes()).hexdigest(),
            'all_commands_exit_zero':all(j['exit_code']==0 for j in jobs),'jobs':jobs,
            'scope':'New replay of delivered tests, inherited review and saved rows; no newly independent oracle implied; no panels'}
    (out/'replay_summary.json').write_text(json.dumps(result,indent=2)+'\n')
    return 0 if result['all_commands_exit_zero'] else 1
if __name__=='__main__':
    raise SystemExit(main())
