"""Replay saved local receipts and concrete controls under three historical checkers.

Sibling production dependencies are byte-identical between the versions (verified
separately); checker files are imported under distinct names within that package.
No panels are generated, and no input/source file is altered.
"""
import argparse, hashlib, importlib.util, json, sys
from pathlib import Path

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--build',type=Path,required=True);ap.add_argument('--controls',type=Path,required=True)
    ap.add_argument('--output',type=Path,required=True)
    a=ap.parse_args();root=a.build.resolve();sys.path.insert(0,str(root))
    paths={'R1':root/'history/transfer/frozen_r1/sat_group_compiler/receipts.py',
           'review_candidate':root/'history/transfer/review/candidate_patch/receipts.py',
           'M1':root/'sat_group_compiler/receipts.py'}
    modules={}
    for name,p in paths.items():
        spec=importlib.util.spec_from_file_location('sat_group_compiler._compare_'+name,p)
        mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);modules[name]=mod
    rows=[];counts={name:0 for name in paths}
    for panel in ('smoke','stress','stage1','development','evaluation'):
        for ri,r in enumerate(json.loads((root/'saved/results'/f'{panel}.json').read_text())):
            for ci,payload in enumerate(r.get('receipts',[])):
                verdicts={name:mod.check_rewrite_receipt(payload) for name,mod in modules.items()}
                for name,v in verdicts.items():counts[name]+=int(v['ok'])
                if len({v['ok'] for v in verdicts.values()})>1:
                    rows.append({'panel':panel,'row':ri,'receipt':ci,'payload':payload,'verdicts':verdicts})
    controls=[]
    for c in json.loads(a.controls.read_text()):
        vs={name:mod.check_rewrite_receipt(c['payload']) for name,mod in modules.items()}
        controls.append({'name':c['name'],'expected_ok':c['expected_ok'],'payload':c['payload'],'verdicts':vs})
    failed={name:[c['name'] for c in controls if c['verdicts'][name]['ok']!=c['expected_ok']] for name in modules}
    assert counts=={'R1':932,'review_candidate':982,'M1':982},counts
    assert len(rows)==50
    assert all(r['verdicts']['R1']['reasons']==['recovery_missing'] and r['payload']['group_sat_mask']==0
               and r['payload']['replacement']==['F'] for r in rows)
    assert not failed['M1']
    summary={'scope':'Saved receipts and supplied controls only; no original-instance solver certification.',
             'version_hashes':{name:hashlib.sha256(p.read_bytes()).hexdigest() for name,p in paths.items()},
             'accepted_of_982':counts,'changed_saved_receipts':len(rows),'failed_controls':failed,
             'saved_transitions':rows,'control_results':controls}
    a.output.write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps({k:v for k,v in summary.items() if k not in ('saved_transitions','control_results')},indent=2))
if __name__=='__main__':main()
