"""Check M1 archive identity, both manifests, and unchanged historical inputs."""
from __future__ import annotations
import argparse, hashlib, json, re
from pathlib import Path
from zipfile import ZipFile

def sha(b:bytes)->str: return hashlib.sha256(b).hexdigest()
def archived_files(zpath:Path)->dict[str,bytes]:
    with ZipFile(zpath) as z:
        rows=[i for i in z.infolist() if not i.is_dir()]
        assert z.testzip() is None
        # Submitted source archives have a single directory prefix.
        prefixes={i.filename.split('/',1)[0] for i in rows}
        assert len(prefixes)==1
        return {i.filename.split('/',1)[1]:z.read(i) for i in rows}

def manifest(root:Path,name:str)->dict:
    doc=json.loads((root/name).read_text())
    rows=doc['files']; paths=[r['path'] for r in rows]
    actual={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()}
    assert len(paths)==len(set(paths))
    assert actual==set(paths)|{name}, (actual-set(paths)-{name},set(paths)-actual)
    bad=[]
    for r in rows:
        p=(root/r['path']).resolve()
        assert p.is_relative_to(root) and not p.is_symlink()
        b=p.read_bytes()
        if len(b)!=r['bytes'] or sha(b)!=r['sha256']: bad.append(r['path'])
    assert not bad,bad
    return {'manifest':name,'files':len(rows),'passed':len(rows),'failure_paths':bad,'exact_file_set':True}

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--build',type=Path,required=True);ap.add_argument('--evidence',type=Path,required=True)
    ap.add_argument('--r1',type=Path,required=True);ap.add_argument('--sat02',type=Path,required=True)
    ap.add_argument('--handoff',type=Path,required=True);ap.add_argument('--output',type=Path,required=True)
    a=ap.parse_args(); p=a.build.resolve(); e=a.evidence.resolve()
    result={'build_manifest':manifest(p,'M1_MANIFEST.json'),'evidence_manifest':manifest(e,'EVIDENCE_MANIFEST.json')}
    r1=archived_files(a.r1); unchanged=[]; changed=[]
    for path,b in r1.items():
        assert (p/'history/transfer/frozen_r1'/path).read_bytes()==b,path
        assert (p/path).is_file(),path
        (unchanged if (p/path).read_bytes()==b else changed).append(path)
    assert set(changed)=={'README.md','CLAIM_LEDGER.md','sat_group_compiler/receipts.py'}
    result['original_r1']={'sha256':sha(a.r1.read_bytes()),'files':len(r1),'historical_exact':len(r1),
        'unchanged_active':len(unchanged),'changed_active':changed,'deleted':[]}
    original=archived_files(a.sat02);panels=[]
    for panel in ['smoke','stress','stage1','development','evaluation']:
        rel=f'results/{panel}.json';b=original[rel]
        assert b==(p/'saved'/rel).read_bytes(),rel
        panels.append({'path':rel,'sha256':sha(b),'result_rows':len(json.loads(b))})
    result['original_panels']={'source_zip_sha256':sha(a.sat02.read_bytes()),'files':panels,'all_identical':True}
    handoff=archived_files(a.handoff)
    for path,b in handoff.items():assert b==(p/'history/transfer'/path).read_bytes(),path
    result['historical_handoff']={'sha256':sha(a.handoff.read_bytes()),'files':len(handoff),'all_identical':True}
    result['seed_status']=json.loads((p/'SEED_STATUS.json').read_text())
    result['checker_sha256']=sha((p/'sat_group_compiler/receipts.py').read_bytes())
    result['accepted_manifest_and_sources_only']=True
    a.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
if __name__=='__main__':main()
