# RCF01 Codex C1 — acceptance and closeout

**12 September 2026 · ACCEPTED_WITHIN_SCOPE**

The submitted C1 successor completes the bounded independent-review and runtime-integration assignment. The mathematical/API capability is accepted within its declared finite domain. The runner-report repair and the additional coherent-transport admission repair are implemented and replay successfully. This review found no new blocker within that scope. No further repair assignment is issued.

This is a closeout of the exact finite capability, not a declaration that every recovered RPRM concept is formalized. The active artifact remains the submitted `RCF01-portable-codex-c1.zip`; the reviewer did not edit, repackage or replace it.

## Artifact identities

| Artifact | SHA-256 |
|---|---|
| Active C1 build | `5a33fe48bb7f868fdfa11d0baa23aa2a158bba04e3e5f341b2962bae8c82328b` |
| Codex final-export evidence | `77f1c0f48c9eefc5bac6fe400b2064a0215b2b45efab65f19dec0cee211fba1b` |
| C1 envelope source | `e5ad46b6a8dc863b19f41a279ffeed882dad8ad6670a644fc4b3c71bebe59d68` |
| Unchanged mathematical protocol | `33ea582ebd832869c204cac061360899c8e9b7b39b5c668adb1ea2f7b61d8508` |

Both uploaded SHA-256 sidecars match. The final-export evidence is external to the immutable build, avoiding a circular self-hash. Hashes establish byte agreement, not scientific truth or authentication of an author. See [intake](results/intake.json).

## What was independently done in this review

The ZIPs were inspected for duplicate names, unsafe paths and symlinks, CRC-checked, and extracted into new directories. A reviewer-written manifest check compared file sets, lengths and SHA-256 independently of the supplied verifier. The actual original R2 ZIP available in this conversation was compared against the successor and its retained history.

The root C1 entrypoint was then executed from the extraction with only its packaged project dependencies. The environment was Python 3.13.5 on Linux; the submitted Codex replay records Python 3.14.5 on Windows. `PYTHONPATH` and `PYTHONHOME` were removed for the child environment, user-site/bytecode writes disabled, and direct entrypoints invoked with `-I -B`. This establishes successful execution in these recorded environments, not universal platform compatibility.

| Evidence | New review result |
|---|---|
| C1 file manifest | All 1,290 listed payload files match; manifest is the 1,291st, self-excluded file. No missing or unlisted files. |
| External evidence manifest | All 351 listed files match; manifest is the 352nd, self-excluded file. |
| Original R2 preservation | All 115 original files remain byte-for-byte recoverable from unchanged paths or retained historical copies. |
| Actual root replay | Exit 0, printed PASS and JSON PASS; envelope 28/28 and starter 12/12. |
| Actual coverage controls | Omission, duplication and substitution rejected for coverage; reordered complete case set passes. |
| Concept preservation | All 13 entries retain semantic/source fields and checked artifact links. Deferred scope remains visible. |
| Codex direct-table/API test rerun | 9 groups, 317 assertions PASS. This is a new execution of Codex-authored tests, not newly authored reviewer tests. |
| Codex independent mathematical script rerun | Inverse transform, 64 basis-product pairs, 216 site-retention criteria and 216 single-map least repairs PASS. |
| Runner-only controls | 5/5 prescribed aggregate scenarios and 8/8 report scenarios have the intended disposition. |
| Direct report-guard fixtures | 26/26 PASS. |
| Reviewer-derived additional checks | 16 composed distributivity trials / 256 exact output-value comparisons; 16 valid coherent maps and 7 invalid-map rejections; 5,832 two-map/retained-subset least-repair comparisons PASS. |

The additional arithmetic expressions were evaluated through the public envelope API and compared with direct rational tables. Their arithmetic performed zero backing-file reads, while creating 80 separately counted composition recipes. Later reconstruction reads are not counted as free. These are bounded development checks, not a speed test, held-out scientific evaluation, independent physical trials, or formal verification of all Python behavior.

The runner-fixture checks deliberately substitute child programs or reports. They test result handling, not new mathematics. Their receipts remain separate from the actual envelope/starter replay. See [root replay](results/replay/portable_summary.json), [independent direct checks](results/independent_closeout.json), [runner scenarios](results/runner_controls.json), [report scenarios](results/runner_receipts.json), and [direct guard checks](results/guard_edges.json).

## What the independent Codex review added

### 1. The remaining runner repair is integrated

The runner now requires a JSON object, nonempty well-formed case rows, every case passing, and the exact unique IDs supplied by the protocol. A bare PASS, empty results, contradictory failed row, absent/duplicate/unexpected ID, and non-object JSON are not accepted as a completed successful suite. A negative-control child must supply its expected coverage-rejection evidence; an unrelated crash does not count. Starter failure participates in the aggregate unless explicitly skipped with the narrower scope reported. Printed, saved and process-exit verdicts agree in the exercised scenarios.

This guard validates report structure and declared obligations. It is not a cryptographic attestation that an adversarial child did real mathematics. Genuine replay and separate source identities remain necessary.

### 2. One additional production admission defect is fixed

The prior `coherent_transport` checked map length but not the allowed site values. Consequently an eight-entry map filled with -1 or 8 could produce an exact empty answer instead of rejecting out-of-carrier input. C1 invokes the existing site-map validator before computing the receiver or attempting reopening. It rejects the malformed lengths, types and indices in the reproduced tests.

A valid constant map to site 7 still has an empty transported receiver, because no new site maps into the old seven-site receiver. Its exact empty readout is legitimate for that question; it is not a determination of the missing original value. Valid coordinate/view transport retains its positive behavior. No algebraic rule or existing 28-case protocol was changed by this three-line admission repair.

### 3. The quotient description corrects the proof terminology

Let A be all rational-valued laws on the eight-site Boolean cube. Restriction to B2, the seven retained sites, is a surjective algebra homomorphism. Its kernel is the ideal of laws supported only at the omitted site: `Q*hxy`. Thus the compact algebra is `A/(Q*hxy)`, equivalently `Q^B2`.

The natural degree-at-most-two representatives are not themselves closed under full multiplication: `hx * y = hxy`, outside their degree bound. The retained product is zero because hxy vanishes at all retained sites. This is not a claim that the full product equals zero.

Codex correctly identified that the old wording “product subalgebra of Q^X” conflated these constructions. A different zero-extension embedding does form a nonunital subalgebra, but it is not the chosen polynomial-representative embedding. The exact arithmetic and its proof survive; the current carry-forward supplies the precise quotient terminology while historical proofs retain their original bytes.

This matters for interpretation: the compact unit preserves equivalence for the stated work, not every difference between full constructions. A later operation can make one previously omitted difference observable.

## The accepted capability

For exact rational tables on `{0,1}^3`, C2 retains seven low-degree coefficients. The prototype supports exact retained addition and multiplication, sound Boolean/rational output-family handling, specified operation-admission checks, and explicit reopening of composed recipes when additional information is needed.

The example `p=(h*x)*y`, `s=p+p` is concrete: both compact summaries are zero, p is Boolean-valued, s is rational-valued, and the backed composed result has omitted value 2. The hot arithmetic does not read that omitted value. Without the required retained backing, the API returns a reopening/uncertainty outcome rather than silently choosing zero. A unique compact answer is not a uniquely identified complete source law.

The associated retained-site theorem says that fixed-receiver pullback by H can be computed from arbitrary law values retained on S exactly when `H(S) subseteq S`. Closing S under admitted maps gives the least sufficient retained-site superset. The proof is conditional on the arbitrary-law and retained-site setting; the finite tests do not enlarge it to all encodings or constrained families.

Finite fiving, retained winding, and Double-Stamp enabledness remain separately typed constructions. Their verified examples complement the exact-reuse capability but do not constitute an automatic cross-carrier equivalence.

## Limitations that remain, without reopening this task

The API conservatively requests reopening for some unbacked affine flips even though an honest affine guarantee would determine the missing value. It does not exploit that available optimization. Coherent transport attempts backing before its hot fallback, so it can perform an unnecessary read. No runtime advantage is established.

Legacy `MANY/REOPEN_REQUIRED` must be read as operational insufficiency, not as a complete enumerated rational source family. Damaged backing is not proof that no mathematical state exists. The constructor/API contract does not cover arbitrarily forged internal Python objects or all operating-system/process failures.

Original historical donor trees remain unavailable and were not replayed here. Their retained receipts are historical evidence, not fresh verification. Prestige acquisition, the broader lifecycle, approximate regrouping and general candidate-family propagation are not completed by this prototype. Fiving splice ↔ Double-Stamp A5 restart remains OPEN. The registered unexecuted concepts and partially deferred subcapabilities remain NOT_RUN.

These are defined boundaries of acceptance, not a new repair checklist. The accepted finite result should be retained and reused with its exact conditions; broader work requires a separate question and assignment.

## Preservation and execution hygiene

The submitted archives and all 1,290 manifest-listed source files were rehashed after execution and remained unchanged. No repository operation, publication, package installation or external service was used. The original workspace's git condition is reported by Codex, not independently observable from this review environment.

One reviewer-local orchestration script initially had an unclosed list and failed to parse before any product test executed. The startup stderr is retained as [reviewer-local error](results/reviewer_initial_syntax_error.log). The corrected orchestration then completed all eight jobs at exit 0; this was not a C1 product failure. The unavailable streaming execution route was not used for any result.

## Disposition

**Accept and close the bounded RCF01 recovery/implementation review at C1.** Keep the unchanged official build, its external Codex evidence and this acceptance record together. Use `CARRY_FORWARD_CODEX.md` in the official package as the detailed rebrief. The short [carry-forward decision](CLOSEOUT_MESSAGE.md) records the result without issuing another repair or research assignment.
