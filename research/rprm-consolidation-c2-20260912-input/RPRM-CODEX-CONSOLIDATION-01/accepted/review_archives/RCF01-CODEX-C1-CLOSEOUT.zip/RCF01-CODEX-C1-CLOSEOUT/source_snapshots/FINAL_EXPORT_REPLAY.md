# Final exported ZIP replay — RCF01 Codex C1

12 September 2026. **CORRECTED_AND_REVERIFIED.** This certifies the actual
final ZIP, extracted into a new directory and executed there. The ZIP was
not modified after hashing or replay. These records are external to it.

- ZIP: `RCF01-portable-codex-c1.zip` (1,716,903 bytes; 1291 files).
- SHA-256: `5a33fe48bb7f868fdfa11d0baa23aa2a158bba04e3e5f341b2962bae8c82328b`.
- Root entrypoint: `run_portable.py`.
- Extracted root: `C:\github\RPRM-open\.artifacts\RCF01-CODEX-R3-20260912\final_extract\RCF01-portable-codex-c1`.
- Environment: existing Python 3.14.5 / Windows 11; PYTHONPATH/PYTHONHOME
  cleared in the child environment, user-site and bytecode writes disabled.
- Exit 0; JSON PASS and printed PASS agree; starter included.

Actual direct entrypoint command (complete argv/environment are also in
[execution context](replay_execution/context.json)):

```text
C:\Users\bkbee\AppData\Local\Python\pythoncore-3.14-64\python.exe -I -B C:\github\RPRM-open\.artifacts\RCF01-CODEX-R3-20260912\final_extract\RCF01-portable-codex-c1\run_portable.py --output-dir C:\github\RPRM-open\.artifacts\RCF01-CODEX-R3-20260912\final_evidence\replay
```

| Real mathematical/export job | Exit | Actual aggregate reason |
|---|---:|---|
| envelope | 0 | PASS receipt with complete case coverage |
| omit | 2 | coverage rejection |
| duplicate | 2 | coverage rejection |
| unexpected | 2 | coverage rejection |
| reorder | 0 | PASS receipt with complete case coverage |
| ids | 0 | PASS record |
| export | 0 | PASS record |
| starter | 0 | PASS receipt with complete case coverage |

The main envelope has 28/28 PASS case records; the starter has 12/12.
Omit/duplicate/unexpected return nonzero specifically for coverage rejection;
reorder retains the complete case set. These are actual mathematical runs,
not fixture substitutions. See [complete aggregate](replay/portable_summary.json),
[envelope](replay/envelope_r2.json), [starter](replay/starter_replay.json),
[parent stdout](replay_execution/stdout.txt) and the complete child streams in
`child_streams/`. Every child stream is below the inherited runner's 4,000
character truncation threshold; no stream content was lost in this replay.

Additional tests against this extraction:

- [Eight real-runner reporting fixtures](receipts.json): valid case accepted;
  the other seven rejected with structured FAIL and nonzero exit. These reuse
  this final replay's receipts as explicit synthetic fixtures, not new math.
- [Five producer runner controls](runner_fixtures/controls/runner_controls.json):
  starter failure, export failure and wrong-reason crash correctly fail;
  good run and explicit starter skip pass, with the latter's narrower scope.
- [Twenty-six direct report-guard checks](guards.json): PASS.
- [Independent direct API suite](api.json): 9 groups / 317 assertions PASS.
- [Transport admission regressions](boundary.json): malformed lengths,
  types and site indices rejected; valid `(7,)*8` remains an exact empty
  moved receiver; valid coherent transport survives missing/invalid backing
  when retained observations suffice. The observation harness's literal
  status is OBSERVATIONS_REPRODUCED with `expect_transport_validation=true`.
- [Integrity and semantics](integrity.json): all 1,290 manifest-listed files
  and manifest itself match; all 13 concept records and their artifact links
  survive. The fully deferred IDs and F3's partially deferred marker remain.
- [Preservation](preservation.json): exact reconstruction of all 115 frozen R2
  files; handoff untouched, original incoming ZIP hash unchanged, repository
  HEAD unchanged and ordinary git status clean. Task artifacts are ignored.

The envelope's C1 source is
`e5ad46b6a8dc863b19f41a279ffeed882dad8ad6670a644fc4b3c71bebe59d68`.
The mathematical protocol remains
`33ea582ebd832869c204cac061360899c8e9b7b39b5c668adb1ea2f7b61d8508`.
The successor includes two separately justified repairs: the supplied
runner-report guard and an independently reproduced coherent-map admission
guard. It preserves R2's algebra and passing evidence; changed original files
are retained under `history/r2_runtime/` and exact R2 restoration is tested.

`CODEX_REVIEW_AND_CLOSEOUT.md` and `CARRY_FORWARD_CODEX.md` inside the successor
provide the independent judgment and self-contained capability account.
The original source meanings of Prestige One, fiving/FIVE_IS_SAFE and
cube/abduction remain core. Fiving splice versus Double-Stamp restart is OPEN;
deferred concepts are NOT_RUN. Historical donor code was unavailable and was
not replayed. No publication, installation, commit or other-project work was
performed. The bounded task is complete.

[Final machine-readable verdict](FINAL_VERDICT.json) records all actual commands,
exits and unchanged ZIP identity. Hashes bind bytes; they do not prove claims.
