# Reproduce this acceptance

Use the unchanged official `RCF01-portable-codex-c1.zip` supplied by the user, not this smaller evidence ZIP as a replacement implementation. Extract it and choose new external output paths. Standard-library Python is sufficient.

```text
python -I -B /path/to/RCF01-portable-codex-c1/run_portable.py --output-dir /new/path/replay
python -I -B /path/to/RCF01-portable-codex-c1/verify_successor.py --root /path/to/RCF01-portable-codex-c1 --output /new/path/integrity.json
python -I -B scripts/independent_closeout_checks.py --package /path/to/RCF01-portable-codex-c1 --work /new/path/reviewer_work --output /new/path/reviewer_checks.json
```

The official package's `REPLAY_COMMANDS.md` supplies its additional API, mathematical and runner-fixture commands. This review's `results/execution/*/context.json` preserves actual commands, environments and exits, with original absolute paths as evidence rather than portable commands.

This evidence bundle includes the full top-level child receipts, not disposable fixture package copies. The scripts in the official package reproduce those fixtures. The attributed source snapshots retain their original bytes; their internal relative links refer to the official source tree.
