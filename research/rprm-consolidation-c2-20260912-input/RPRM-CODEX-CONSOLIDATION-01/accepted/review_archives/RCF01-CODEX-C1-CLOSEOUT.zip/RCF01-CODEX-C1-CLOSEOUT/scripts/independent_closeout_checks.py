"""Reviewer-derived direct-table and finite-closure checks, no checker imports.
This is additional exposed development evidence, not independent physical trials.
"""
from pathlib import Path
from fractions import Fraction as Q
import argparse, importlib.util, sys, json, random, itertools, hashlib

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--package',type=Path,required=True);ap.add_argument('--work',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);a=ap.parse_args()
 a.work.mkdir(parents=True,exist_ok=False)
 src=a.package/'experiments/core_recovery_bridge_01_r2/prestige_envelope.py'
 spec=importlib.util.spec_from_file_location('closeout_envelope',src);e=importlib.util.module_from_spec(spec);sys.modules[spec.name]=e;spec.loader.exec_module(e)
 assert Path(sys.modules['rprm.core'].__file__).resolve()==(a.package/'rprm/core.py').resolve()
 contract=e.FULL_CUBE_CONTRACT|frozenset({'identity'});rng=random.Random(20260912);rows=[]
 def exact(r):
  assert r.disposition=='ONE' and r.status=='EXACT',repr(r)
  return r.value
 def table(env):return tuple(exact(e.read_admitted(env)))+(exact(e.inspect_omitted(env)),)
 count=0;hotreads=[]
 for i in range(16):
  tables=[tuple(Q(rng.randrange(-3,4),rng.randrange(1,5)) for _ in range(8)) for j in range(3)]
  units=[e.promote_cube(t,label='one',contract=contract,cold_dir=a.work/'cold',name=f'{i}_{j}') for j,t in enumerate(tables)]
  e.reset_meter();u,v,w=units
  left=exact(e.multiply_units(exact(e.add_units(u,v)),w))
  right=exact(e.add_units(exact(e.multiply_units(u,w)),exact(e.multiply_units(v,w))))
  m=e.meter_snapshot();assert m['cold_reads']==0;hotreads.append(m)
  reference=tuple((x+y)*z for x,y,z in zip(*tables))
  assert table(left)==reference==table(right);count+=16
 rows.append({'name':'composed_distributivity','trials':16,'exact_value_comparisons':count,'hot_cold_reads':sum(m['cold_reads'] for m in hotreads),'recipe_constructions':sum(m['constructions'] for m in hotreads),'outcome':'PASS'})
 # The degree<=2 representative is not a multiplicatively closed embedding.
 hx=tuple(Q((s&1)*((s>>1)&1)) for s in range(8));y=tuple(Q((s>>2)&1) for s in range(8));hxy=tuple(x*z for x,z in zip(hx,y));assert hxy==(Q(0),)*7+(Q(1),)
 u=e.promote_cube(hx,label='one',contract=contract,cold_dir=None,name='hot_hx',family='boolean_cube');v=e.promote_cube(y,label='one',contract=contract,cold_dir=None,name='hot_y',family='boolean_cube');p=exact(e.multiply_units(u,v));s=exact(e.add_units(p,p))
 assert exact(e.read_admitted(p))==(Q(0),)*7 and s.family=='rational_cube'
 assert e.inspect_omitted(s).status=='REOPEN_REQUIRED'
 rows.append({'name':'quotient_not_degree_two_subalgebra','full_hx_times_y':list(map(str,hxy)),'retained_product':list(map(str,exact(e.read_admitted(p)))),'sum_family':s.family,'omitted_status':e.inspect_omitted(s).status,'outcome':'PASS'})
 # Coherent preimages may be smaller/larger, without claiming inverse or full recovery.
 t=tuple(Q(s*s-2*s,3) for s in range(8));u=e.promote_cube(t,label='one',contract=contract,cold_dir=None,name='hot_transport');maps=[tuple((s+k)%8 for s in range(8)) for k in range(8)]+[(k,)*8 for k in range(8)]
 for mp in maps:
  got=exact(e.coherent_transport(u,mp));want=tuple((s,t[mp[s]]) for s in range(8) if mp[s]<7);assert got==want
 for bad in [(-1,)*8,(8,)*8,(True,)*8,(0.0,)*8,('0',)*8,(0,)*7,(0,)*9]:
  r=e.coherent_transport(u,bad);assert r.status=='UNSUPPORTED' and r.value is None
 rows.append({'name':'coherent_receiver_admission','valid_maps':len(maps),'malformed_maps_rejected':7,'all_7_receiver':list(exact(e.coherent_transport(u,(7,)*8))),'outcome':'PASS'})
 # Independent test of simultaneous-map leastness, including empty/full retained sets.
 X=range(3);subsets=[frozenset(i for i in X if mask>>i&1) for mask in range(8)];maps=list(itertools.product(X,repeat=3));pairs=0
 for A,B in itertools.product(maps,repeat=2):
  for S in subsets:
   R=S
   while True:
    N=R|frozenset(A[x] for x in R)|frozenset(B[x] for x in R)
    if N==R:break
    R=N
   allowed=[T for T in subsets if S<=T and all(A[x] in T and B[x] in T for x in T)]
   assert R==frozenset.intersection(*allowed);pairs+=1
 rows.append({'name':'least_repair_two_maps','carrier_sites':3,'map_pairs':729,'subset_map_pair_checks':pairs,'outcome':'PASS'})
 result={'status':'PASS','scope':'Reviewer-derived finite development checks, separate from supplied-suite replay and written proofs','source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'groups':rows}
 a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
