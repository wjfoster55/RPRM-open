"""M1 work-session subprocess receipts; not a replacement test runner."""
import datetime
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import time

BASE = Path(__file__).resolve().parent
HANDOFF = BASE / 'SAT02-CODEX-CLOSEOUT-01'
EVIDENCE = BASE / 'evidence'
EVIDENCE.mkdir(exist_ok=True)
PYTHON = sys.executable

def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def record(name, args, cwd, expected=0):
    folder = EVIDENCE / name
    folder.mkdir(parents=True, exist_ok=False)
    before = sha(cwd / 'sat_group_compiler/receipts.py') if (cwd / 'sat_group_compiler/receipts.py').exists() else None
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    t = time.perf_counter()
    run = subprocess.run([str(v) for v in args], cwd=cwd, capture_output=True)
    (folder / 'stdout.txt').write_bytes(run.stdout)
    (folder / 'stderr.txt').write_bytes(run.stderr)
    err = run.stderr.decode('utf-8', errors='replace').replace('\r\n', '\n')
    ids = [{'test': m[0], 'outcome': m[1]} for m in re.findall(r'^(test_\S+ \([^\n]+\)) \.\.\. (ok|FAIL|ERROR|skipped[^\n]*)$', err, re.M)]
    payload = {'argv': [str(v) for v in args], 'command_windows': subprocess.list2cmdline([str(v) for v in args]),
        'cwd': str(cwd), 'started_utc': started, 'duration_s': time.perf_counter() - t,
        'returncode': run.returncode, 'expected_returncode': expected, 'checker_sha256_before': before,
        'checker_sha256_after': sha(cwd / 'sat_group_compiler/receipts.py') if before else None,
        'test_outcomes': ids, 'stdout_sha256': sha(folder / 'stdout.txt'), 'stderr_sha256': sha(folder / 'stderr.txt')}
    (folder / 'command.json').write_text(json.dumps(payload, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'name': name, 'returncode': run.returncode, 'tests': len(ids),
        'failures': [x for x in ids if x['outcome'] != 'ok']}, indent=2), flush=True)
    if run.returncode != expected:
        print(run.stdout.decode('utf-8', errors='replace'), err, flush=True)
        raise RuntimeError(name)
    return payload
