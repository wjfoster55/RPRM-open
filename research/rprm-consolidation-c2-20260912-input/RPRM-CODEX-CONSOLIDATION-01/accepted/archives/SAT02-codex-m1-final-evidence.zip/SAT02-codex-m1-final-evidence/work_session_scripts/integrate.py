import difflib
import json
import re
import shutil
from record import BASE, HANDOFF, EVIDENCE, PYTHON, record, sha

# Re-extract test identities from CRLF logs; no tests rerun or outcomes changed.
for folder in [EVIDENCE/'baseline_73', EVIDENCE/'baseline_six']:
    path = folder/'command.json'
    data = json.loads(path.read_text())
    err = (folder/'stderr.txt').read_text()
    data['test_outcomes'] = [{'test': m[0], 'outcome': m[1]} for m in re.findall(r'^(test_\S+ \([^\n]+\)) \.\.\. (ok|FAIL|ERROR|skipped[^\n]*)$', err, re.M)]
    path.write_text(json.dumps(data, indent=2)+'\n')

successor = BASE/'sat_group_compiler_02_r1_codex_m1'
record('apply_candidate', [PYTHON,'-I','-S','-B',HANDOFF/'review/candidate_patch/apply_to_fresh_copy.py',
    '--source',HANDOFF/'frozen_r1','--destination',successor], HANDOFF)
shutil.copyfile(BASE/'portable_check.py', successor/'portable_check.py')
(successor/'verification/prior/scripts').mkdir(parents=True)
shutil.copyfile(HANDOFF/'review/tools/review_successor.py', successor/'verification/review_successor.py')
shutil.copyfile(HANDOFF/'reference_interpreter/scripts/review_sat02.py', successor/'verification/prior/scripts/review_sat02.py')
shutil.copyfile(BASE/'check_saved_rows.py', successor/'verification/check_saved_rows.py')
shutil.copytree(HANDOFF/'historical_sat02/results', successor/'saved/results')
# The original 73 test files remain unchanged and are run before adding six.
record('candidate_73', [PYTHON,'-I','-S','-B',successor/'portable_check.py','tests','--environment',EVIDENCE/'candidate_73_environment.json'], successor)
shutil.copyfile(HANDOFF/'review/candidate_patch/test_recovery_boundary_closeout.py', successor/'tests/test_recovery_boundary_closeout.py')
record('candidate_six', [PYTHON,'-I','-S','-B',successor/'portable_check.py','regressions','--environment',EVIDENCE/'candidate_six_environment.json'], successor)
record('candidate_boundary_reproducer', [PYTHON,'-I','-S','-B',successor/'portable_check.py','rows',
    '--output',EVIDENCE/'candidate_row_audit','--environment',EVIDENCE/'candidate_row_environment.json'], successor, expected=1)
