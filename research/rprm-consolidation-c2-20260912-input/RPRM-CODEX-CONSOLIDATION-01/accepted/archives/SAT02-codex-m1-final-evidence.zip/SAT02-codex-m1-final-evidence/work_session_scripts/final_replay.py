import datetime
import json
from pathlib import Path
import stat
import subprocess
import tempfile
import zipfile
from record import BASE, HANDOFF, EVIDENCE, PYTHON, record, sha

delivery = BASE / 'deliverables'
archive = delivery / 'SAT02-portable-codex-m1.zip'
expected = (delivery / 'SAT02-portable-codex-m1.sha256').read_text().split()[0]
assert sha(archive) == expected
fresh = Path(tempfile.mkdtemp(prefix='sat02-codex-m1-final-')).resolve()
assert not fresh.is_relative_to(Path('C:/github/RPRM-open')) and not fresh.is_relative_to(HANDOFF)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    names = [i.filename for i in z.infolist()]
    assert len(names) == len(set(names))
    for info in z.infolist():
        target = (fresh / info.filename).resolve()
        assert target.is_relative_to(fresh) and not stat.S_ISLNK(info.external_attr >> 16)
        assert info.filename.startswith('sat_group_compiler_02_r1_codex_m1/')
    z.extractall(fresh)
s = fresh / 'sat_group_compiler_02_r1_codex_m1'
extraction = {'archive': str(archive), 'archive_sha256': expected, 'fresh_extraction_parent': str(fresh),
    'extracted_build': str(s), 'outside_original_workspace': True, 'zip_crc_ok': True, 'archive_file_count': len(names),
    'extracted_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'checker_sha256': sha(s/'sat_group_compiler/receipts.py'), 'runtime_executable': PYTHON}
(EVIDENCE / 'FINAL_ZIP_EXTRACTION.json').write_text(json.dumps(extraction, indent=2)+'\n')

for label, check, output in [('final_manifest_before', 'manifest', None), ('final_79', 'tests', None),
                            ('final_six', 'regressions', None), ('final_review', 'review', 'final_review_rows'),
                            ('final_row_audit', 'rows', 'final_saved_rows'), ('final_manifest_after', 'manifest', None)]:
    args = [PYTHON, '-I', '-S', '-B', s/'portable_check.py', check, '--environment', EVIDENCE/(label+'_environment.json')]
    if output:
        args += ['--output', EVIDENCE/output]
    record(label, args, s)
record('final_historical_handoff', [PYTHON,'-I','-S','-B',s/'history/transfer/verify_handoff.py'], s/'history/transfer')
record('transfer_after', [PYTHON,'-I','-S','-B',HANDOFF/'verify_handoff.py'], HANDOFF)

def read(path):
    return json.loads((EVIDENCE / path).read_text(encoding='utf-8'))

original = read('baseline_73/command.json')['test_outcomes']
baseline_six = read('baseline_six/command.json')['test_outcomes']
full = read('final_79/command.json')['test_outcomes']
six = read('final_six/command.json')['test_outcomes']
assert len(original) == 73 and all(r['outcome'] == 'ok' for r in original)
assert len(baseline_six) == 6 and sum(r['outcome'] == 'FAIL' for r in baseline_six) == 3
expected_failed = ['test_closed_form_cannot_overwrite_boundary', 'test_empty_relation_does_not_need_recovery', 'test_table_cannot_overwrite_boundary']
assert sorted(r['test'].split()[0] for r in baseline_six if r['outcome'] == 'FAIL') == expected_failed
assert len(full) == 79 and len(six) == 6 and all(r['outcome'] == 'ok' for r in full + six)
assert {r['test'] for r in full} == {r['test'] for r in original} | {r['test'] for r in six}
assert len({r['test'] for r in full}) == 79

review = read('final_review_rows/saved_receipts_recheck.json')
assert review['count'] == 982 and not review['rejected'] and not review['independent_errors']
audit = read('final_saved_rows/row_audit_summary.json')
actual = read('final_saved_rows/all_982_receipt_rows.json')
assert audit['receipt_count'] == 982 and audit['accepted'] == 982 and audit['rejected'] == audit['independent_errors'] == 0
assert len(actual) == 982 and all(r['checker']['ok'] and not r['checker']['reasons'] and not r['independent_errors'] for r in actual)
assert all(r['checker']['grade'] == 'local_relation_checked' and r['checker']['binds_original_factor_ids'] is False and r['checker']['whole_solver_derivation_replayed'] is False for r in actual)
by_id = {(r['panel'], r['row'], r['receipt']): r for r in actual}
assert len(by_id) == 982
baseline = read('baseline_review_rows/saved_receipts_recheck.json')
assert baseline['count'] == 982 and len(baseline['rejected']) == 50 and not baseline['independent_errors']
transitions = []
for old in baseline['rejected']:
    new = by_id[(old['panel'], old['row'], old['receipt'])]
    assert old['report']['reasons'] == ['recovery_missing']
    assert new['independently_recomputed_mask'] == new['stored_mask'] == 0
    assert new['promise'] == 'C' and new['replacement'] == ['F'] and new['recovery_type'] == 'none'
    transitions.append({'panel': new['panel'], 'row': new['row'], 'receipt': new['receipt'],
        'before': old['report'], 'after': new['checker'], 'recomputed_mask': 0, 'replacement': ['F']})
(EVIDENCE/'EMPTY_RECEIPT_50_TRANSITIONS.json').write_text(json.dumps(transitions,indent=2)+'\n')

controls = read('final_saved_rows/m1_boundary_controls.json')
assert len(controls) == 23 and all(c['matches_expected'] for c in controls)
review_controls = read('final_review_rows/receipt_controls.json')['cases']
accepted_controls = {'correct_closed_form', 'good_table', 'unbound_original_ids'}
for c in review_controls:
    assert c['checker']['ok'] == (c['name'] in accepted_controls), c['name']
    assert c['checker']['binds_original_factor_ids'] is False and c['checker']['whole_solver_derivation_replayed'] is False
candidate_controls = read('candidate_row_audit/m1_boundary_controls.json')
assert [c['name'] for c in candidate_controls if not c['matches_expected']] == ['no_elimination_closed_overwrite','no_elimination_table_overwrite']
for c in candidate_controls:
    if not c['matches_expected']:
        assert all(t['satisfies_local_relation'] and not t['preserves_boundary'] for t in c['recovery_traces'])

g = read('final_review_rows/group_oracle.json')
assert (g['graphs'],g['comparisons'],g['failures']) == (1099,4396,[])
x = read('final_review_rows/xor_checks.json')
assert x['transform_cases'] == x['transform_passed'] == 72 and all(t['exact'] for t in x['trials'])
route = next(row for row in x['base'] if row['arm'] == 'W3-T')['receipts']
assert [(r['orig_cost'],r['new_cost']) for r in route] == [(15,18),(23,6)]
n = read('final_review_rows/native_check.json')
assert n == {'conjunction_accepts':147,'matches_original_elimination':True,'pair_projection_sizes':[9,9,9],
    'star_accepts':21,'star_domain':27,'two_star_domain':243,'union_atom_accepts':93}
t = read('final_review_rows/timer_and_grade.json')
assert t['failure_grade'] == 'receipt_rejected' and t['failure_status'] == 'UNRESOLVED'
assert t['receipt_check_s'] >= .025 and t['wall_s'] >= t['receipt_check_s']
f = read('final_review_rows/fingerprint_check.json')
assert f['before'] == f['after'] and f['stable'] and not f['versions_in_inputs']
for label in ['final_manifest_before', 'final_79', 'final_six', 'final_review', 'final_row_audit', 'final_manifest_after']:
    env = read(label+'_environment.json')
    assert not env['unexpected_modules'] and env['root'] == str(s)
seed = json.loads((s/'SEED_STATUS.json').read_text())
assert seed['run_count'] == 6 and seed['not_run_count'] == 4 and not seed['backfill_into_original_result']
assert sha(archive) == expected
workspace = Path('C:/github/RPRM-open')
git_status = subprocess.check_output(['git','status','--porcelain=v1'],cwd=workspace,text=True)
initial = read('initial_environment.json')
assert git_status == initial['git_status']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=workspace,text=True).strip() == initial['git_head']
assert sha(Path('C:/Users/bkbee/Downloads/SAT02-CODEX-CLOSEOUT-01.zip')) == initial['handoff_zip_sha256']
summary = {'disposition': 'INTEGRATED_AND_VERIFIED_WITHIN_LOCAL_SCOPE', 'build_sha256': expected,
    'checker_sha256': sha(s/'sat_group_compiler/receipts.py'), 'fresh_extraction': str(s),
    'tests': {'unchanged_original':73,'unchanged_supplied_regressions':6,'final_discovery':79,'all_passed':True,'same_six_repeated':True},
    'baseline': {'original_tests_passed':73,'six_failed':3,'saved_accepted':932,'saved_rejected_missing_recovery':50},
    'candidate': {'original_tests_passed':73,'supplied_regressions_passed':6,'saved_accepted':982,'new_overwrite_controls_failed':2},
    'saved_result_rows':466,'saved_receipts':982,'accepted':982,'rejected':0,'independent_errors':0,
    'empty_receipt_transitions_inspected':50,'targeted_controls':23,'targeted_controls_passed':23,
    'review_control_expectations_met':True,'xor_checks':72,'graph_comparisons':4396,'graphs':1099,
    'w3t_route':[[15,18],[23,6]],'three_color':n,'timer':t,'fingerprint':f,
    'manifest_before_after_passed':True,'historical_handoff_verified':True,'workspace_git_unchanged':True,
    'delivered_project_dependencies_only':True,'stdlib_runtime':PYTHON,'run_seeds':6,'not_run_seeds':4,
    'binds_original_factor_ids':False,'whole_solver_derivation_replayed':False,
    'panels_generated':False,'seed_backfill':False,'completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(EVIDENCE / 'FINAL_REPLAY_SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
