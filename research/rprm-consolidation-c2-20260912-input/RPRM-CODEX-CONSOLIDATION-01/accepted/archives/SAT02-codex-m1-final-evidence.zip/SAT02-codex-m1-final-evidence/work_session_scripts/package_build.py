import datetime
import difflib
import json
from pathlib import Path
import shutil
import zipfile
from record import BASE, HANDOFF, EVIDENCE, PYTHON, record, sha

s = BASE / 'sat_group_compiler_02_r1_codex_m1'
delivery = BASE / 'deliverables'
delivery.mkdir(exist_ok=False)
shutil.copytree(HANDOFF, s / 'history/transfer')
shutil.copyfile(BASE / 'verify_manifest.py', s / 'verification/verify_manifest.py')
(s / 'maintenance').mkdir()
current = s / 'sat_group_compiler/receipts.py'
original = HANDOFF / 'frozen_r1/sat_group_compiler/receipts.py'
candidate = HANDOFF / 'review/candidate_patch/receipts.py'
for label, prior in [('r1_to_m1', original), ('review_candidate_to_m1', candidate)]:
    diff = ''.join(difflib.unified_diff(prior.read_text().splitlines(keepends=True), current.read_text().splitlines(keepends=True),
        fromfile=label.split('_to_')[0] + '/sat_group_compiler/receipts.py', tofile='m1/sat_group_compiler/receipts.py'))
    (s / 'maintenance' / (label + '.patch')).write_text(diff, encoding='utf-8', newline='\n')

(s / 'README.md').write_text('''# SAT02 portable Codex M1

This is the active maintenance successor. The accepted partial research result is
unchanged. M1 integrates the reviewed local-checker repair with one small additional
guard for retained-variable writes when no variables are eliminated. The production
change is confined to `sat_group_compiler/receipts.py`; compiler, grouping, scoring,
protocol and seed code are byte-identical to submitted R1.

The integrated checker was tested before export. The final exported ZIP must be
verified from a fresh extraction; that completed replay is reported in the paired
`SAT02-codex-m1-final-evidence.zip` and `CODEX_M1_REVIEW_AND_CLOSEOUT.md`, outside this
hashed build. `M1_INTEGRATION.json` and `M1_MANIFEST.json` identify the current bytes.
The manifest binds bytes, not mathematical truth.

## Portable verification

Use Python 3.10 or newer with assertions enabled. M1 was verified on CPython 3.14.5.
No installation is needed for these checks. The inherited `requirements.txt` names
an optional original performance backend; it is historical and is not needed here.
`portable_check.py` delegates to the unchanged `run.py test` entrypoint, unittest
discovery for the supplied six tests, and the supplied bounded review script. Its
import guard prevents the inherited backend probe from loading hard-coded local
NariZoo modules or installed packages. Python's standard library is the runtime;
all project and review dependencies are delivered here.

From the extracted build, choose a fresh external evidence directory. For example
in PowerShell (if `../m1-replay` already exists, choose a different fresh name):

```powershell
New-Item -ItemType Directory -Path ../m1-replay
python -I -S -B portable_check.py manifest --environment ../m1-replay/manifest-environment.json
python -I -S -B portable_check.py tests --environment ../m1-replay/tests-environment.json
python -I -S -B portable_check.py regressions --environment ../m1-replay/six-environment.json
python -I -S -B portable_check.py review --output ../m1-replay/review --environment ../m1-replay/review-environment.json
python -I -S -B portable_check.py rows --output ../m1-replay/rows --environment ../m1-replay/rows-environment.json
python -I -S -B portable_check.py manifest --environment ../m1-replay/manifest-after-environment.json
```

`tests` discovers 79 = 73 unchanged original tests + six unchanged supplied review
regressions. `regressions` reruns that same six-case subset, not six further tests.
`review` reuses the supplied finite graph, XOR, native-color and receipt checks; its
exit code alone does not require zero receipt rejections. Inspect its actual JSON.
`rows` writes all 982 outcomes and 23 targeted control rows and requires the expected
accepts/rejects, zero rejected saved receipts, zero independent errors, and unchanged
local-only scope flags. The controls are diagnostics, not additional experiments.
Saved rows are read directly from `saved/results/`; no panels or seeds are generated.

## Current scope and history

Recovery on a nonempty Boolean local relation must extend the same retained boundary
and write only eliminated variables. Recomputed emptiness needs no reconstruction
witness; the stored mask and FALSE projection still must agree with the input.
This is local relation/recovery checking: `binds_original_factor_ids=False` and
`whole_solver_derivation_replayed=False` remain explicit. General parser hardening,
arbitrary future receipt grammars and whole-solver derivations are outside M1.

`history/transfer/` is the complete immutable received handoff, including frozen R1,
the three original input archives, the reviewed candidate, historical results and
the old status overlay. Its imperative documents are historical source material;
they are not a new assignment. Frozen R1 remains separate from this active build.
Root `HASHES.json`, `OWNER_RETURN.md`, `RESULT_STATUS.json`, `PATCH_APPLICATION.json`
and inherited protocol/seed records are preserved historical records. In particular,
`PATCH_APPLICATION.json` records the intermediate candidate application, not current
integration status. Original README and claim ledger are in `history/transfer/frozen_r1/`.
Use this README, the current `CLAIM_LEDGER.md`, `M1_INTEGRATION.json` and
`maintenance/M1_STATUS.md` for M1.

Keep 6 RUN / 4 NOT_RUN. Keep W3-T 15→18 then 23→6 as a local structural route; the
three-color star has 21/27 extensions and pair projections of size 9. The correct
two-factor conjunction accepts 147/243; the wrong union atom accepts 93/243.
Comparative speed, complete work budget, ten-seed completion, original dispatch
authentication, whole-solver proof, a new tractable SAT family and P versus NP
claims remain withdrawn or unclaimed. Unavailable historical logs stay unavailable.

C1, Lind–Reichardt and AD 14/16 versus 14/16 stay closed. Fluid and Yang–Mills stay
undispatched. No Task03, panel rerun, seed backfill, general rewrite, installation,
commit, push, merge, publication or other-lane dispatch is part of this build.
''', encoding='utf-8', newline='\n')

(s / 'CLAIM_LEDGER.md').write_text('''# SAT02 M1 claim ledger

Accepted partial research is unchanged. Owner-submitted R1 is frozen with its two
documented defects; the reviewer candidate is historical prior evidence. This M1
successor integrates the repair plus the relevant empty-elimination output guard.

| Claim | Carrier / receiver | Evidence and disposition |
| --- | --- | --- |
| Recovery extends the same retained assignment | Finite Boolean local relation R on scope S; B and E disjoint and cover S; promise C projects R to B | Code inspection plus unchanged 73+6 suite, 23 focused controls, and 982 saved local replays; M1 maintenance result only |
| Recovery is vacuous for empty input | Independently recomputed R is empty; replacement represents its empty projection | Accepted with no witness; incorrect stored zero masks and TRUE-for-empty replacements reject |
| No elimination permits no recovery writes | E is empty, R is nonempty; B=S | Both recovery forms must have no output keys. Absent recovery and identity forms remain accepted. Additional candidate flaw reproduced and repaired |
| Protected XOR and W3-T | Explicit retained variables {1,2,3} and supplied finite fixture | 72 parity transformations retained; ordinary W3 limitation retained; TABLE score 15→18, then parity 23→6. Structural score is not elapsed time |
| Native three-color star | {0,1,2}; existential center X; retained A,B,C | 21/27 extend; each pair projection has all 9 values |
| Overlapping stars | Two joint factors on 5 retained color variables | Exact conjunction 147/243; single union atom 93/243 is not equivalent; separator (0,0,1,1,2) retained |
| Saved local receipts | 982 receipts in 466 already-saved result rows | All accepted by M1 and the reused review interpretation with output-scope guard; no new panels and no new independent interpretation |
| Historical SAT answers and witnesses | Earlier reconstructed generators, n≤12 | Prior review evidence preserved as history; no fresh whole-instance claim in M1 |
| Connected grouping | Labelled graphs on 1–5 factors, forward/reverse IDs and two caps | Inherited repair unchanged; finite 1,099-graph / 4,396-comparison oracle retained, not an unbounded test proof |
| Timer and fingerprint repairs | Synthetic checker delay; generated versions record | Inherited corrections unchanged; checks retained, no performance ranking |
| Seed coverage | Original declared 10 seeds | 6 RUN / 4 NOT_RUN; no backfill; development 37,41 and evaluation 20063,20089 remain NOT_RUN |
| Whole-solver certification | Binding live input factor IDs and complete original-instance derivation | Not supplied. `binds_original_factor_ids=False`, `whole_solver_derivation_replayed=False`; local-only grade |
| Comparative/complete claims | Work budget, speed ranking, ten-seed completion, original dispatch, tractability, P versus NP | Withdrawn, unclaimed or explicitly limited; no new evidence upgrades them |

The recovery obligation is a section of existential projection: for every b in
pi_B(R), recovered r belongs to R and r restricted to B equals b. It does not
reconstruct every original satisfying occurrence or identify a whole solver chain.
Masks and enumeration concern finite admitted local scopes, not a general solver
soundness theorem. Malformed receipts, aliases accepted by integer coercion and
arbitrary extensions of the parser/grammar have not undergone a comprehensive
adversarial audit. Emptiness is established by evaluating the supplied input
identities, not by trusting their declared mask or binding them to a live instance.

Evidence grades remain distinct: historical run, written/code inspection, finite
unit/regression checks and reused independent local interpretation. No formal proof
was added. Hashes establish source identity only. Reproducible controls and corrected
counterexamples are retained alongside the surviving results.
''', encoding='utf-8', newline='\n')

(s / 'maintenance/M1_STATUS.md').write_text('''# SAT02 M1 maintenance status

M1 checker integrated in this fresh successor; accepted partial research unchanged.
The reviewed candidate was adopted with an additional eight-line output guard for
nonempty relations with no eliminated variables. Both recovery forms previously
accepted writes to retained variables in that case. M1 rejects those writes while
preserving absent/identity recovery and empty-relation vacuity.

The supplied candidate itself passed 73 original tests, six regressions and 982 saved
receipts, but failed the two added no-elimination overwrite controls. M1 passes all
23 focused controls. The original six-test file and all seven original test files
are byte-identical to their sources. The production code delta remains one file.

The paired external evidence and CODEX_M1_REVIEW_AND_CLOSEOUT.md report the final
ZIP's actual fresh-extraction verification. This build carries no self-referential
claim that its own future export replay was already run. Root HASHES.json and
PATCH_APPLICATION.json remain historical; M1_MANIFEST.json binds current payload.

Research: accepted partial. Seeds: 6 RUN / 4 NOT_RUN. Comparative and whole-proof
claims: withdrawn/limited. C1, Lind–Reichardt and AD 14/16 stay closed; Fluid and
Yang–Mills stay undispatched. No next experiment or Task03 is assigned.
''', encoding='utf-8', newline='\n')

integration = {'kind': 'M1_INTEGRATED_MAINTENANCE_SUCCESSOR', 'date': '2026-09-12',
    'research_disposition': 'ACCEPTED_PARTIAL_UNCHANGED', 'candidate_disposition': 'ADOPTED_WITH_RELEVANT_MINIMAL_CORRECTION',
    'original_checker_sha256': sha(original), 'review_candidate_checker_sha256': sha(candidate),
    'integrated_checker_sha256': sha(current), 'production_files_changed': ['sat_group_compiler/receipts.py'],
    'reason_for_candidate_change': 'Nonempty no-elimination receipts could still overwrite retained boundary via either recovery form; reject nonempty output maps/internal dictionaries when E is empty.',
    'added_production_lines_beyond_candidate': 8, 'original_tests': 73, 'supplied_regressions': 6,
    'additional_diagnostic_controls': 23, 'saved_receipts': 982, 'saved_result_rows': 466,
    'final_export_replay': 'See paired external SAT02-codex-m1-final-evidence.zip; no circular build hash.',
    'historical_hashes_json_not_current_manifest': True, 'historical_patch_application_not_current_status': True,
    'whole_solver_derivation_replayed': False, 'binds_original_factor_ids': False,
    'run_seeds': 6, 'not_run_seeds': 4, 'no_panels_rerun': True, 'no_seeds_backfilled': True,
    'runtime': 'CPython standard library; delivered-only launcher blocks inherited external backend import paths.'}
(s / 'M1_INTEGRATION.json').write_text(json.dumps(integration, indent=2) + '\n')

# Source comparison includes every original file, not merely the three named protocols.
comparison = []
for p in sorted((HANDOFF / 'frozen_r1').rglob('*')):
    if p.is_file():
        rel = p.relative_to(HANDOFF / 'frozen_r1').as_posix()
        q = s / rel
        comparison.append({'path': rel, 'before_sha256': sha(p), 'after_sha256': sha(q), 'unchanged': p.read_bytes() == q.read_bytes()})
assert {r['path'] for r in comparison if not r['unchanged']} == {'README.md', 'CLAIM_LEDGER.md', 'sat_group_compiler/receipts.py'}
(s / 'maintenance/ORIGINAL_FILE_COMPARISON.json').write_text(json.dumps(comparison, indent=2) + '\n')

record('m1_final_bytes_79', [PYTHON,'-I','-S','-B',s/'portable_check.py','tests','--environment',EVIDENCE/'m1_final_bytes_79_environment.json'], s)
manifest = {'kind': 'M1_CURRENT_PAYLOAD_SHA256', 'manifest_excludes_itself': True, 'files': [
    {'path': p.relative_to(s).as_posix(), 'bytes': p.stat().st_size, 'sha256': sha(p)}
    for p in sorted(s.rglob('*')) if p.is_file()]}
(s / 'M1_MANIFEST.json').write_text(json.dumps(manifest, indent=2) + '\n')
record('preexport_manifest', [PYTHON,'-I','-S','-B',s/'portable_check.py','manifest','--environment',EVIDENCE/'preexport_manifest_environment.json'], s)
archive = delivery / 'SAT02-portable-codex-m1.zip'
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for p in sorted(s.rglob('*')):
        if p.is_file():
            z.write(p, (Path(s.name) / p.relative_to(s)).as_posix())
digest = sha(archive)
(delivery / (archive.stem + '.sha256')).write_text(digest + '  ' + archive.name + '\n', encoding='ascii')
print(json.dumps({'build': str(archive), 'sha256': digest, 'checker_sha256': sha(current), 'payload_files': len(manifest['files']) + 1}, indent=2))
