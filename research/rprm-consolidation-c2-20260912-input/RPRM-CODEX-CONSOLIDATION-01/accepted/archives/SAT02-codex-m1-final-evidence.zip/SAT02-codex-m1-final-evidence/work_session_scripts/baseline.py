import json
import platform
import shutil
import subprocess
import sys
from pathlib import Path
from record import BASE, HANDOFF, EVIDENCE, PYTHON, record, sha

workspace = Path('C:/github/RPRM-open')
environment = {'workspace': str(workspace), 'python': sys.version, 'executable': PYTHON,
    'platform': platform.platform(), 'git_head': subprocess.check_output(['git','rev-parse','HEAD'],cwd=workspace,text=True).strip(),
    'git_status': subprocess.check_output(['git','status','--porcelain=v1'],cwd=workspace,text=True),
    'handoff_zip_sha256': sha(Path('C:/Users/bkbee/Downloads/SAT02-CODEX-CLOSEOUT-01.zip')),
    'assertions_enabled': __debug__, 'no_panels': True}
(EVIDENCE / 'initial_environment.json').write_text(json.dumps(environment, indent=2) + '\n')
record('transfer_before', [PYTHON,'-I','-S','-B', HANDOFF/'verify_handoff.py'], HANDOFF)
baseline = BASE / 'baseline_r1'
shutil.copytree(HANDOFF / 'frozen_r1', baseline)
shutil.copyfile(BASE / 'portable_check.py', baseline / 'portable_check.py')
(baseline/'verification/prior/scripts').mkdir(parents=True)
shutil.copyfile(HANDOFF/'review/tools/review_successor.py', baseline/'verification/review_successor.py')
shutil.copyfile(HANDOFF/'reference_interpreter/scripts/review_sat02.py', baseline/'verification/prior/scripts/review_sat02.py')
shutil.copytree(HANDOFF/'historical_sat02/results', baseline/'saved/results')
record('baseline_73', [PYTHON,'-I','-S','-B',baseline/'portable_check.py','tests','--environment',EVIDENCE/'baseline_73_environment.json'], baseline)
shutil.copyfile(HANDOFF/'review/candidate_patch/test_recovery_boundary_closeout.py', baseline/'tests/test_recovery_boundary_closeout.py')
record('baseline_six', [PYTHON,'-I','-S','-B',baseline/'portable_check.py','regressions','--environment',EVIDENCE/'baseline_six_environment.json'], baseline, expected=1)
record('baseline_review', [PYTHON,'-I','-S','-B',baseline/'portable_check.py','review','--output',EVIDENCE/'baseline_review_rows','--environment',EVIDENCE/'baseline_review_environment.json'], baseline)
