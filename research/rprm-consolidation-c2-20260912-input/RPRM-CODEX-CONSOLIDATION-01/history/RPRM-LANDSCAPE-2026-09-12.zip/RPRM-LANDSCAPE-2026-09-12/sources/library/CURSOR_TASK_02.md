# Cursor task 02 — exact boundary relations and representation-aware traversal

Continue the uploaded `sat_group_compiler_01` experiment. Implement and run an isolated follow-up in `experiments/sat_group_compiler_02/`. Preserve v1 code, protocol, reports, and raw results unchanged. Do not modify canonical RPRM theory documents or claim P=NP.

## Aim

Test William's current hypothesis in two concrete forms:

1. A useful relation may be invisible to a small grouping window or inaccessible to a procedure that requires every intermediate step to shrink immediately.
2. Eliminating a participant can produce a genuinely higher-arity boundary relation. The traversal order and the representation retained at that boundary should be tested separately.

Primary deliverable: a controlled Boolean window/temporary-representation experiment. Secondary deliverable: a small exact three-color boundary experiment, not a new general coloring solver. Complete the primary stage even if later stages reach their resource limits.

## Grounding: what v1 actually supports

Read v1 `REPORT.md`, `PROTOCOL.md`, `TRANSFORM_CARDS.md`, source, tests, and raw JSON. Read applicable workspace instructions. Inspect existing RPRM components only at accessible verified paths; report missing dependencies rather than inventing their contents. Reuse correct existing implementations with attribution.

V1 recognized SAME/DIFFERENT and some cardinality relations. The 3-variable, 4-clause XOR fixture stalled in the 2–3-factor window. All 29 supplied tests passed in the independent review. In the supplied evaluation JSON, B made 20/33 definitive decisions and C made 22/33. In stress, B made 21/27 and C made 13/27: eight B decisions became C resource limits. These are instance–arm comparisons, not evidence of universally better grouping.

Read `REVIEW.md` and `review_checks.json` if supplied. The review's four-factor monkey-patch is only a diagnostic, not a frozen v2 benchmark. With no protected variables, the standalone XOR can be enumerated and projected to TRUE. With all three protected, it is recognized as `P:1,2,3=1`. Recognition must therefore be scored separately from deciding an isolated tiny formula.

## Stage 0 — repair the measuring apparatus before freezing v2

Make regression tests fail on the old defects, then fix them in v2 only. Write `V1_ERRATA.md` with exact source references and bounded claims.

1. `_enum_groups` currently constructs all pair/triple combinations eagerly, including scanning disconnected tuples before candidate accounting. Replace it with lazy, variable-incidence-driven connected-group generation, deduplication, and deadline/work checks *during generation*. Count tuple/proposal work and discarded candidates, not just groups reaching recognition. A review probe with 70 disjoint binary clauses scanned 57,155 pair/triple combinations, recorded zero candidates, and returned UNRESOLVED after about 0.196s despite a 0.01s configured budget. That observed time is host-specific; the bypass is the regression target.
2. Make scope/group limits flow from the actual configuration. V1 hard-codes six-variable scopes and B/C group sizes; editing JSON alone does not change those behaviors. Serialize effective configuration in each run.
3. Bound and charge initial simplification, recognition-template construction, projection, validation, recovery construction, native closing, residual encoding, and final validation. `group_sat_masks` rows alone are not total table work. Record cold and warm cache conditions; avoid silently warming C with B's templates. Cap speculative work and allocations.
4. Capture a disjoint phase timing breakdown and independent end-to-end wall time. V1 `selection_s` includes recognition; `_finish` ignores its `t0`; hybrid timing omits preprocessing and double-counts residual solve time. Do not reconstruct total time by adding overlapping counters.
5. Record initial as well as intermediate representation peaks. Replace approximate proof/witness byte formulas with actual serialized byte lengths, including recovery tables, proofs, caches, and any retained original block. Distinguish logical serialized size from Python process-memory measurements; report peak process memory where available, not as an exact sum of object sizes.
6. `backends.pysat_sat` calls ordinary `solver.solve()` and checks time only afterward; this is not an enforced timeout. Use a verified supported interruption/limited-solving API or a killable worker process. Test that it actually stops. Time-limit outcomes are not UNSAT. Use a slow worker stub for a deterministic watchdog regression rather than depending on a particular hard SAT instance.
7. Repair and probe optional backend imports *before* freezing. V1's saved panels predate an affine-import fix even though the protocol hash was unchanged. Fingerprint source files, effective configuration, Python/package versions, and actually available backend versions; require matching identities for a claimed reproduction.
8. Syntactic classification into 2-CNF or Horn is permitted computed work, not hidden family advice. Keep ordinary implication-graph 2-SAT distinct from the narrower signed-union-find method. Preserve known methods as explicit baselines; do not implement unrelated backends just to enlarge this task.
9. Keep statuses and claims honest: compiler-local checks plus oracle agreement are not automatically an independently replayed UNSAT proof. Implement a small separate receipt checker for the transformations introduced here. Record immutable input/output factor identities and enough normalization/unit/UF/affine steps to replay the claimed derivation; alternatively mark any non-replayed backend conclusion accurately. The checker must not just invoke the compiler again or trust a `validation` string.
10. Correct the transform-card minimality language. Removing a clause and changing the represented relation does not alone prove minimality of a *stall*. Declare the property, rerun it on each deletion, and report only the minimality actually tested.

Preserve the three contracts: A = same binary penalty function; B = identical satisfying assignments on the same named variables; C = exact existential boundary projection with recovery. Each operation declares its contract. Removing duplicate clauses is generally B, not A. Check global witness recovery against the original input.

After repairs, freeze `PROTOCOL_V2.md`, machine configuration, implementation fingerprints, seeds, stopping rules, and acceptance criteria. Use old panels only for regression; new evaluation seeds are required. Keep later changes as new versions. Define shared resource budgets before evaluation.

## Stage 1 — distinguish window size from the need for an intermediate

### 1A. Protected XOR interface

Start from the existing fixture:

```text
p cnf 3 4
1 2 3 0
1 -2 -3 0
-1 2 -3 0
-1 -2 3 0
```

It represents `x1 XOR x2 XOR x3 = 1`.

In the local transformation test, declare all three variables retained. Require a B-equivalent PARITY representation, not merely a SAT status or one stored assignment. Check all eight named boundary assignments independently. An explicit retained-variable API is part of this subtest's input contract, not a hidden hint given to the autonomous benchmark.

Separately generate larger raw-CNF instances in which those variables occur in other live constraints. Interleave and rename the clauses. The autonomous candidate receives no block boundaries, planted witness, family label, useful order, or expected parity bit. Record what it actually finds, including when preprocessing changes the original block before recognition.

Recognition tests must include both parity values, all consistent variable complementations, reordered clauses/literals, duplicate clauses, tautologies, and near misses formed by deleting/flipping constraints. A near miss must not be replaced by a stronger parity relation. Both SAT and UNSAT contexts must be independently labeled.

Do not infer a surviving boundary relation by solving a whole block with an empty boundary. Log protected-boundary recognition, existential elimination, and backend solving separately.

### 1B. Matched variants

Run these with the same repaired core, scope cap, score for ordinary replacements, native backend availability, and comparable frozen budgets:

- **W3:** original pair/triple grammar-only discovery.
- **W4:** allow four-factor groups; no new grammar atom. This isolates the window change.
- **W3-T:** keep the 2–3-factor window but allow a bounded exact temporary relation TABLE on at most six Boolean variables. Freeze a small speculation depth/beam width and account for every explored path. A TABLE may cost more temporarily; do not apply the old strict immediate-compression guard to this arm. Full boundary semantics and recovery must remain exact. A stored table is not compression merely because it has one ID. Repeated states, memory, and total work are bounded.
- **W4-I:** use a public support/incidence index to find complete small same-scope sign patterns before generic four-group search. No family hints. Keep its transformation grammar unchanged and label this separately as a selection/indexing improvement.

Fix all numerical caps during development, not after reading held-out outcomes. Evaluate candidates at the same total work limits, and show work curves rather than one cherry-picked threshold. It is legitimate for a smaller window to outperform a larger one.

Show whether the XOR relation needs (a) a larger simultaneous view, (b) a charged temporary description along the route, or (c) a better candidate index. If W4 or W3-T recognizes a relation but does not decide a mixed residual, record both facts.

Use known GF(2) elimination only after the recovered factors satisfy its checked input contract. It is a baseline algebraic backend, not discovery and not a general solver for mixtures with arbitrary OR constraints. Include reproducible self-contained availability or explicit skips; do not require a machine-specific sibling checkout for the key comparison.

Test isolated blocks, shared-variable XOR chains/networks, XOR-plus-OR systems, signed graphs, exactly-one systems, and small unrelated 3-CNF controls. Scale enough to expose selection overhead, under real watchdogs. No global truth-table fallback inside the candidate; bounded local TABLE recognition remains explicitly charged enumeration.

## Stage 2 — pairwise exclusions can leave a three-way relationship

This is a deliberately declared **native three-value carrier** experiment, distinct from Boolean recognition. Variables take colors in `{0,1,2}`. Do not confuse three colors, three variables, three clauses, and group size.

For center X and boundary A,B,C, define:

`X != A AND X != B AND X != C`.

With X strictly internal, prove and check:

`exists X: block` iff `number of distinct colors in {A,B,C} <= 2`.

Call the retained relation `USES_AT_MOST_2_COLORS(A,B,C)`. Equivalently, there is a missing color. Test the 27 boundary assignments: exactly 21 are extendable. Each two-variable projection nevertheless contains all nine pairs. Replacing the relation by the conjunction of its pair projections is therefore unsound.

Compose with `A!=B, B!=C, C!=A`: the original and correct projected systems are UNSAT; the pairwise-only ablation admits all-distinct assignments. Keep this ablation out of the accepted engine.

Retain a constructive lift: choose a color absent from the boundary for X. If X has any outside incidence, it is not internal and cannot be dropped under this contract. Test this side condition explicitly. Retained boundary variables cannot be eliminated merely to obtain a SAT scalar.

Create a reference one-hot CNF encoder and independently validate both directions and recovered witnesses. The four-node star occupies 12 Boolean variables in that encoding, outside v1's six-Boolean-variable recognizer cap. Native success is not automatic recovery of the three-color carrier from arbitrary CNF. Use separate labels:

- native typed-relation test;
- CNF encoder/decoder equivalence test;
- raw-CNF discovery test, only if actually implemented and executed.

Do not give manually supplied one-hot block labels to a lane advertised as raw-CNF-only discovery. Automatic carrier recovery is not required in this iteration.

### Scaling and traversal

Extend the star to k boundary nodes. Derive the same `USES_AT_MOST_2_COLORS` condition and missing-color recovery without enumerating `3^k` assignments. Its argument list still has length k. Charge evaluation, storage, and recovery accordingly. Compare with both the original star and a naive table: avoiding a table is not automatically a size improvement over the already-compact original graph.

On small graphs with overlapping stars, compare fixed-ID, computed minimum-degree, and one explicitly defined representation-aware processing policy. Freeze policies; charge order discovery and speculative candidate evaluation. Keep the same final question, retained outputs, and witness obligations across orders. In the local protected A/B/C fixture, eliminating A, B, or C is not a competing legal order.

Carry the exact joint boundary relation after each allowed elimination. Use a capped explicit reference table for small scopes; retain a symbolic relation only with proved operations. Stop honestly when a composition has no supported compact form. Compact storage of one factor does not imply tractable composition of overlapping factors.

Test global color permutations. Do not independently rename colors inside different blocks and then join them without an explicit compatible mapping. Do not treat a three-bit missing-color mask from one assigned boundary as a complete summary of every possible boundary assignment.

Record scope, representation type, serialized size, propagation/update work, and reconstruction cost at each step. Distinguish original rule arity, resulting boundary arity, and representation size. Draw no general coloring or P=NP conclusion from these restricted specimens.

## Verification, measurements, and deliverables

Use bounded exhaustive evaluation for small declared domains and a separately metered reference SAT solver above the cutoff. All candidate SAT assignments are checked on the original formula. Candidate UNSAT needs the advertised checked derivation; oracle agreement is a separate field. Inject corrupted receipts, wrong variable mappings, wrong recovery bits, and illegal eliminations to test rejection.

Publish matched counts of SAT, UNSAT, UNRESOLVED, RESOURCE_LIMIT, FAILURE, and SKIPPED. Report any decisive-to-limited regression, not only disagreements. Report input size; raw scopes; generated/rejected proposals; table/template/projection rows; cached and uncached costs; peak live state; proof/recovery bytes; exclusive stage times; and whole-pipeline time. Hybrid totals include preprocessing, export, residual solver, and lift exactly once.

Deliver runnable code, tests, fixtures, locked source/config/dependency identities, JSON/CSV results, and commands. Produce `TRANSFORM_CARDS_V2.md` showing:

- raw block and its relationship to outside variables;
- exact transformation and its A/B/C contract;
- a window success or temporary-table route;
- an invalid pairwise contraction counterexample;
- an observed expensive or unresolved composition;
- actual costs and how the claim was checked.

Keep the report readable. Answer:

1. What changed because the procedure could see four factors?
2. What changed because an intermediate was allowed not to shrink immediately?
3. What changed because of traversal/indexing rather than a stronger grammar?
4. Which higher-arity relation survived removing the center, and why could pairs not preserve it?
5. What broke or grew when compact relations overlapped?
6. Which smallest observed obstacle identifies the next missing operation?

Use proposed/tested/proved labels, with finite test scope stated. A bounded null is useful. No new-theorem or universal polynomial claim without its actual proof. Return completed stages and honest limits rather than deferring the task or asking whether to proceed.

## Primary reference points

For implementation details, consult the official PySAT solver API for actual supported interruption/limited-solving behavior. For comparison, complete parity reasoning alongside CNF has established implementations (Laitinen, Junttila, Niemela, arXiv:1207.0988). These references do not supply an answer for this selector; cite them as known machinery, not novelty.
