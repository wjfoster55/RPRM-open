# Independent review of sat_group_compiler_01

## Scope

Reviewed the uploaded source, protocol, report, transformation cards, and saved result JSON. Reran the 29 supplied unit tests: all passed. Did not rerun the full original panels or reproduce the original machine-specific NariZoo backends. No source in the extracted v1 directory was edited. Additional checks below are reviewer diagnostics, not a frozen v2 performance result.

Archive SHA-256: `f8eec0656ac0823be7bebc4837cceb6efbfab26fa52edaabc53ad1f38248f447`.

## Recount of saved results

| Panel | Per-arm instances | A definitive | B definitive | C definitive | C resource limits |
|---|---:|---:|---:|---:|---:|
| Smoke | 18 | 7 | 13 | 15 | 2 |
| Stress | 27 | 1 | 21 | 13 | 11 |
| Development | 33 | 2 | 19 | 21 | 2 |
| Evaluation | 33 | 3 | 20 | 22 | 2 |

Definitive means SAT or UNSAT. The four JSON files contain 333 instance-arm records, not 333 independent puzzles. Their stored soundness/agreement fields contain no false entries. This is a recount of the supplied records, not an independent proof of all reported UNSAT conclusions.

The stress panel loses eight B decisions under C: DIFFERENT cycles of lengths 15 through 21, plus one 24-variable signed graph. All eight C outcomes are RESOURCE_LIMIT with `max_seconds`. The report's statement that C is the same as B on stress cycles is too broad. Larger windows expose more relations on some examples but do not monotonically improve bounded completion.

## Four-factor diagnostic

The original XOR fixture has 3 variables, 4 clauses, and no rewrite with v1's pair/triple selector. A local monkey-patch changed only group enumeration to permit four factors. Affine closing was explicitly disabled.

- No retained boundary: SAT, all three variables existentially eliminated, replacement TRUE. This is correct bounded whole-block enumeration, not proof that the output retained a parity relation.
- Retain variables 1,2,3: replacement `P:1,2,3=1`, contract B, no eliminated variables. The final status was UNRESOLVED with the affine closer disabled, even though parity recognition succeeded.

The next comparison should measure recognition with a protected or genuine shared interface, separately from solving an isolated tiny formula. For raw-CNF end-to-end tests, the candidate must discover blocks without supplied generator labels.

## Measurement / reproducibility defects to fix before interpreting speed

- `compiler.py:_enum_groups` eagerly scans all raw pairs/triples and checks connectedness afterward. Deadline and candidate accounting occur only after list construction. On 70 disconnected binary clauses, the local diagnostic scanned 57,155 raw combinations, recorded zero candidates, and returned UNRESOLVED without any limit flag after about 0.196 seconds under a configured 0.01-second cap. The time is host-specific; the uncapped stage is the finding.
- Configuration is not the sole behavioral source: six-variable scopes and group sizes are hard-coded in the compiler. A JSON edit is not an implementation change.
- `selection_s` encloses recognition, so those times overlap. `_finish` accepts but does not use `t0`; no complete candidate wall time is saved by that path.
- `cli.py:hybrid_arm` omits preprocessing from its timer and adds oracle time on top of the elapsed interval already containing it. It is not end-to-end hybrid timing.
- `backends.py:pysat_sat` calls ordinary `solver.solve()` with no interruption/budget mechanism. Checking elapsed time afterward does not enforce the advertised limit.
- The table counter omits recognition-template construction, validation table work, and several projection/recovery passes. Approximate proof bytes omit the actual recovery-table payload. Initial representation peaks can be missed because initial state is not recorded before simplification.
- The recognition-template cache is shared across runs. Default sequential A/B/C evaluation can warm later arms. Explicit cold/warm policy and complete accounting are needed.
- Saved panel environment predates an affine-import repair; the unchanged protocol hash does not capture that code/environment change. Fingerprint actual implementation and backend versions.
- Receipts and internal checks are useful but do not, as currently recorded, constitute a separately replayed full proof trail for every native transformation. Oracle agreement and replay-checked certificates need distinct labels.
- The statement that 2-SAT or Horn dispatch would inherently require a human family label is too strong. Their syntactic eligibility can be computed from input. A chosen ROBDD order can also be algorithmic, although finding and using it has a cost.
- “Deleting a clause changes the relation” does not establish minimality of a selector-stall property. The property must be rerun after the deletion.

These are measurement and claim-scope corrections, not an observed wrong SAT/UNSAT result from the provided tests.

## Boundary relation from the discussion

For X,A,B,C in {0,1,2}, with X internal:

`exists X (X!=A and X!=B and X!=C)` iff `|{A,B,C}| <= 2`.

Exhaustive local verification: 21/27 boundary triples are extendable; all three pair projections contain all nine assignments. A conjunction of those pair projections admits (0,1,2), which the true relation rejects. Adding the pairwise DIFFERENT triangle on A,B,C makes the correctly retained problem UNSAT while the pairwise-only ablation admits a false solution.

This is a three-value-carrier specimen, not automatic recognition by the existing six-Boolean-variable compiler. Its standard four-node one-hot CNF has 12 Boolean variables. Keep typed-relation testing, encoder equivalence, and automatic recovery from raw CNF distinct.

For k neighbors of an internal center, the exact condition remains “use at most two colors,” with a missing-color witness lift. It has O(k) argument data; its compactness versus a full table does not itself beat the original O(k)-edge star. Overlapping such relations are the meaningful composition test.

## Reproduction

`review_checks.py --experiment PATH_TO_EXTRACTED_sat_group_compiler_01 --out OUTPUT_DIRECTORY`

Optional: add `--archive PATH_TO_ORIGINAL_ZIP` for the archive hash. The script monkey-patches group enumeration only within one process and restores it afterward. It does not edit the experiment. Results are in `review_checks.json`.

The supplied tests can be rerun from the experiment directory with `python run.py test`.
