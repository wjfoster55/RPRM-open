# Coordinator instruction — reconcile four existing lanes, do not relaunch them

William is reviewing Understanding P Versus NP, Explore Birch–Swinnerton-Dyer, Fluid Adjacency Findings, and the Yang–Mills gap thread after accepted core recovery C1. Read LANDSCAPE.md and the relevant owner card. This packet is a scoped coordination review, not four simultaneous execution orders.

## Shared accepted dependency

RCF01-portable-codex-c1.zip is accepted within its exact finite scope, SHA256:
`5a33fe48bb7f868fdfa11d0baa23aa2a158bba04e3e5f341b2962bae8c82328b`.
Read sources/core_c1/CLOSEOUT_MESSAGE.md and CARRY_FORWARD_CODEX.md. Do not restart its recovery, repeat its entire audit, rename the seven-coefficient representatives as a closed subalgebra, or upgrade it into a universal compression/physics result. Preserve broader meanings and the OPEN/NOT_RUN work.

## Reconcile before dispatch

For each existing owner, obtain the exact current assignment, source/commit or archive identity, whether a worker is running, whether a result already exists, and the single next missing proof/test/measurement. A document’s existence does not identify execution status. The user reports the fluid frontier workers finished; the PRs were still draft/unmerged at this review. SAT02’s latest located artifact is an assignment, not a completed return.

Do not overwrite a running task with this overview. Reuse an already completed return before proposing new work. Closed Lind–Reichardt and C1 results remain closed.

## Proposed routing

- Fluid: bounded evidence/claim reconciliation of existing PR12/13, with only directly necessary reproductions. No TGS, new domain or tuned larger study.
- SAT: continue or review existing Task02 once; do not create a competing task03. Retain the window/temporary-representation/indexing comparisons and exact boundary recovery.
- AD: one compact scoped-claim operational-use development design; old pilot unchanged. Do not imply empirical benefit from exact mathematics alone.
- Yang–Mills: one justified physical model/observable/dynamics bridge and falsifiable target; no invented seam-energy law.

Keep one owner/writer per worktree. Do not merge/rebase unrelated workers’ branches for housekeeping. PR13 is based on PR12; handle their ancestry intentionally if a later, separately authorized integration occurs.

## Return

Return a short table with source/version, current task, real execution state, accepted result, next bounded deliverable and stop condition. Note disagreements with this landscape explicitly. No new registry framework, historical transcript reconstruction, public release, paper-source edit, commit/push/merge, paid compute or unrelated lane restart is requested by this coordination card. Scientific work is assigned through the relevant owner card only when William directs it there.
