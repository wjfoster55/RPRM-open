# SAT owner — continue the existing boundary-relation experiment

**First reconcile status.** The latest retrieved artifact is `CURSOR_TASK_02.md`, not a completed Task02 return. Read the owner’s current state before running anything. If Task02 already exists, review it; if it is running, do not launch a duplicate. This card does not supersede its frozen protocol.

## Sources and accepted context

Read `sources/library/REVIEW(5).md` and `sources/library/CURSOR_TASK_02.md`. The review reran 29 v1 tests and recounted saved panels, but did not replay every original backend/panel. It found no wrong checked SAT/UNSAT result; it did identify significant budget/timing/accounting defects. Evaluation B20/33 vs C22/33 and stress B21/27 vs C13/27 show that a larger discovery window is not monotonically better under resource limits.

The core C1 result is now available as a correctness reference. Do not rewrite the SAT engine to imitate cube data structures. Import the relevant obligations: an exact retained boundary, operations valid for that boundary, truthful output classes, original-witness reconstruction and total-cost accounting.

## Substantive next question

Does the observed stall come from too small a simultaneous view, a forbidden temporary non-shrinking representation, or an expensive traversal/selection policy?

Keep the already assigned W3 / W4 / W3-T / W4-I comparison, the measurement repairs, exact source/config bindings and negative controls. Retain the protected XOR boundary: recognizing parity is different from eliminating an isolated satisfiable block to TRUE.

The native three-color star is the core connection: eliminating an internal X from X≠A, X≠B, X≠C leaves “at most two colors among A,B,C.” Pair projections cannot retain that relation. Preserve the outside-variable incidence test and recovery of a missing color for X. Native three-color success is not automatic discovery from raw one-hot CNF.

The meaningful composition question is what happens when those compact factors overlap. Track exact semantics, argument size, intermediate growth, supported projections, nonemptiness and recovery. A compact named factor is not automatically a tractable conjunction with other factors.

## Success, null and stop condition

Complete or review the existing bounded task. Return one clear transform card for a success, one legal counterexample/boundary, and one costly or unresolved composition, with the original evidence grades and full pipeline costs. A null or a simple conventional baseline win is a result.

Do not relabel finite success as P=NP, or frontier traversal as proof of polynomial cost. Any general result would need a separate uniform proof of compiler, representation, semantic-operation and recovery complexity in input bit length. Do not require such a universal theorem to close Task02. No new benchmark arms, public-paper changes, unrelated backend rewrites or competing Task03 are requested by this card.
